# Notch Tutor

An always-on-top "notch" AI tutor for macOS, Windows and Linux. It watches your primary screen, listens to your voice, and talks back in real time through one Gemini Live session.

## Everyday use

Open Notch Tutor like any other app: press **⌘ + Space**, type `Notch Tutor`, and press **Enter**, or double-click it in **Applications**. Terminal is only needed for building. If you start the app from Terminal, closing Terminal also closes the app.

### Start Notch Tutor automatically when your Mac turns on (optional)

Open the **Study hub** and turn on **Open when my Mac starts** at the bottom of the sidebar. If macOS opens the Login Items window, switch **Notch Tutor** on there to finish.

You can also do it by hand:

1. Open **System Settings**.
2. Click **General** in the sidebar, then **Login Items**.
3. Under **Open at Login**, click **+**.
4. Choose **Notch Tutor** in **Applications** and click **Open**.

To stop it starting automatically, select **Notch Tutor** in that list and click **−**. After rebuilding the app, remove it from the list and add it again, since macOS treats each rebuild as a new app.

## Talking to your tutor

- **Hold to talk (default):** hold **Right Option** anywhere on your Mac, speak, and let go. Holding the key also interrupts the tutor if it's talking. The first time, allow Notch Tutor under **Study hub → Settings → Allow access** (macOS Accessibility). Until then, you can press and hold **Hold to talk** in the notch instead.
- **Change the key** in **Study hub → Settings → Talk key**. The fn key can't be used, because macOS keeps it for emoji and dictation.
- **Always listening:** switch to it in Settings if you'd rather not hold a key. The notch then shows a Mute button.
- **Typing:** hover the notch and type in the box. When the tutor asks you a question, it appears at the top of your screen with a box for your answer, and the tutor gives you feedback on what you type.
- **The face** in the notch turns yellow and moves its mouth when the tutor talks, and turns blue when you talk. You can hide it in Settings.
- The tutor can also **open revision pages** in your browser and **open your study hub** when you ask it to.

## Sending Notch Tutor to other people

After `npm run dist:mac`, the `release` folder contains:

- `NotchTutor-Mac-arm64.dmg` for Macs with Apple chips (M1–M5, A18 Pro, MacBook Neo and newer)
- `NotchTutor-Mac-x64.dmg` for older Intel Macs

Upload the right file to Google Drive, OneDrive or WeTransfer, or AirDrop it. Each person uses their own free Gemini key, so it costs you nothing.

Message you can send with it:

> Here's Notch Tutor. Open the .dmg and drag Notch Tutor into Applications. The first time you open it, macOS will warn you it's from an unidentified developer: click Done, then go to System Settings → Privacy & Security, scroll down and click Open Anyway. You'll need a free Gemini API key from aistudio.google.com/apikey: hover the black bar at the top of your screen, click Start session and paste it in.

The warning appears because the app isn't signed with a paid Apple Developer certificate ($99/year). Everything still works after **Open Anyway**.

### Download links for your website (Mac and Windows, free)

GitHub builds both versions for free on its own computers (so you don't need a Windows PC) and hosts the files with permanent links.

1. Go to **github.com** and create a free account.
2. Click **+** (top right), then **New repository**. Name it `notch-tutor`, choose **Public** (downloads from private repositories need a GitHub login), and click **Create repository**.
3. On the new page, click **uploading an existing file**.
4. In Finder, open your `notch-tutor` folder and press **⌘ + Shift + .** to show hidden items (you need the `.github` folder). Select everything **except** `node_modules`, `release` and `out`, and drag it into the GitHub page. Wait for the uploads to finish, then click **Commit changes**.
5. Click the **Actions** tab. If asked, click the green button to enable workflows. Click **Build installers**, then **Run workflow**, then the green **Run workflow** button.
6. Wait about 10–15 minutes for a green tick. The files then appear under **Releases** on the right of your repository's main page.

Your permanent links (replace `YOUR-USERNAME` with your GitHub username):

| Download | Link |
|---|---|
| Mac (Apple chip: M1–M5, MacBook Neo) | `https://github.com/YOUR-USERNAME/notch-tutor/releases/latest/download/NotchTutor-Mac-arm64.dmg` |
| Mac (Intel) | `https://github.com/YOUR-USERNAME/notch-tutor/releases/latest/download/NotchTutor-Mac-x64.dmg` |
| Windows (installer) | `https://github.com/YOUR-USERNAME/notch-tutor/releases/latest/download/NotchTutor-Windows-Setup.exe` |
| Windows (no install) | `https://github.com/YOUR-USERNAME/notch-tutor/releases/latest/download/NotchTutor-Windows-Portable.exe` |

`latest/download` always points at your newest build: whenever you change the app, upload the changed files and run the workflow again, and the same links serve the new version.

Website buttons you can paste:

```html
<a href="https://github.com/YOUR-USERNAME/notch-tutor/releases/latest/download/NotchTutor-Mac-arm64.dmg">Download for Mac (Apple chip)</a>
<a href="https://github.com/YOUR-USERNAME/notch-tutor/releases/latest/download/NotchTutor-Mac-x64.dmg">Download for Mac (Intel)</a>
<a href="https://github.com/YOUR-USERNAME/notch-tutor/releases/latest/download/NotchTutor-Windows-Setup.exe">Download for Windows</a>
```

What to tell visitors: on Mac, the first launch shows a warning; click **Done**, then **System Settings → Privacy & Security → Open Anyway**. On Windows, SmartScreen may say "Windows protected your PC"; click **More info**, then **Run anyway**. Both warnings appear because the app isn't signed with a paid certificate. Each person needs their own free key from aistudio.google.com/apikey.

## Study hub

Click **Study hub** in the notch (it also opens automatically the first time). **Today** shows your exam countdown, streak, today's plan and next tasks. It also has these sections:

- **Your subjects.** Level, exam date, weekly hours, and for each subject the exam board, a confidence rating and the topics you find hardest.
- **Your handwriting.** Copy four pangrams, a–z, A–Z and 0–9 onto paper and photograph it. Gemini writes a profile of your letter shapes and easily-confused characters. The photo and profile are sent along with every piece of work you get marked, so your handwriting is read correctly.
- **Revision plan.** A weekly schedule plus concrete tasks per topic, with tick boxes and revision links.
- **Mark my work.** Upload photos, PDFs or iPhone HEIC files, paste screenshots, or use the camera. Add the question and mark scheme for more accurate marking. Results come back as a red-pen marked page: score, what you got right, each mistake with the correction, how to improve, and what to revise next.
- **Quick quiz.** Multiple-choice questions on any topic (suggested from your weak topics and past mistakes), with an explanation after every answer.
- **Progress.** Average score per subject across marks and quizzes, topics that keep coming up, and your full history.
- **Settings.** Talk mode and key, voice, teaching style, the notch face, screen detail, open at startup, your Gemini key, deleting your data, and About.

The model never writes URLs, so revision links can't be dead: it picks a site from a fixed list (BBC Bitesize, YouTube, Khan Academy, Save My Exams, Physics & Maths Tutor, Corbettmaths, Maths Genie, Seneca, Cognito and others) plus a search phrase, and the app builds the link. The voice tutor in the notch also receives your subjects, weak topics, handwriting profile and recent marks.

All study data is stored in the app's data folder (`~/Library/Application Support/Notch Tutor/study.json` on macOS). Non-realtime requests use `GEMINI_TEXT_MODEL` if set, otherwise the first available of `gemini-3.8-flash`, `gemini-3.6-flash`, `gemini-3.5-flash` and `gemini-2.5-flash`.

## Why Electron (not Tauri)

Both were considered. Electron wins for this app because every hard requirement is a first-class, cross-platform Electron API backed by the *same* Chromium on every OS:

| Requirement | Electron | Tauri |
|---|---|---|
| Screen capture without a picker | `setDisplayMediaRequestHandler` + `desktopCapturer` | Different webview per OS (WKWebView / WebView2 / WebKitGTK); `getDisplayMedia` behaviour and permission prompts differ, often requiring a native Rust capture crate |
| AudioWorklet + 16/24 kHz AudioContexts + AEC | Identical Chromium audio stack everywhere | Varies by webview; WebKitGTK support is weakest |
| Transparent, click-through, always-on-top overlay | `setIgnoreMouseEvents({forward})`, `setAlwaysOnTop('screen-saver')`, `setContentProtection` | Possible, but click-through forwarding and capture exclusion need platform code |
| Low-latency WebSocket with backpressure | Node `ws` in main (TCP_NODELAY, no deflate, `bufferedAmount`) | Fine in Rust, but media must then cross the webview↔Rust IPC boundary as base64/JSON |

The trade-off is download size (~90–110 MB installer vs ~10 MB). For a realtime media app, predictable capture and audio behaviour matters more.

## Architecture

```
┌──────────────────── Renderer (sandboxed) ────────────────────┐      ┌─────────────── Main (Node) ───────────────┐
│ MicCapture   getUserMedia → AudioContext@16k → AudioWorklet  │      │ MediaBridge (MessagePortMain)             │
│              → PCM16 40 ms chunks ─────────────────────────┐ │ Port │   ↓ base64 once, right before the write   │
│ ScreenSampler getDisplayMedia(primary) → change-detect →   ├─┼─────▶│ GeminiLiveSession (ws, TCP_NODELAY)       │──wss──▶ Gemini Live
│              → downscale 1280px → JPEG (OffscreenCanvas) ──┘ │      │   setup / realtimeInput.audio|video       │
│ PcmPlayer    AudioWorklet ring buffer @24k ◀───────────────┐ │      │   resumption handles, goAway handover,    │◀─wss──
│              (60 ms prebuffer, instant flush on barge-in)  └─┼◀─────│   backoff reconnect, video backpressure   │
│ Pill UI      compact / peek / expanded                       │ IPC  │ window.ts  permissions.ts  credentials.ts │
└──────────────────────────────────────────────────────────────┘      └───────────────────────────────────────────┘
```

Key decisions: the API key and the socket live only in the main process; the renderer has no network access (enforced by CSP). High-frequency media uses a dedicated `MessageChannelMain`, not `ipcMain`. Audio is never dropped; video frames are dropped under socket backpressure so they can't delay audio on the shared TCP stream.

## Project layout

```
notch-tutor/
├─ electron.vite.config.ts        three bundles: main / preload / renderer
├─ electron-builder.yml           .dmg / .exe (NSIS + portable) / .AppImage
├─ build/entitlements.mac.plist   hardened runtime + microphone entitlement
├─ .env.example
└─ src/
   ├─ shared/protocol.ts          IPC channel names + message types (single source of truth)
   ├─ main/
   │  ├─ index.ts                 lifecycle, IPC (sender-validated), global shortcut
   │  ├─ window.ts                transparent always-on-top click-through notch window
   │  ├─ permissions.ts           TCC/Windows privacy + primary-screen display-media handler
   │  ├─ credentials.ts           env key (dev) / safeStorage-encrypted key (prod)
   │  ├─ bridge.ts                MessagePort data plane ↔ live session
   │  └─ live/GeminiLiveSession.ts  WebSocket protocol client
   ├─ preload/index.ts            typed window.notch API + MessagePort hand-off
   └─ renderer/
      ├─ index.html               strict CSP + pill markup
      └─ src/
         ├─ main.ts               orchestrator
         ├─ audio/worklets.ts     capture + playback AudioWorklet processors
         ├─ audio/MicCapture.ts
         ├─ audio/PcmPlayer.ts
         ├─ video/ScreenSampler.ts
         ├─ ui/Pill.ts
         └─ styles.css
```

## 1. Install

Prerequisites: Node.js 20.19+ or 22.12+ (required by Vite 7), npm 10+, Git. On Windows, nothing else is needed. On macOS, Xcode Command Line Tools (`xcode-select --install`) are needed only for signing.

```bash
git clone <your-repo> notch-tutor
cd notch-tutor
npm install          # downloads the Electron binary for your OS (~100 MB)
```

## 2. Configure environment variables

```bash
cp .env.example .env
```

Open `.env` and set `GEMINI_API_KEY` to a key from https://aistudio.google.com/apikey. The other values are optional:

| Variable | Default | Purpose |
|---|---|---|
| `GEMINI_API_KEY` | none | Dev only. Read by the main process when the app is not packaged. |
| `GEMINI_MODEL` | `gemini-3.8-live` | Live model id, no `models/` prefix. Update if Google supersedes it. |
| `GEMINI_VOICE` | server default | Prebuilt voice name. |
| `GEMINI_MEDIA_RESOLUTION` | `MEDIA_RESOLUTION_MEDIUM` | Token detail per frame. Use `HIGH` for small code/text. |
| `RENDERER_VITE_SCREEN_INTERVAL_MS` | `1000` | Frame cadence. Inlined at build time, so never put secrets in `RENDERER_VITE_*`. |

In packaged builds `.env` is ignored on purpose. The first time a user starts a session, the notch asks for their key and stores it encrypted with the OS keychain (`safeStorage`: macOS Keychain, Windows DPAPI, libsecret on Linux). `GEMINI_MODEL` and friends can still be set as real environment variables for packaged builds.

## 3. Run in development

```bash
npm run dev
```

A black pill appears at the top center of your primary display. Hover it to expand, click **Start session**, or press **⌘⇧Space** (macOS) / **Ctrl+Shift+Space** (Windows/Linux) from any app.

First-run permissions:

- **macOS:** approve the microphone prompt. For the screen, enable the app under System Settings → Privacy & Security → Screen & System Audio Recording, then quit and relaunch (macOS only applies this grant on relaunch). In dev the entry is named "Electron"; in the packaged app it's "Notch Tutor".
- **Windows:** make sure Settings → Privacy & security → Microphone → "Let desktop apps access your microphone" is on. Screen capture needs no permission.
- **Linux (Wayland):** the PipeWire portal shows a one-time screen chooser. X11 works without prompts.

Use headphones for the best barge-in behaviour. Echo cancellation is on and works well on laptop speakers, but headphones remove any chance of the tutor hearing itself.

## 4. Build the single-file installer

```bash
npm run dist:mac     # on a Mac   → release/NotchTutor-Mac-arm64.dmg and NotchTutor-Mac-x64.dmg
npm run dist:win     # on Windows → release/NotchTutor-Windows-Setup.exe (one-click) + release/NotchTutor-Windows-Portable.exe
npm run dist:linux   # on Linux   → release/Notch Tutor-1.0.0.AppImage
```

Each script typechecks, builds the three bundles, then packages them. Notes:

- A `.dmg` can only be built on macOS. A Windows `.exe` is best built on Windows (or on macOS/Linux with Wine installed). CI runners (`macos-latest`, `windows-latest`) are the usual way to produce both.
- Add icons as `build/icon.icns` (mac), `build/icon.ico` (win) and `build/icon.png` (512×512, linux). Without them electron-builder uses the default Electron icon.
- The portable `.exe` is a true single file with nothing to install. It unpacks to a temp folder on each launch, so startup is a second or two slower than the NSIS install.

### Signing & notarization (required for public distribution)

**macOS.** Unsigned apps are blocked by Gatekeeper, and hardened-runtime apps without the `audio-input` entitlement receive silent microphone audio. With an Apple Developer account:

```bash
export CSC_LINK=/path/to/DeveloperID_Application.p12
export CSC_KEY_PASSWORD='p12-password'
export APPLE_ID='you@example.com'
export APPLE_APP_SPECIFIC_PASSWORD='xxxx-xxxx-xxxx-xxxx'
export APPLE_TEAM_ID='ABCDE12345'
```

Then set `mac.notarize: true` in `electron-builder.yml` and run `npm run dist:mac`.

**Windows.** Set `CSC_LINK` / `CSC_KEY_PASSWORD` to your code-signing certificate (or configure Azure Trusted Signing in `electron-builder.yml`). Unsigned installers work but show a SmartScreen warning.

## Wire protocol reference (Gemini Live, v1beta)

Endpoint (API-key auth as a query parameter):

```
wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=API_KEY
```

Each client message has exactly one top-level field. The first must be `setup`; send nothing else until `setupComplete` arrives.

```jsonc
// → 1. setup (see GeminiLiveSession.buildSetup)
{ "setup": {
    "model": "models/gemini-3.8-live",
    "generationConfig": { "responseModalities": ["AUDIO"], "mediaResolution": "MEDIA_RESOLUTION_MEDIUM" },
    "systemInstruction": { "parts": [{ "text": "You are Notch, a patient tutor…" }] },
    "realtimeInputConfig": {
      "automaticActivityDetection": { "disabled": false },
      "activityHandling": "START_OF_ACTIVITY_INTERRUPTS",
      "turnCoverage": "TURN_INCLUDES_AUDIO_ACTIVITY_AND_ALL_VIDEO"
    },
    "inputAudioTranscription": {}, "outputAudioTranscription": {},
    "contextWindowCompression": { "slidingWindow": {} },
    "sessionResumption": {}            // or { "handle": "<last newHandle>" } on reconnect
} }
// ← { "setupComplete": {} }

// → 2. microphone, every 40 ms (PCM16 LE mono 16 kHz, base64)
{ "realtimeInput": { "audio": { "data": "AAEC…", "mimeType": "audio/pcm;rate=16000" } } }

// → 3. screen, ~1/s when changed (JPEG, base64) – same socket, parallel stream
{ "realtimeInput": { "video": { "data": "/9j/4AAQ…", "mimeType": "image/jpeg" } } }

// → 4. mic muted
{ "realtimeInput": { "audioStreamEnd": true } }

// ← audio out (PCM16 LE mono 24 kHz)
{ "serverContent": { "modelTurn": { "parts": [{ "inlineData": { "mimeType": "audio/pcm;rate=24000", "data": "…" } }] } } }
// ← { "serverContent": { "interrupted": true } }      flush playback now
// ← { "serverContent": { "turnComplete": true } }     drain remaining audio
// ← { "serverContent": { "outputTranscription": { "text": "…" } } }
// ← { "sessionResumptionUpdate": { "newHandle": "…", "resumable": true } }
// ← { "goAway": { "timeLeft": "10s" } }               reconnect with handle now
```

Audio and video are independent realtime streams inside one session; the server aligns them, so there is no manual interleaving or timestamping. The server sends JSON in binary WebSocket frames, which `parseMessage` handles.

## Latency budget (typical, wired broadband)

| Stage | Cost |
|---|---|
| Mic capture quantum + 40 ms chunk | ~45 ms |
| Worklet → MessagePort → main → socket | < 2 ms |
| Network + server VAD end-of-speech | 300–600 ms (dominant; tune `silenceDurationMs` if needed) |
| First audio byte → speaker (60 ms prebuffer + output device) | ~70–90 ms |
| Barge-in: `interrupted` → silence | one render quantum (~5 ms) |

Things that keep it low: TCP_NODELAY, no permessage-deflate, base64 done once with native `Buffer`, audio never queued behind video, unchanged screens skipped, a fresh frame forced at speech onset, `backgroundThrottling: false`, and connecting while devices spin up.

## Production hardening checklist

- **Don't ship your own key.** For a public app, run a small backend that mints Gemini ephemeral tokens (`AuthTokenService.CreateToken`), fetch one in `startSession()` and pass it as `ephemeralToken` instead of `apiKey`. `GeminiLiveSession` then connects to the `BidiGenerateContentConstrained` endpoint with `access_token=…`. Tokens expire quickly and can lock the model and config server-side. Fetch a fresh token before each reconnect if yours are single-use.
- Keep `contextIsolation`, `sandbox` and the CSP as they are. IPC handlers already reject calls from anything but the notch's own frame.
- Screen frames can contain sensitive data. Consider an app deny-list (pause capture while a password manager or banking site is focused) and a visible indicator whenever frames are being sent (the dot colour does this now).
- Enable auto-update with `electron-updater` and a `publish` block in `electron-builder.yml`.

## Swapping in another realtime provider

Everything provider-specific lives in `src/main/live/GeminiLiveSession.ts`. To add OpenAI's Realtime API, create a sibling class with the same public surface (`start`, `stop`, `isReady`, `sendAudio`, `sendFrame`, `sendAudioStreamEnd`, `sendText`, and the `audio` / `interrupted` / `turnComplete` / `transcript` / `state` events), then choose the class in `startSession()` in `src/main/index.ts`. Two differences to plan for: OpenAI's realtime audio defaults to 24 kHz input, so either resample in `sendAudio` or create the capture `AudioContext` at 24 kHz; and images are sent as conversation items rather than a continuous video stream, so send a frame when the user starts speaking rather than every second. Check OpenAI's current Realtime docs for exact event names before implementing.

## Troubleshooting

| Symptom | Fix |
|---|---|
| Pill appears but frames are black (macOS) | Screen Recording permission not granted, or granted without relaunching. Toggle it on and quit/reopen. |
| Mic works in dev, silent in the signed build (macOS) | Missing `com.apple.security.device.audio-input` entitlement or `NSMicrophoneUsageDescription`. Both are in this repo; check the build used them. |
| "Gemini rejected this API key" | The notch reopens the key field; paste a valid key. In dev, fix `GEMINI_API_KEY` in `.env` (it takes priority over the stored key). |
| "That Live model isn't available" | Set `GEMINI_MODEL` to a current Live model from the Gemini docs. |
| Tutor interrupts itself on speakers | Use headphones, or lower speaker volume. The OS may also be applying its own voice processing. |
| Pill hidden behind the menu bar (macOS) | Some menu-bar managers force their own level. Move the window lower in `topCenterOfPrimary()` (`y: d.workArea.y`). |
| Global shortcut doesn't fire | Another app owns it. Change `TOGGLE_SHORTCUT` in `src/main/index.ts`. |
