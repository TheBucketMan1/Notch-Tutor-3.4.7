/**
 * electron-vite build config.
 *
 * electron-vite compiles three independent bundles:
 *   out/main      – Node/Electron main process (owns the WebSocket + API key)
 *   out/preload   – sandboxed bridge (CommonJS, only imports `electron`)
 *   out/renderer  – the notch UI + media capture (plain browser code)
 *
 * Entry points follow electron-vite conventions (src/main/index.ts,
 * src/preload/index.ts, src/renderer/index.html), so only non-default
 * settings live here.
 */
import { resolve } from 'node:path'
import { defineConfig } from 'electron-vite'

export default defineConfig({
  main: {
    build: {
      // `ws` stays in node_modules (it has optional native speedups);
      // dotenv is a devDependency and gets bundled, so it never ships unused.
      externalizeDeps: true,
      sourcemap: true
    },
    resolve: { alias: { '@shared': resolve(__dirname, 'src/shared') } }
  },
  preload: {
    build: { externalizeDeps: true, sourcemap: true },
    resolve: { alias: { '@shared': resolve(__dirname, 'src/shared') } }
  },
  renderer: {
    resolve: { alias: { '@shared': resolve(__dirname, 'src/shared') } },
    build: {
      target: 'chrome130', // Electron 44 ships a far newer Chromium; this just avoids down-levelling
      sourcemap: true,
      rollupOptions: {
        // Two pages: the notch overlay and the study hub window.
        input: {
          index: resolve(__dirname, 'src/renderer/index.html'),
          study: resolve(__dirname, 'src/renderer/study.html')
        }
      }
    }
  }
})
