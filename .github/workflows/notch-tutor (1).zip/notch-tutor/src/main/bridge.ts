/**
 * MediaBridge – the zero-routing data plane between renderer and socket.
 *
 *   renderer AudioWorklet ──(MessagePort, ArrayBuffer)──▶ MediaBridge ──▶ GeminiLiveSession ──▶ wss
 *   renderer PcmPlayer    ◀─(MessagePort, ArrayBuffer)── MediaBridge ◀── GeminiLiveSession ◀── wss
 *
 * A MessageChannelMain avoids ipcMain's channel lookup and per-message
 * listener fan-out, and keeps high-frequency traffic off the control plane.
 */
import { MessageChannelMain, type MessagePortMain, type WebContents } from 'electron'
import { IPC, type MainToRenderer, type RendererToMain } from '@shared/protocol'
import type { GeminiLiveSession } from './live/GeminiLiveSession'

export class MediaBridge {
  private port: MessagePortMain | null = null
  private session: GeminiLiveSession | null = null
  private unbind: Array<() => void> = []

  /** (Re)creates the channel and hands one end to the renderer. Safe on reload. */
  attachRenderer(wc: WebContents): void {
    this.port?.close()
    const { port1, port2 } = new MessageChannelMain()
    this.port = port1
    port1.on('message', (e) => this.onRendererMessage(e.data as RendererToMain))
    port1.start()
    wc.postMessage(IPC.mediaPort, null, [port2])
  }

  bindSession(session: GeminiLiveSession): void {
    this.unbindSession()
    this.session = session

    const onAudio = (pcm: Buffer): void => this.post({ t: 'audio', buf: toStandaloneArrayBuffer(pcm) })
    const onInterrupted = (): void => this.post({ t: 'interrupted' })
    const onTurnComplete = (): void => this.post({ t: 'turnComplete' })
    const onTranscript = (role: 'user' | 'tutor', text: string): void => this.post({ t: 'transcript', role, text })

    session.on('audio', onAudio)
    session.on('interrupted', onInterrupted)
    session.on('turnComplete', onTurnComplete)
    session.on('transcript', onTranscript)
    this.unbind = [
      () => session.off('audio', onAudio),
      () => session.off('interrupted', onInterrupted),
      () => session.off('turnComplete', onTurnComplete),
      () => session.off('transcript', onTranscript)
    ]
  }

  /** Shows a question with a typing bar in the notch. */
  postQuestion(question: string, hint: string): void {
    this.post({ t: 'question', question, hint })
  }

  unbindSession(): void {
    for (const fn of this.unbind) fn()
    this.unbind = []
    this.session = null
  }

  private post(msg: MainToRenderer): void {
    this.port?.postMessage(msg)
  }

  private onRendererMessage(msg: RendererToMain): void {
    const s = this.session
    if (!s || !s.isReady) return // drop media until setupComplete (never queue stale audio)
    switch (msg.t) {
      case 'audio':
        s.sendAudio(toBuffer(msg.buf))
        break
      case 'frame':
        s.sendFrame(toBuffer(msg.buf))
        break
      case 'audioEnd':
        s.sendAudioStreamEnd()
        break
      case 'activityStart':
        s.sendActivityStart()
        break
      case 'activityEnd':
        s.sendActivityEnd()
        break
      case 'text':
        if (msg.text.trim()) s.sendText(msg.text.trim())
        break
    }
  }
}

/** Structured clone may deliver ArrayBuffer or a typed-array view; normalise without copying. */
function toBuffer(data: unknown): Buffer {
  if (data instanceof ArrayBuffer) return Buffer.from(data)
  if (ArrayBuffer.isView(data)) return Buffer.from(data.buffer, data.byteOffset, data.byteLength)
  throw new TypeError('Expected binary payload from renderer')
}

/**
 * Small Buffers share Node's 8 KB slab; posting `buf.buffer` would clone the
 * whole slab. Slice out exactly our bytes.
 */
function toStandaloneArrayBuffer(buf: Buffer): ArrayBuffer {
  return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) as ArrayBuffer
}
