/**
 * API key resolution & storage (main process only).
 *
 * Resolution order:
 *   1. GEMINI_API_KEY env var  – development (.env is loaded only when unpackaged)
 *   2. Encrypted key file      – production; encrypted with Electron safeStorage,
 *                                which is backed by macOS Keychain / Windows DPAPI /
 *                                libsecret-kwallet on Linux.
 *
 * We deliberately NEVER bake a key into the binary: anything inside an asar is
 * trivially extractable. For a commercial distribution, replace this with a
 * short-lived "ephemeral token" minted by your backend (see README).
 */
import { app, safeStorage } from 'electron'
import { promises as fs } from 'node:fs'
import { join } from 'node:path'
import type { KeySource } from '@shared/protocol'

const keyPath = (): string => join(app.getPath('userData'), 'gemini-key.bin')
/** Fallback when the OS keychain is unavailable: plain file readable only by this user. */
const plainKeyPath = (): string => join(app.getPath('userData'), 'gemini-key.txt')

let cached: { key: string; source: KeySource } | null = null

export async function resolveApiKey(): Promise<{ key: string | null; source: KeySource }> {
  if (cached) return cached

  const envKey = process.env.GEMINI_API_KEY?.trim()
  if (envKey) return (cached = { key: envKey, source: 'env' })

  try {
    const blob = await fs.readFile(keyPath())
    if (safeStorage.isEncryptionAvailable()) {
      const key = safeStorage.decryptString(blob).trim()
      if (key) return (cached = { key, source: 'keychain' })
    }
  } catch {
    /* no encrypted key, or the keychain entry belongs to an older build */
  }
  try {
    const key = (await fs.readFile(plainKeyPath(), 'utf8')).trim()
    if (key) return (cached = { key, source: 'keychain' })
  } catch {
    /* no stored key yet */
  }
  return { key: null, source: 'none' }
}

export async function storeApiKey(raw: string): Promise<void> {
  const key = raw.trim()
  // Google AI Studio keys are ~39 chars of [A-Za-z0-9_-]. Loose check only –
  // the real validation is the server accepting our setup message.
  if (!/^[A-Za-z0-9_.\-]{20,400}$/.test(key)) {
    throw new Error('That doesn’t look like a Gemini API key. Copy it again from AI Studio.')
  }
  await fs.mkdir(app.getPath('userData'), { recursive: true })
  if (safeStorage.isEncryptionAvailable()) {
    await fs.writeFile(keyPath(), safeStorage.encryptString(key), { mode: 0o600 })
    await fs.rm(plainKeyPath(), { force: true })
  } else {
    // Keychain refused (common with unsigned builds that change signature on
    // every rebuild). Store in a file only this macOS user can read.
    await fs.writeFile(plainKeyPath(), key, { mode: 0o600 })
    await fs.chmod(plainKeyPath(), 0o600)
  }
  cached = { key, source: 'keychain' }
}

export async function clearApiKey(): Promise<void> {
  cached = null
  await fs.rm(keyPath(), { force: true })
  await fs.rm(plainKeyPath(), { force: true })
}
