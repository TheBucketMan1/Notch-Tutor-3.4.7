/**
 * Main process entry.
 *
 * Responsibilities:
 *   • single-instance, agent-style app (no Dock icon on macOS)
 *   • notch window + click-through control
 *   • OS/Chromium media permissions
 *   • owns the API key and the Gemini Live WebSocket
 *   • control-plane IPC (validated sender) + data-plane MessagePort
 */
import { app, BrowserWindow, globalShortcut, ipcMain, shell, type IpcMainEvent, type IpcMainInvokeEvent } from 'electron'
import { config as loadDotenv } from 'dotenv'
import { IPC, type SessionState, type StartResult } from '@shared/protocol'
import { createNotchWindow, setWindowInteractive } from './window'
import { ensureCameraPermission, ensureMediaPermissions, installMediaHandlers } from './permissions'
import { getHub, openStudyHub } from './studyWindow'
import { getOpenAtLogin, setOpenAtLogin } from './loginItem'
import { getSettings, onSettingsChanged, updateSettings } from './settings'
import * as ptt from './pushToTalk'
import { buildLinks, SITE_KEYS } from './study/links'
import type { FunctionCall, FunctionDeclaration } from './live/GeminiLiveSession'
import type { AppSettings } from '@shared/study'
import * as study from './study/service'
import { STUDY_IPC } from '@shared/study'
import { clearApiKey, resolveApiKey, storeApiKey } from './credentials'
import { GeminiLiveSession, type MediaResolution } from './live/GeminiLiveSession'
import { MediaBridge } from './bridge'

// .env is a developer convenience only. Packaged apps use the keychain.
if (!app.isPackaged) loadDotenv()

// Keep the renderer's audio + timers at full priority when occluded.
app.commandLine.appendSwitch('disable-renderer-backgrounding')
app.commandLine.appendSwitch('disable-background-timer-throttling')

const TOGGLE_SHORTCUT = 'CommandOrControl+Shift+Space'

/**
 * Tools the voice tutor can use. These are the safe, free "agentic" actions:
 * showing a question to type into, opening revision pages, opening the hub.
 */
const TUTOR_FUNCTIONS: FunctionDeclaration[] = [
  {
    name: 'show_question',
    description:
      'Show a question at the top of the student’s screen with a box to type their answer. Use this whenever you ask the student a question to check their understanding, in addition to saying it.',
    parameters: {
      type: 'OBJECT',
      properties: {
        question: { type: 'STRING', description: 'The exact question, short enough to read at a glance.' },
        hint: { type: 'STRING', description: 'Optional short hint, or empty.' }
      },
      required: ['question']
    }
  },
  {
    name: 'open_revision_link',
    description: 'Open a revision page in the student’s web browser, e.g. when they ask for a video, notes or practice questions.',
    parameters: {
      type: 'OBJECT',
      properties: {
        site: { type: 'STRING', description: 'Which site to search.', enum: SITE_KEYS },
        query: { type: 'STRING', description: '3-6 plain words, e.g. "edexcel gcse quadratics questions". Never a page title or URL.' }
      },
      required: ['site', 'query']
    }
  },
  {
    name: 'open_study_hub',
    description: 'Open the student’s study hub (their subjects, revision plan, marking and quizzes).',
    parameters: {
      type: 'OBJECT',
      properties: {
        section: { type: 'STRING', enum: ['today', 'plan', 'mark', 'quiz', 'progress'], description: 'Which section to show.' }
      }
    }
  }
]

const TOOL_GUIDE = `
Tools:
- Whenever you ask the student a question to check understanding, ALSO call show_question with that question so they can type an answer. Typed answers arrive as text starting with "My answer to your question". Give specific feedback on it.
- If they ask for a video, notes, practice or past papers, call open_revision_link.
- If they want to see their plan, get work marked or do a quiz, call open_study_hub.
`

const STYLE_GUIDE: Record<AppSettings['tutorStyle'], string> = {
  guide: 'Style: guide with hints and questions first; give the full answer if they ask for it or are stuck after trying.',
  direct: 'Style: explain answers clearly and directly, step by step, then check understanding with one quick question.'
}

const SYSTEM_INSTRUCTION = `
You are Notch, a patient, sharp one-on-one tutor who lives in the user's screen notch.
You continuously receive frames of the user's primary screen and hear their voice.

How to tutor:
- Ground every answer in what is visible on screen right now. Refer to concrete things you see
  ("the error on line 42", "the second equation", "the red cell in column C").
- Prefer guiding over telling: ask one short question or give one hint, then let them try.
  Give the full answer when they ask for it directly or are clearly stuck after trying.
- Speak like a person: short sentences, no lists, no markdown, no reading out URLs or long code.
  Keep most replies under 20 seconds of speech.
- If the screen is unreadable or irrelevant to the question, say so and ask them to zoom or scroll.
- Stay silent about screen content that is private and unrelated to the question (messages, passwords).
`.trim()

let win: BrowserWindow | null = null
let live: GeminiLiveSession | null = null
const bridge = new MediaBridge()

// ─────────────────────────── single instance ───────────────────────────
if (!app.requestSingleInstanceLock()) {
  app.quit()
} else {
  app.on('second-instance', () => win?.showInactive())
  void app.whenReady().then(bootstrap)
}

function isTrustedUrl(url: string): boolean {
  if (!url) return false
  const devUrl = process.env.ELECTRON_RENDERER_URL
  if (devUrl && url.startsWith(new URL(devUrl).origin)) return true
  return url.startsWith('file://')
}

/** Only our own top-level renderer may use IPC (defence in depth). */
function isFromOurWindow(e: IpcMainInvokeEvent | IpcMainEvent): boolean {
  return Boolean(win && e.sender === win.webContents && isTrustedUrl(e.senderFrame?.url ?? ''))
}

/** For invoke handlers: throwing rejects the renderer's promise. */
function assertSender(e: IpcMainInvokeEvent): void {
  if (!isFromOurWindow(e)) throw new Error('Untrusted IPC sender')
}

/** Study APIs may be called from the study hub OR the notch. */
function isFromStudyCaller(e: IpcMainInvokeEvent | IpcMainEvent): boolean {
  const hub = getHub()
  const fromHub = Boolean(hub && e.sender === hub.webContents && isTrustedUrl(e.senderFrame?.url ?? ''))
  return fromHub || isFromOurWindow(e)
}

function assertStudyCaller(e: IpcMainInvokeEvent): void {
  if (!isFromStudyCaller(e)) throw new Error('Untrusted IPC sender')
}

function pushState(state: SessionState, detail?: string): void {
  win?.webContents.send(IPC.sessionState, { state, detail })
}

async function bootstrap(): Promise<void> {
  if (process.platform === 'darwin') app.dock?.hide()

  installMediaHandlers(isTrustedUrl)
  win = createNotchWindow()

  // Renderer reloaded (HMR/crash recovery) → tear down the session cleanly.
  win.webContents.on('did-start-loading', () => stopSession())
  win.webContents.on('render-process-gone', () => stopSession())

  registerIpc()

  const ok = globalShortcut.register(TOGGLE_SHORTCUT, () => win?.webContents.send(IPC.shortcutToggle))
  if (!ok) console.warn(`[main] ${TOGGLE_SHORTCUT} is taken by another app`)

  // Push-to-talk: listen for the chosen key while hold mode is on.
  const applyPtt = (s: AppSettings): Promise<unknown> =>
    ptt.configure({
      hold: s.talkMode === 'hold',
      keycode: s.pttKeycode,
      onKey: (down) => win?.webContents.send(IPC.ptt, down)
    })
  await applyPtt(await getSettings())
  onSettingsChanged((s) => void applyPtt(s))

  // First run: open the study hub so the student can set up their subjects.
  const s = await study.getState()
  if (!s.profile) openStudyHub()
}

function registerIpc(): void {
  // Fire-and-forget channels: silently ignore untrusted senders (throwing
  // inside an ipcMain.on listener would surface as an uncaught exception).
  ipcMain.on(IPC.mediaPortRequest, (e) => {
    if (!isFromOurWindow(e)) return
    bridge.attachRenderer(e.sender)
  })

  ipcMain.handle(IPC.sessionStart, async (e): Promise<StartResult> => {
    assertSender(e)
    return startSession()
  })

  ipcMain.handle(IPC.sessionStop, (e) => {
    assertSender(e)
    stopSession()
  })

  ipcMain.handle(IPC.keyStatus, async (e) => {
    assertSender(e)
    const { key, source } = await resolveApiKey()
    return { hasKey: Boolean(key), source }
  })

  ipcMain.handle(IPC.keySet, async (e, key: unknown) => {
    assertSender(e)
    if (typeof key !== 'string') return { ok: false, error: 'Invalid key.' }
    try {
      await storeApiKey(key)
      return { ok: true }
    } catch (err) {
      return { ok: false, error: (err as Error).message }
    }
  })

  ipcMain.handle(IPC.keyClear, async (e) => {
    assertSender(e)
    stopSession()
    await clearApiKey()
  })

  ipcMain.handle(IPC.permEnsure, async (e) => {
    assertSender(e)
    return ensureMediaPermissions()
  })

  ipcMain.on(IPC.windowInteractive, (e, interactive: unknown, wantsKeyboard: unknown) => {
    if (!isFromOurWindow(e)) return
    if (win) setWindowInteractive(win, interactive === true, wantsKeyboard === true)
  })

  ipcMain.on(IPC.quit, (e) => {
    if (!isFromOurWindow(e)) return
    app.quit()
  })

  // ── Study hub ──
  ipcMain.on(STUDY_IPC.open, (e) => {
    if (!isFromStudyCaller(e)) return
    openStudyHub()
  })
  ipcMain.handle(STUDY_IPC.getState, (e) => {
    assertStudyCaller(e)
    return study.getState()
  })
  ipcMain.handle(STUDY_IPC.saveProfile, (e, p) => {
    assertStudyCaller(e)
    return study.saveProfile(p)
  })
  ipcMain.handle(STUDY_IPC.analyzeHandwriting, (e, f) => {
    assertStudyCaller(e)
    return study.analyzeHandwriting(f)
  })
  ipcMain.handle(STUDY_IPC.generatePlan, (e) => {
    assertStudyCaller(e)
    return study.generatePlan()
  })
  ipcMain.handle(STUDY_IPC.setTaskDone, (e, id: string, done: boolean) => {
    assertStudyCaller(e)
    return study.setTaskDone(id, done)
  })
  ipcMain.handle(STUDY_IPC.markWork, (e, req) => {
    assertStudyCaller(e)
    return study.markWork(req)
  })
  ipcMain.handle(STUDY_IPC.deleteHistory, (e, id: string) => {
    assertStudyCaller(e)
    return study.deleteHistoryItem(id)
  })
  ipcMain.handle(STUDY_IPC.ensureCamera, (e) => {
    assertStudyCaller(e)
    return ensureCameraPermission()
  })
  ipcMain.handle(STUDY_IPC.getOpenAtLogin, (e) => {
    assertStudyCaller(e)
    return getOpenAtLogin()
  })
  ipcMain.handle(STUDY_IPC.setOpenAtLogin, (e, on: unknown) => {
    assertStudyCaller(e)
    return setOpenAtLogin(on === true)
  })
  ipcMain.handle(STUDY_IPC.makeQuiz, (e, req) => {
    assertStudyCaller(e)
    return study.makeQuiz(req)
  })
  ipcMain.handle(STUDY_IPC.saveQuiz, (e, r) => {
    assertStudyCaller(e)
    return study.saveQuizResult(r)
  })
  ipcMain.handle(STUDY_IPC.deleteAll, (e) => {
    assertStudyCaller(e)
    return study.deleteAllData()
  })
  ipcMain.handle(STUDY_IPC.getSettings, async (e) => {
    assertStudyCaller(e)
    return { ...(await getSettings()), appVersion: app.getVersion() }
  })
  ipcMain.handle(STUDY_IPC.updateSettings, (e, patch: Partial<AppSettings>) => {
    assertStudyCaller(e)
    return updateSettings(patch && typeof patch === 'object' ? patch : {})
  })
  ipcMain.handle(STUDY_IPC.recordKey, (e) => {
    assertStudyCaller(e)
    return ptt.recordNextKey()
  })
  ipcMain.handle(STUDY_IPC.accessibility, async (e) => {
    assertStudyCaller(e)
    // If permission was just granted, start listening straight away.
    const s = await getSettings()
    return ptt.configure({ hold: s.talkMode === 'hold', keycode: s.pttKeycode, onKey: (down) => win?.webContents.send(IPC.ptt, down) })
  })
  ipcMain.handle(STUDY_IPC.requestAccessibility, (e) => {
    assertStudyCaller(e)
    return ptt.requestAccessibility()
  })
  ipcMain.handle(STUDY_IPC.keyStatus, async (e) => {
    assertStudyCaller(e)
    const { key, source } = await resolveApiKey()
    return { hasKey: Boolean(key), source }
  })
  ipcMain.handle(STUDY_IPC.setApiKey, async (e, key: unknown) => {
    assertStudyCaller(e)
    if (typeof key !== 'string') return { ok: false, error: 'Invalid key.' }
    try {
      await clearApiKey()
      await storeApiKey(key)
      return { ok: true }
    } catch (err) {
      return { ok: false, error: (err as Error).message }
    }
  })
  ipcMain.handle(STUDY_IPC.removeApiKey, async (e) => {
    assertStudyCaller(e)
    stopSession()
    await clearApiKey()
  })
  ipcMain.on(STUDY_IPC.startTutor, (e) => {
    if (!isFromStudyCaller(e)) return
    win?.webContents.send(IPC.startRequest)
  })
  ipcMain.on(STUDY_IPC.openExternal, (e, url: unknown) => {
    if (!isFromStudyCaller(e)) return
    if (typeof url === 'string' && url.startsWith('https://')) void shell.openExternal(url)
  })
}

async function startSession(): Promise<StartResult> {
  if (live) return { ok: true }

  const { key } = await resolveApiKey()
  if (!key) return { ok: false, code: 'NO_KEY', error: 'Add your Gemini API key to start.' }

  const settings = await getSettings()
  const context = await study.tutorContext().catch(() => '')
  const makeSession = (voice: string | undefined): GeminiLiveSession =>
    new GeminiLiveSession({
      apiKey: key,
      model: process.env.GEMINI_MODEL?.trim() || 'gemini-3.8-live',
      voiceName: voice,
      mediaResolution:
        (process.env.GEMINI_MEDIA_RESOLUTION?.trim() as MediaResolution) ||
        (settings.screenDetail === 'sharp' ? 'MEDIA_RESOLUTION_HIGH' : 'MEDIA_RESOLUTION_MEDIUM'),
      // The live tutor knows the student's subjects, weak topics and handwriting.
      systemInstruction: `${SYSTEM_INSTRUCTION}\n${STYLE_GUIDE[settings.tutorStyle]}\n${TOOL_GUIDE}${context}`,
      functions: TUTOR_FUNCTIONS,
      manualActivity: settings.talkMode === 'hold'
    })

  const voice = process.env.GEMINI_VOICE?.trim() || settings.voice || undefined
  const first = await connectSession(makeSession(voice))
  // If a chosen voice isn't available any more, fall back to the default voice.
  if (!first.ok && voice && first.code === 'CONNECT') return connectSession(makeSession(undefined))
  return first
}

async function connectSession(session: GeminiLiveSession): Promise<StartResult> {
  live = session
  session.on('toolCall', (calls) => void handleToolCalls(session, calls))

  session.on('state', (state, detail) => {
    if (live !== session) return
    pushState(state, detail)
    if (state === 'error') {
      bridge.unbindSession()
      live = null
    }
  })

  bridge.bindSession(session)
  try {
    await session.start()
    return { ok: true }
  } catch (err) {
    bridge.unbindSession()
    session.removeAllListeners()
    session.stop()
    if (live === session) live = null
    const { message, badKey } = humanizeConnectError(err as Error)
    return { ok: false, code: badKey ? 'BAD_KEY' : 'CONNECT', error: message }
  }
}

let lastLinkOpenedAt = 0

async function handleToolCalls(session: GeminiLiveSession, calls: FunctionCall[]): Promise<void> {
  const responses = await Promise.all(
    calls.map(async (c) => {
      try {
        return { id: c.id, name: c.name, response: await runTool(c) }
      } catch (err) {
        return { id: c.id, name: c.name, response: { error: (err as Error).message } }
      }
    })
  )
  if (live === session) session.sendToolResponse(responses)
}

async function runTool(c: FunctionCall): Promise<Record<string, unknown>> {
  const a = c.args
  switch (c.name) {
    case 'show_question': {
      const question = typeof a.question === 'string' ? a.question.trim().slice(0, 400) : ''
      if (!question) return { error: 'question is empty' }
      bridge.postQuestion(question, typeof a.hint === 'string' ? a.hint.slice(0, 200) : '')
      return { shown: true, note: 'The student can type an answer or just speak.' }
    }
    case 'open_revision_link': {
      // Guard against the model opening lots of tabs in a row.
      if (Date.now() - lastLinkOpenedAt < 8000) return { opened: false, reason: 'A page was just opened; wait before opening another.' }
      const [link] = buildLinks([{ site: a.site, query: a.query }], 1)
      if (!link) return { opened: false, reason: 'No query given.' }
      lastLinkOpenedAt = Date.now()
      await shell.openExternal(link.url)
      return { opened: true, page: link.label }
    }
    case 'open_study_hub': {
      const hub = openStudyHub()
      const section = typeof a.section === 'string' ? a.section : ''
      if (section) {
        const send = (): void => hub.webContents.send(STUDY_IPC.navigate, section)
        if (hub.webContents.isLoading()) hub.webContents.once('did-finish-load', send)
        else send()
      }
      return { opened: true }
    }
    default:
      return { error: `Unknown tool ${c.name}` }
  }
}

function stopSession(): void {
  const s = live
  if (!s) return
  live = null
  bridge.unbindSession()
  s.stop()
  s.removeAllListeners()
  pushState('idle')
}

function humanizeConnectError(err: Error): { message: string; badKey: boolean } {
  const m = err.message || ''
  if (/api key|API_KEY|unauthenticated|401|403/i.test(m))
    return { badKey: true, message: 'Gemini rejected this API key. Paste a valid key from AI Studio.' }
  if (/not found|not supported|model/i.test(m))
    return { badKey: false, message: 'That Live model isn’t available to this key. Set GEMINI_MODEL to a current Live model.' }
  if (/quota|429|RESOURCE_EXHAUSTED/i.test(m))
    return { badKey: false, message: 'Your Gemini quota is used up. Try again later or raise your limit.' }
  if (/ENOTFOUND|ECONNREFUSED|ETIMEDOUT|EAI_AGAIN|getaddrinfo/i.test(m))
    return { badKey: false, message: 'Can’t reach Gemini. Check your internet connection.' }
  return { badKey: false, message: m || 'Couldn’t connect to Gemini.' }
}

app.on('will-quit', () => {
  globalShortcut.unregisterAll()
  ptt.shutdown()
  stopSession()
})

app.on('window-all-closed', () => app.quit())
