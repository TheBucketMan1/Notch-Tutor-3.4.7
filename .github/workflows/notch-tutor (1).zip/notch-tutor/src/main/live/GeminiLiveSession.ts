/**
 * GeminiLiveSession – a single bidirectional Gemini Live API session over raw
 * WebSockets, running in the Electron MAIN process.
 *
 * Why raw `ws` instead of an SDK:
 *   • zero abstraction between our audio worklet and the socket write,
 *   • control over Nagle (TCP_NODELAY) and permessage-deflate (off: compressing
 *     base64 PCM/JPEG costs CPU and adds latency for ~0 gain),
 *   • access to `bufferedAmount` for backpressure-aware frame dropping.
 *
 * Wire protocol (v1beta BidiGenerateContent). Every client message is a JSON
 * object with EXACTLY ONE top-level field:
 *
 *   1) first message → { "setup": { model, generationConfig, systemInstruction,
 *                          realtimeInputConfig, sessionResumption, ... } }
 *      wait for       ← { "setupComplete": {} }
 *
 *   2) mic audio     → { "realtimeInput": { "audio": { "data": <b64 PCM16>,
 *                          "mimeType": "audio/pcm;rate=16000" } } }
 *   3) screen frame  → { "realtimeInput": { "video": { "data": <b64 JPEG>,
 *                          "mimeType": "image/jpeg" } } }
 *      (audio and video are independent parallel streams in ONE session;
 *       the server fuses them – no manual interleaving/timestamps needed)
 *   4) mic muted     → { "realtimeInput": { "audioStreamEnd": true } }
 *
 *   Server → client:
 *      { serverContent: { modelTurn: { parts: [{ inlineData: { mimeType:
 *          "audio/pcm;rate=24000", data: <b64> } }] } } }
 *      { serverContent: { interrupted: true } }     ← user barged in
 *      { serverContent: { turnComplete: true } }
 *      { serverContent: { inputTranscription | outputTranscription: { text } } }
 *      { sessionResumptionUpdate: { newHandle, resumable } }
 *      { goAway: { timeLeft } }                     ← server will disconnect soon
 */
import { EventEmitter } from 'node:events'
import WebSocket, { type RawData } from 'ws'
import type { SessionState } from '@shared/protocol'
import { AUDIO_IN_RATE } from '@shared/protocol'

const ENDPOINT =
  'wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent'
/** Endpoint for short-lived ephemeral tokens minted by your backend. */
const CONSTRAINED_ENDPOINT =
  'wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContentConstrained'

/** Max time from socket open to `setupComplete`. */
const SETUP_TIMEOUT_MS = 10_000
/** If this many bytes are queued in the socket, stop sending VIDEO (audio is never dropped). */
const VIDEO_BACKPRESSURE_BYTES = 384 * 1024
/** Reconnect policy for unexpected drops. */
const MAX_RECONNECT_ATTEMPTS = 6
const BACKOFF_BASE_MS = 250
const BACKOFF_MAX_MS = 5_000

export type MediaResolution = 'MEDIA_RESOLUTION_LOW' | 'MEDIA_RESOLUTION_MEDIUM' | 'MEDIA_RESOLUTION_HIGH'

export interface GeminiLiveOptions {
  /** Long-lived API key (dev / bring-your-own-key). Ignored if ephemeralToken is set. */
  apiKey?: string
  /**
   * Short-lived token from AuthTokenService.CreateToken, minted by YOUR backend.
   * Recommended for public distribution: no long-lived secret on the device.
   */
  ephemeralToken?: string
  /** Model id without the `models/` prefix, e.g. "gemini-3.8-live". */
  model: string
  systemInstruction: string
  voiceName?: string
  mediaResolution?: MediaResolution
  /** Override for a self-hosted relay/proxy or tests. Defaults to Google's endpoint. */
  endpoint?: string
  /** Function declarations the model may call (show a question, open a link, …). */
  functions?: FunctionDeclaration[]
  /**
   * Push-to-talk: turn off Gemini's automatic speech detection. The client
   * then marks each utterance with activityStart (key down) and activityEnd
   * (key up), and the model answers as soon as activityEnd arrives.
   */
  manualActivity?: boolean
}

export interface FunctionDeclaration {
  name: string
  description: string
  parameters?: { type: 'OBJECT'; properties: Record<string, { type: string; description?: string; enum?: string[] }>; required?: string[] }
}

export interface FunctionCall {
  id: string
  name: string
  args: Record<string, unknown>
}

/** Strongly-typed event map for consumers. */
export interface GeminiLiveEvents {
  state: [state: SessionState, detail?: string]
  audio: [pcm24k: Buffer]
  interrupted: []
  turnComplete: []
  transcript: [role: 'user' | 'tutor', text: string]
  toolCall: [calls: FunctionCall[]]
}

// Minimal shape of the server messages we consume (the API has more fields).
interface ServerMessage {
  setupComplete?: Record<string, never>
  serverContent?: {
    modelTurn?: { parts?: Array<{ inlineData?: { mimeType?: string; data?: string }; text?: string }> }
    interrupted?: boolean
    turnComplete?: boolean
    generationComplete?: boolean
    inputTranscription?: { text?: string }
    outputTranscription?: { text?: string }
  }
  sessionResumptionUpdate?: { newHandle?: string; resumable?: boolean }
  goAway?: { timeLeft?: string }
  toolCall?: { functionCalls?: Array<{ id?: string; name?: string; args?: Record<string, unknown> }> }
}

export class GeminiLiveSession extends EventEmitter<GeminiLiveEvents> {
  /** The socket currently carrying media (only swapped once a new one is ready). */
  private ws: WebSocket | null = null
  /** A socket mid-handshake during (re)connect; becomes `ws` on setupComplete. */
  private pending: WebSocket | null = null
  /** True only between `setupComplete` and close – gates every send. */
  private ready = false
  private closedByUser = false
  private reconnecting = false
  /** Latest resumable handle. Lets a reconnect continue the SAME conversation. */
  private resumeHandle: string | null = null
  private droppedFrames = 0

  constructor(private readonly opts: GeminiLiveOptions) {
    super()
  }

  // ───────────────────────────── lifecycle ─────────────────────────────

  /** Opens the socket and resolves once the server acknowledges setup. */
  async start(): Promise<void> {
    this.closedByUser = false
    this.emit('state', 'connecting')
    await this.open()
    this.emit('state', 'live')
  }

  /** Graceful user-initiated shutdown. Never triggers reconnect. */
  stop(): void {
    this.closedByUser = true
    const ws = this.ws
    this.ws = null
    this.ready = false
    this.resumeHandle = null
    this.pending?.terminate()
    this.pending = null
    if (ws) {
      try {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({ realtimeInput: { audioStreamEnd: true } }))
          ws.close(1000, 'client stop')
        } else {
          ws.terminate()
        }
      } catch {
        /* socket already gone */
      }
    }
    this.emit('state', 'idle')
  }

  get isReady(): boolean {
    return this.ready
  }

  // ───────────────────────────── sending ─────────────────────────────

  /** PCM16 LE mono @ 16 kHz. Never dropped (speech gaps break VAD & ASR). */
  sendAudio(pcm16k: Buffer): void {
    this.sendJson({
      realtimeInput: {
        audio: { data: pcm16k.toString('base64'), mimeType: `audio/pcm;rate=${AUDIO_IN_RATE}` }
      }
    })
  }

  /**
   * JPEG screen frame. Dropped under socket backpressure: a stale frame is
   * worthless, and queuing it would delay the audio behind it (head-of-line
   * blocking on a single TCP stream).
   */
  sendFrame(jpeg: Buffer): void {
    const ws = this.ws
    if (!ws || !this.ready) return
    if (ws.bufferedAmount > VIDEO_BACKPRESSURE_BYTES) {
      this.droppedFrames++
      if (this.droppedFrames % 10 === 1) console.warn(`[live] backpressure: dropped ${this.droppedFrames} frames`)
      return
    }
    this.sendJson({ realtimeInput: { video: { data: jpeg.toString('base64'), mimeType: 'image/jpeg' } } })
  }

  /** Tell server VAD the mic went quiet on purpose (mute) so it ends the turn now. */
  sendAudioStreamEnd(): void {
    if (this.opts.manualActivity) return // not used in push-to-talk mode
    this.sendJson({ realtimeInput: { audioStreamEnd: true } })
  }

  /** Push-to-talk: the user started speaking (also interrupts the model). */
  sendActivityStart(): void {
    if (this.opts.manualActivity) this.sendJson({ realtimeInput: { activityStart: {} } })
  }

  /** Push-to-talk: the user finished speaking; the model replies now. */
  sendActivityEnd(): void {
    if (this.opts.manualActivity) this.sendJson({ realtimeInput: { activityEnd: {} } })
  }

  /**
   * Typed message as a complete user turn. clientContent works in both
   * automatic and push-to-talk modes and always triggers a reply.
   */
  sendText(text: string): void {
    this.sendJson({ clientContent: { turns: [{ role: 'user', parts: [{ text }] }], turnComplete: true } })
  }

  /** Answers the model's function calls so it can carry on speaking. */
  sendToolResponse(responses: Array<{ id: string; name: string; response: Record<string, unknown> }>): void {
    this.sendJson({ toolResponse: { functionResponses: responses } })
  }

  private sendJson(payload: unknown): boolean {
    const ws = this.ws
    if (!ws || !this.ready || ws.readyState !== WebSocket.OPEN) return false
    // No per-message callback: ws batches writes; callbacks would allocate per chunk.
    ws.send(JSON.stringify(payload))
    return true
  }

  // ───────────────────────────── connection ─────────────────────────────

  private buildSetup(): unknown {
    const { model, systemInstruction, voiceName, mediaResolution } = this.opts
    return {
      setup: {
        model: `models/${model}`,
        generationConfig: {
          responseModalities: ['AUDIO'],
          mediaResolution: mediaResolution ?? 'MEDIA_RESOLUTION_MEDIUM',
          ...(voiceName
            ? { speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName } } } }
            : {})
        },
        systemInstruction: { parts: [{ text: systemInstruction }] },
        ...(this.opts.functions?.length ? { tools: [{ functionDeclarations: this.opts.functions }] } : {}),
        realtimeInputConfig: {
          // Server-side VAD: no client push-to-talk; user can interrupt ("barge in").
          automaticActivityDetection: { disabled: Boolean(this.opts.manualActivity) },
          activityHandling: 'START_OF_ACTIVITY_INTERRUPTS',
          // A user turn includes their speech AND every screen frame since the
          // last turn, so "what's wrong with this?" sees what's on screen.
          turnCoverage: 'TURN_INCLUDES_AUDIO_ACTIVITY_AND_ALL_VIDEO'
        },
        // Transcripts drive the caption line in the notch.
        inputAudioTranscription: {},
        outputAudioTranscription: {},
        // Audio+video sessions fill the context window fast; a sliding window
        // keeps long tutoring sessions alive instead of hard-terminating.
        contextWindowCompression: { slidingWindow: {} },
        // Ask the server for resumption handles so drops/goAway are seamless.
        sessionResumption: this.resumeHandle ? { handle: this.resumeHandle } : {}
      }
    }
  }

  private buildUrl(): string {
    const { ephemeralToken, apiKey, endpoint } = this.opts
    if (ephemeralToken) return `${endpoint ?? CONSTRAINED_ENDPOINT}?access_token=${encodeURIComponent(ephemeralToken)}`
    if (apiKey) return `${endpoint ?? ENDPOINT}?key=${encodeURIComponent(apiKey)}`
    throw new Error('GeminiLiveSession needs an apiKey or an ephemeralToken.')
  }

  /** Opens a NEW socket, sends setup, resolves on setupComplete. */
  private open(): Promise<void> {
    return new Promise<void>((resolve, reject) => {
      const url = this.buildUrl()
      const ws = new WebSocket(url, {
        perMessageDeflate: false, // lower CPU + latency; payloads are already dense
        handshakeTimeout: 8_000,
        maxPayload: 32 * 1024 * 1024
      })
      // Keep the current socket live while this one handshakes (make-before-break).
      this.pending = ws

      let settled = false
      let established = false
      const timer = setTimeout(() => fail(new Error('Timed out waiting for the model to accept the session.')), SETUP_TIMEOUT_MS)

      const fail = (err: Error): void => {
        if (settled) return
        settled = true
        clearTimeout(timer)
        if (this.pending === ws) this.pending = null
        try {
          ws.terminate()
        } catch {
          /* ignore */
        }
        reject(err)
      }

      // Disable Nagle: 40 ms audio chunks must leave immediately, not coalesce.
      ws.on('upgrade', (res) => res.socket.setNoDelay(true))

      ws.on('open', () => ws.send(JSON.stringify(this.buildSetup())))

      ws.on('message', (data: RawData) => {
        const msg = parseMessage(data)
        if (!msg) return
        if (msg.setupComplete !== undefined) {
          established = true
          if (this.closedByUser) {
            fail(new Error('Session stopped.'))
            return
          }
          this.pending = null
          this.ws = ws // atomic swap: all subsequent sends go to the new socket
          this.ready = true
          settled = true
          clearTimeout(timer)
          resolve()
          return
        }
        this.handleServerMessage(msg)
      })

      ws.on('close', (code, reasonBuf) => {
        const reason = reasonBuf.toString()
        if (!established) {
          // Setup-phase failure: bad key (1007/1008), bad model, quota, etc.
          fail(new Error(reason || `Connection closed during setup (code ${code}).`))
          return
        }
        if (this.ws !== ws) return // superseded by a newer socket (goAway handover)
        this.ready = false
        if (this.closedByUser) return
        void this.reconnect(`Connection dropped (${code}${reason ? `: ${reason}` : ''})`)
      })

      // 'close' always follows 'error' in ws; reject early only during setup.
      ws.on('error', (err) => {
        if (!established) fail(err)
        else console.error('[live] socket error:', err.message)
      })
    })
  }

  /**
   * Reconnect with exponential backoff. If we hold a resumption handle the
   * model keeps full conversational context; otherwise a fresh session starts.
   * The old socket (if still alive, e.g. after goAway) keeps working until the
   * new one is ready, then is closed – a make-before-break handover.
   */
  private async reconnect(reason: string): Promise<void> {
    if (this.reconnecting || this.closedByUser) return
    this.reconnecting = true
    const old = this.ws
    this.emit('state', 'reconnecting', reason)

    for (let attempt = 0; attempt < MAX_RECONNECT_ATTEMPTS && !this.closedByUser; attempt++) {
      try {
        await this.open()
        if (old && old !== this.ws) {
          try {
            old.close(1000, 'handover')
          } catch {
            /* ignore */
          }
        }
        this.reconnecting = false
        this.emit('state', 'live')
        return
      } catch (err) {
        console.warn(`[live] reconnect attempt ${attempt + 1} failed:`, (err as Error).message)
        // A stale/expired handle makes every attempt fail – fall back to fresh.
        if (attempt >= 1) this.resumeHandle = null
        const delay = Math.min(BACKOFF_BASE_MS * 2 ** attempt, BACKOFF_MAX_MS)
        await sleep(delay + Math.random() * 100)
      }
    }
    this.reconnecting = false
    if (!this.closedByUser) this.emit('state', 'error', 'Lost connection to the tutor. Check your network and start again.')
  }

  // ───────────────────────────── receiving ─────────────────────────────

  private handleServerMessage(msg: ServerMessage): void {
    const sc = msg.serverContent
    if (sc) {
      // Order matters: flush playback BEFORE enqueueing any new audio.
      if (sc.interrupted) this.emit('interrupted')

      const parts = sc.modelTurn?.parts
      if (parts) {
        for (const part of parts) {
          const d = part.inlineData
          if (d?.data && d.mimeType?.startsWith('audio/pcm')) {
            this.emit('audio', Buffer.from(d.data, 'base64'))
          }
        }
      }
      if (sc.inputTranscription?.text) this.emit('transcript', 'user', sc.inputTranscription.text)
      if (sc.outputTranscription?.text) this.emit('transcript', 'tutor', sc.outputTranscription.text)
      if (sc.turnComplete) this.emit('turnComplete')
    }

    const calls = msg.toolCall?.functionCalls
    if (calls?.length) {
      this.emit(
        'toolCall',
        calls.map((c) => ({ id: c.id ?? '', name: c.name ?? '', args: c.args ?? {} }))
      )
    }

    const upd = msg.sessionResumptionUpdate
    if (upd?.resumable && upd.newHandle) this.resumeHandle = upd.newHandle

    // Server will cut us off soon (connection lifetime limit). Hand over now,
    // while the current socket still works, so the user never hears a gap.
    if (msg.goAway) void this.reconnect(`Server rotation (${msg.goAway.timeLeft ?? 'soon'})`)
  }
}

/** Gemini sends JSON in binary WebSocket frames; accept both text and binary. */
function parseMessage(data: RawData): ServerMessage | null {
  try {
    const text = Array.isArray(data)
      ? Buffer.concat(data).toString('utf8')
      : Buffer.isBuffer(data)
        ? data.toString('utf8')
        : Buffer.from(data as ArrayBuffer).toString('utf8')
    return JSON.parse(text) as ServerMessage
  } catch (err) {
    console.warn('[live] unparsable server message', err)
    return null
  }
}

const sleep = (ms: number): Promise<void> => new Promise((r) => setTimeout(r, ms))
