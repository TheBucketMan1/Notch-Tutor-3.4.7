/**
 * "Open when my Mac starts" – registers the app as a login item.
 *
 * macOS 13+ uses SMAppService (Electron's default `mainAppService` type).
 * macOS may put a new login item into "requires approval" state; in that
 * case we open the Login Items settings page so the user can switch it on.
 */
import { app, shell } from 'electron'
import type { LoginItemStatus } from '@shared/study'

export function getOpenAtLogin(): LoginItemStatus {
  // In development this would register the bare Electron binary, not the app.
  if (!app.isPackaged || process.platform === 'linux') {
    return { enabled: false, needsApproval: false, supported: false }
  }
  const s = app.getLoginItemSettings()
  const needsApproval = process.platform === 'darwin' && s.status === 'requires-approval'
  const enabled = process.platform === 'darwin' ? s.status === 'enabled' || needsApproval || s.openAtLogin : s.openAtLogin
  return { enabled, needsApproval, supported: true }
}

export async function setOpenAtLogin(on: boolean): Promise<LoginItemStatus> {
  const before = getOpenAtLogin()
  if (!before.supported) return before
  app.setLoginItemSettings({ openAtLogin: on })
  const after = getOpenAtLogin()
  if (on && after.needsApproval && process.platform === 'darwin') {
    await shell.openExternal('x-apple.systempreferences:com.apple.LoginItems-Settings.extension')
  }
  return after
}
