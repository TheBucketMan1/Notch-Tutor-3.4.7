/**
 * Media permissions – the part of desktop AI apps that usually breaks.
 *
 * Three layers must ALL say yes:
 *   A. OS privacy layer (macOS TCC, Windows Privacy settings)
 *   B. Chromium permission layer (session permission handlers)
 *   C. Screen-source selection (getDisplayMedia would normally show a picker)
 *
 * We handle B and C programmatically so the renderer can call the standard
 * getUserMedia / getDisplayMedia APIs and get the PRIMARY monitor with no picker.
 * A is surfaced to the user with a direct deep link to the right settings pane.
 */
import {
  desktopCapturer,
  dialog,
  screen,
  session,
  shell,
  systemPreferences,
  type Session
} from 'electron'
import type { PermissionReport, PermissionStatus } from '@shared/protocol'

/**
 * Installs Chromium-level handlers.
 * @param isTrustedUrl only our own renderer origin may use the mic/screen.
 */
export function installMediaHandlers(isTrustedUrl: (url: string) => boolean, ses: Session = session.defaultSession): void {
  const ALLOWED = new Set(['media', 'display-capture'])

  ses.setPermissionRequestHandler((webContents, permission, callback, details) => {
    const url = details.requestingUrl || webContents.getURL()
    callback(ALLOWED.has(permission) && isTrustedUrl(url))
  })

  ses.setPermissionCheckHandler((_wc, permission, requestingOrigin) => {
    return ALLOWED.has(permission) && isTrustedUrl(requestingOrigin)
  })

  // Answers navigator.mediaDevices.getDisplayMedia() with the primary monitor.
  ses.setDisplayMediaRequestHandler(
    async (request, callback) => {
      try {
        if (!isTrustedUrl(request.securityOrigin ?? request.frame?.url ?? '')) return callback({})
        // thumbnailSize 0×0: skip generating thumbnails we'd throw away (saves ~50–200 ms).
        const sources = await desktopCapturer.getSources({ types: ['screen'], thumbnailSize: { width: 0, height: 0 } })
        const primaryId = String(screen.getPrimaryDisplay().id)
        // display_id is empty on some Linux/Wayland setups → fall back to first screen.
        const source = sources.find((s) => s.display_id === primaryId) ?? sources[0]
        if (!source) return callback({}) // macOS: Screen Recording not granted
        callback({ video: source })
      } catch (err) {
        console.error('[perm] display media handler failed:', err)
        callback({})
      }
    },
    // Never show the OS picker (macOS 15+ would otherwise offer it).
    { useSystemPicker: false }
  )
}

/** Camera, for photographing work in the study hub. */
export async function ensureCameraPermission(): Promise<boolean> {
  if (process.platform !== 'darwin' && process.platform !== 'win32') return true
  const status = systemPreferences.getMediaAccessStatus('camera')
  if (status === 'granted') return true
  if (process.platform === 'darwin' && status === 'not-determined') {
    return systemPreferences.askForMediaAccess('camera')
  }
  const { response } = await dialog.showMessageBox({
    type: 'info',
    buttons: ['Open Settings', 'Cancel'],
    message: 'Camera access is off',
    detail: 'Turn on Notch Tutor under Camera in your privacy settings, or upload a photo instead.'
  })
  if (response === 0) {
    await shell.openExternal(
      process.platform === 'darwin'
        ? 'x-apple.systempreferences:com.apple.preference.security?Privacy_Camera'
        : 'ms-settings:privacy-webcam'
    )
  }
  return false
}

const mapStatus = (s: string): PermissionStatus =>
  s === 'granted' ? 'granted' : s === 'denied' || s === 'restricted' ? 'denied' : 'unknown'

let promptedForScreenThisRun = false

/**
 * OS-level checks. On macOS this can trigger the system prompts.
 * Must be called from a user action (session start) – never at launch, so the
 * first thing a new user sees is the notch, not a wall of permission dialogs.
 */
export async function ensureMediaPermissions(): Promise<PermissionReport> {
  if (process.platform === 'darwin') {
    // Microphone: one-time native prompt driven by NSMicrophoneUsageDescription.
    let mic = systemPreferences.getMediaAccessStatus('microphone')
    if (mic === 'not-determined') {
      mic = (await systemPreferences.askForMediaAccess('microphone')) ? 'granted' : 'denied'
    }

    // Screen Recording: there is NO programmatic request API. Enumerating
    // sources registers the app in System Settings and shows the OS prompt once.
    let scr = systemPreferences.getMediaAccessStatus('screen')
    if (scr !== 'granted') {
      await desktopCapturer.getSources({ types: ['screen'], thumbnailSize: { width: 1, height: 1 } }).catch(() => [])
      scr = systemPreferences.getMediaAccessStatus('screen')
      if (scr !== 'granted' && !promptedForScreenThisRun) {
        promptedForScreenThisRun = true
        const { response } = await dialog.showMessageBox({
          type: 'info',
          buttons: ['Open Settings', 'Continue without screen'],
          defaultId: 0,
          message: 'Let your tutor see your screen',
          detail:
            'Turn on Notch Tutor in Privacy & Security → Screen & System Audio Recording, then quit and reopen the app. ' +
            'You can keep talking without it; the tutor just won’t see what you’re working on.'
        })
        if (response === 0) {
          await shell.openExternal('x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture')
        }
      }
    }
    return { microphone: mapStatus(mic), screen: mapStatus(scr) }
  }

  if (process.platform === 'win32') {
    // Windows reports the global "Let apps access your microphone" toggle.
    const mic = systemPreferences.getMediaAccessStatus('microphone')
    if (mic === 'denied') {
      const { response } = await dialog.showMessageBox({
        type: 'warning',
        buttons: ['Open Settings', 'Cancel'],
        message: 'Microphone access is off',
        detail: 'Turn on “Let desktop apps access your microphone” in Windows Settings, then start again.'
      })
      if (response === 0) await shell.openExternal('ms-settings:privacy-microphone')
    }
    // Windows has no screen-capture privacy gate for desktop apps.
    return { microphone: mapStatus(mic), screen: 'granted' }
  }

  // Linux: no OS-level status API; getUserMedia/portal will prompt as needed.
  return { microphone: 'unknown', screen: 'unknown' }
}
