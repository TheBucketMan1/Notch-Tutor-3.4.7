/**
 * Global push-to-talk: hold a key anywhere on the Mac to talk, release to stop.
 *
 * Electron's globalShortcut only reports key DOWN, never key UP, so a hold
 * gesture needs a low-level keyboard hook (uiohook-napi, prebuilt N-API
 * binaries, no compiler needed). We only compare each key code against the
 * chosen key: nothing is recorded, stored or sent anywhere.
 *
 * macOS requires the Accessibility permission for this. Without it the rest
 * of the app works, and the notch's on-screen "Hold to talk" button still works.
 *
 * Note: the fn/Globe key is handled by macOS itself (emoji, dictation) and is
 * never delivered to apps, so it can't be used as the talk key.
 */
import { systemPreferences } from 'electron'
import type { AccessibilityStatus } from '@shared/study'

type Hook = typeof import('uiohook-napi')
type KeyEvent = { keycode: number }

let mod: Hook | null = null
let loadError = ''
let running = false
let targetKey = 0x0e38
let enabled = false
let isDown = false
let onChange: (down: boolean) => void = () => undefined
let recorder: ((code: number) => void) | null = null

const MAC = process.platform === 'darwin'

/** Friendly names for keys people are likely to pick. */
const FRIENDLY: Record<string, string> = {
  AltRight: MAC ? 'Right Option' : 'Right Alt',
  Alt: MAC ? 'Left Option' : 'Left Alt',
  MetaRight: MAC ? 'Right Command' : 'Right Windows',
  Meta: MAC ? 'Left Command' : 'Left Windows',
  CtrlRight: 'Right Control',
  Ctrl: 'Left Control',
  ShiftRight: 'Right Shift',
  Shift: 'Left Shift',
  CapsLock: 'Caps Lock',
  Space: 'Space',
  Backquote: '` (backtick)'
}

async function load(): Promise<Hook | null> {
  if (mod || loadError) return mod
  try {
    // Plain require (not import()) so the native addon loads reliably from
    // the app's unpacked node_modules in a packaged build.
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    mod = require('uiohook-napi') as Hook
  } catch (err) {
    loadError = `Hold-to-talk key listener couldn’t load: ${(err as Error).message}`
    console.error('[ptt]', err)
  }
  return mod
}

export async function keyName(code: number): Promise<string> {
  const m = await load()
  if (!m) return `Key ${code}`
  const entry = Object.entries(m.UiohookKey).find(([, v]) => v === code)
  if (!entry) return `Key ${code}`
  return FRIENDLY[entry[0]] ?? entry[0]
}

export function accessibilityGranted(): boolean {
  return MAC ? systemPreferences.isTrustedAccessibilityClient(false) : true
}

export function status(): AccessibilityStatus {
  return { granted: accessibilityGranted(), required: MAC, error: loadError }
}

/** Shows the macOS "allow accessibility" prompt (which links to Settings). */
export function requestAccessibility(): AccessibilityStatus {
  if (MAC) systemPreferences.isTrustedAccessibilityClient(true)
  return status()
}

async function ensureRunning(): Promise<boolean> {
  if (running) return true
  if (!accessibilityGranted()) return false
  const m = await load()
  if (!m) return false
  const { uIOhook } = m
  uIOhook.on('keydown', (e: KeyEvent) => {
    if (recorder) {
      const r = recorder
      recorder = null
      r(e.keycode)
      return
    }
    if (enabled && e.keycode === targetKey && !isDown) {
      isDown = true // ignore auto-repeat while held
      onChange(true)
    }
  })
  uIOhook.on('keyup', (e: KeyEvent) => {
    if (enabled && e.keycode === targetKey && isDown) {
      isDown = false
      onChange(false)
    }
  })
  try {
    uIOhook.start()
    running = true
  } catch (err) {
    loadError = `Hold-to-talk key listener couldn’t start: ${(err as Error).message}`
    console.error('[ptt]', err)
  }
  return running
}

/** Apply settings: listen for `keycode` when hold mode is on. */
export async function configure(opts: { hold: boolean; keycode: number; onKey: (down: boolean) => void }): Promise<AccessibilityStatus> {
  targetKey = opts.keycode
  enabled = opts.hold
  onChange = opts.onKey
  if (isDown && !enabled) {
    isDown = false
    onChange(false)
  }
  if (enabled) await ensureRunning()
  return status()
}

/** Waits for the next key press anywhere (Esc cancels). */
export async function recordNextKey(timeoutMs = 10_000): Promise<{ keycode: number; name: string } | null> {
  if (!(await ensureRunning())) return null
  const m = await load()
  const code = await new Promise<number | null>((resolve) => {
    const timer = setTimeout(() => {
      recorder = null
      resolve(null)
    }, timeoutMs)
    recorder = (c) => {
      clearTimeout(timer)
      resolve(c)
    }
  })
  if (code == null || (m && code === m.UiohookKey.Escape)) return null
  return { keycode: code, name: await keyName(code) }
}

export function shutdown(): void {
  if (running && mod) {
    try {
      mod.uIOhook.stop()
    } catch {
      /* ignore */
    }
  }
  running = false
}
