/**
 * App settings (talk mode, push-to-talk key, voice, tutor style, …).
 * Stored as JSON in the app's data folder; every change is broadcast to all
 * windows so the notch and the study hub stay in sync.
 */
import { app, BrowserWindow } from 'electron'
import { promises as fs } from 'node:fs'
import { join } from 'node:path'
import { DEFAULT_SETTINGS, VOICES, type AppSettings } from '@shared/study'
import { IPC } from '@shared/protocol'

const file = (): string => join(app.getPath('userData'), 'settings.json')
let cache: AppSettings | null = null
const listeners = new Set<(s: AppSettings) => void>()

function sanitize(raw: Partial<AppSettings>): AppSettings {
  const s = { ...DEFAULT_SETTINGS, ...raw }
  return {
    talkMode: s.talkMode === 'always' ? 'always' : 'hold',
    pttKeycode: Number.isInteger(s.pttKeycode) && s.pttKeycode > 0 ? s.pttKeycode : DEFAULT_SETTINGS.pttKeycode,
    pttKeyName: typeof s.pttKeyName === 'string' && s.pttKeyName ? s.pttKeyName.slice(0, 40) : DEFAULT_SETTINGS.pttKeyName,
    voice: (VOICES as readonly string[]).includes(s.voice) ? s.voice : '',
    tutorStyle: s.tutorStyle === 'direct' ? 'direct' : 'guide',
    showFace: s.showFace !== false,
    screenDetail: s.screenDetail === 'sharp' ? 'sharp' : 'standard'
  }
}

export async function getSettings(): Promise<AppSettings> {
  if (cache) return cache
  try {
    cache = sanitize(JSON.parse(await fs.readFile(file(), 'utf8')) as Partial<AppSettings>)
  } catch {
    cache = { ...DEFAULT_SETTINGS, pttKeyName: process.platform === 'darwin' ? 'Right Option' : 'Right Alt' }
  }
  return cache
}

export async function updateSettings(patch: Partial<AppSettings>): Promise<AppSettings> {
  const next = sanitize({ ...(await getSettings()), ...patch })
  cache = next
  await fs.mkdir(app.getPath('userData'), { recursive: true })
  await fs.writeFile(file(), JSON.stringify(next, null, 2), 'utf8')
  for (const w of BrowserWindow.getAllWindows()) {
    if (!w.isDestroyed()) w.webContents.send(IPC.settingsChanged, next)
  }
  for (const fn of listeners) fn(next)
  return next
}

export function onSettingsChanged(fn: (s: AppSettings) => void): void {
  listeners.add(fn)
}
