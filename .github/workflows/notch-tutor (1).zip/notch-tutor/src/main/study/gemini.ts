/**
 * Minimal Gemini REST client for the study hub (non-realtime requests:
 * handwriting analysis, revision plans, marking).
 *
 * Uses the same user API key as the live tutor. Returns parsed JSON.
 * Tries a short list of Flash models in order, so the app keeps working if
 * Google retires one or a model isn't on the user's free tier.
 */
const BASE = 'https://generativelanguage.googleapis.com/v1beta'
const REQUEST_TIMEOUT_MS = 150_000
/** Attempts per model when Google reports it's overloaded, and the waits between them. */
const BUSY_RETRIES_PER_MODEL = 3
const BUSY_BACKOFF_MS = [1500, 4000]
const sleep = (ms: number): Promise<void> => new Promise((r) => setTimeout(r, ms))

function candidateModels(): string[] {
  const fromEnv = process.env.GEMINI_TEXT_MODEL?.trim()
  const list = [fromEnv, 'gemini-3.8-flash', 'gemini-3.6-flash', 'gemini-3.5-flash', 'gemini-2.5-flash']
  return [...new Set(list.filter((m): m is string => Boolean(m)))]
}

/** Remember the first model that worked, so later calls skip dead ones. */
let workingModel: string | null = null

export type Part = { text: string } | { inlineData: { mimeType: string; data: string } }

export class GeminiError extends Error {
  constructor(
    message: string,
    readonly kind: 'key' | 'quota' | 'model' | 'busy' | 'blocked' | 'network' | 'bad-output' | 'other'
  ) {
    super(message)
  }
}

interface GenerateResponse {
  candidates?: Array<{
    content?: { parts?: Array<{ text?: string; thought?: boolean }> }
    finishReason?: string
  }>
  promptFeedback?: { blockReason?: string }
  error?: { code?: number; message?: string; status?: string }
}

export async function generateJson<T>(apiKey: string, system: string, parts: Part[], temperature = 0.4): Promise<T> {
  const models = workingModel ? [workingModel, ...candidateModels().filter((m) => m !== workingModel)] : candidateModels()
  let lastErr: GeminiError | null = null

  let sawBusy = false
  for (const model of models) {
    // Busy/overloaded errors are Google-side and usually clear in seconds:
    // retry the same model a couple of times, then move to the next model.
    for (let attempt = 0; attempt < BUSY_RETRIES_PER_MODEL; attempt++) {
      try {
        const out = await callModel<T>(apiKey, model, system, parts, temperature)
        workingModel = model
        return out
      } catch (err) {
        const e = err instanceof GeminiError ? err : new GeminiError(String(err), 'other')
        lastErr = e
        if (e.kind === 'busy') {
          sawBusy = true
          console.warn(`[gemini] ${model} busy (attempt ${attempt + 1})`)
          if (attempt < BUSY_RETRIES_PER_MODEL - 1) await sleep(BUSY_BACKOFF_MS[attempt] ?? 4000)
          continue
        }
        // A missing model or a per-model quota: try the next model.
        if (e.kind === 'model' || e.kind === 'quota') break
        throw e
      }
    }
    if (workingModel === model) workingModel = null // it just failed; don't prefer it next time
  }
  if (sawBusy && lastErr?.kind === 'busy') {
    throw new GeminiError('Google’s Gemini servers are very busy right now for everyone, not just you. Wait a minute or two and try again.', 'busy')
  }
  throw lastErr ?? new GeminiError('No Gemini model is available for this key.', 'model')
}

async function callModel<T>(apiKey: string, model: string, system: string, parts: Part[], temperature: number): Promise<T> {
  let res: Response
  try {
    res = await fetch(`${BASE}/models/${encodeURIComponent(model)}:generateContent`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: system }] },
        contents: [{ role: 'user', parts }],
        generationConfig: { responseMimeType: 'application/json', temperature }
      }),
      signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS)
    })
  } catch (err) {
    const name = (err as Error).name
    if (name === 'TimeoutError' || name === 'AbortError') {
      throw new GeminiError('Gemini took too long to answer. Try again, or send fewer pages at once.', 'network')
    }
    throw new GeminiError('Can’t reach Gemini. Check your internet connection.', 'network')
  }

  let body: GenerateResponse
  try {
    body = (await res.json()) as GenerateResponse
  } catch {
    throw new GeminiError(`Gemini returned an unreadable response (HTTP ${res.status}).`, 'other')
  }

  if (!res.ok) {
    const msg = body.error?.message ?? ''
    const status = body.error?.status ?? ''
    if (res.status === 404 || /not found|is not supported|unsupported model/i.test(msg)) {
      throw new GeminiError(`Model ${model} isn’t available.`, 'model')
    }
    // 503 "high demand" / overloaded, or a transient 500: temporary, retry.
    if (res.status === 503 || res.status === 500 || status === 'UNAVAILABLE' || status === 'INTERNAL' || /high demand|overloaded|try again later/i.test(msg)) {
      throw new GeminiError(msg || 'Gemini is busy.', 'busy')
    }
    if (res.status === 429 || status === 'RESOURCE_EXHAUSTED') {
      throw new GeminiError('You’ve hit your free Gemini limit for now. Wait a minute (or until tomorrow for daily limits) and try again.', 'quota')
    }
    if (res.status === 401 || res.status === 403 || /api key|permission/i.test(msg)) {
      throw new GeminiError('Gemini rejected your API key. Paste a fresh key from AI Studio in the notch.', 'key')
    }
    throw new GeminiError(msg || `Gemini request failed (HTTP ${res.status}).`, 'other')
  }

  if (body.promptFeedback?.blockReason) {
    throw new GeminiError('Gemini refused to process this upload. Try a clearer photo of just your work.', 'blocked')
  }

  const text = (body.candidates?.[0]?.content?.parts ?? [])
    .filter((p) => !p.thought && typeof p.text === 'string')
    .map((p) => p.text)
    .join('')

  if (!text.trim()) throw new GeminiError('Gemini sent back an empty answer. Try again.', 'bad-output')
  return parseJsonLoose<T>(text)
}

/** Accepts plain JSON, fenced JSON, or JSON with stray text around it. */
function parseJsonLoose<T>(text: string): T {
  const cleaned = text.replace(/```(?:json)?/gi, '').trim()
  try {
    return JSON.parse(cleaned) as T
  } catch {
    const start = cleaned.indexOf('{')
    const end = cleaned.lastIndexOf('}')
    if (start >= 0 && end > start) {
      try {
        return JSON.parse(cleaned.slice(start, end + 1)) as T
      } catch {
        /* fall through */
      }
    }
    throw new GeminiError('Gemini’s answer came back in the wrong format. Try again.', 'bad-output')
  }
}
