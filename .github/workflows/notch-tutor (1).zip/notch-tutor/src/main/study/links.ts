/**
 * Revision links that always work.
 *
 * Language models invent URLs that 404. So the model never writes a URL: it
 * picks a site from this fixed list plus a short search phrase, and WE build
 * the link:
 *   • sites with their own search page (BBC Bitesize, YouTube, Khan Academy)
 *     open that search directly;
 *   • other sites open the best-matching page ON that site directly, using
 *     DuckDuckGo's "jump to first result" (a query starting with a backslash).
 *     We search with the site's name as plain words rather than a strict
 *     `site:` filter, because an over-specific `site:` search can match nothing.
 */
import type { LinkKind, ResourceLink } from '@shared/study'

interface Site {
  label: string
  kind: LinkKind
  build: (q: string) => string
}

const enc = encodeURIComponent
const google = (q: string): string => `https://www.google.com/search?q=${enc(q)}`
/** Opens the top result straight away (DuckDuckGo "\\" jump). */
const jump = (q: string): string => `https://duckduckgo.com/?q=${enc(`\\${q}`)}`
const onSite = (siteWords: string) => (q: string) => jump(`${siteWords} ${q}`)

export const SITES: Record<string, Site> = {
  bitesize: { label: 'BBC Bitesize', kind: 'notes', build: (q) => `https://www.bbc.co.uk/bitesize/search?q=${enc(q)}` },
  youtube: { label: 'YouTube', kind: 'video', build: (q) => `https://www.youtube.com/results?search_query=${enc(q)}` },
  khan: { label: 'Khan Academy', kind: 'video', build: (q) => `https://www.khanacademy.org/search?page_search_query=${enc(q)}` },
  savemyexams: { label: 'Save My Exams', kind: 'notes', build: onSite('savemyexams') },
  pmt: { label: 'Physics & Maths Tutor', kind: 'pastpapers', build: onSite('physicsandmathstutor') },
  corbettmaths: { label: 'Corbettmaths', kind: 'practice', build: onSite('corbettmaths') },
  mathsgenie: { label: 'Maths Genie', kind: 'practice', build: onSite('mathsgenie') },
  seneca: { label: 'Seneca', kind: 'practice', build: onSite('seneca learning') },
  cognito: { label: 'Cognito', kind: 'video', build: onSite('cognito edu') },
  freesciencelessons: { label: 'Freesciencelessons', kind: 'video', build: (q) => `https://www.youtube.com/results?search_query=${enc(`freesciencelessons ${q}`)}` },
  pastpapers: { label: 'Past papers', kind: 'pastpapers', build: (q) => google(`${q} past papers mark scheme`) },
  google: { label: 'Google', kind: 'search', build: google }
}

/** The site keys the model is allowed to choose from (listed in prompts). */
export const SITE_KEYS = Object.keys(SITES)

export function buildLinks(raw: unknown, max = 4): ResourceLink[] {
  if (!Array.isArray(raw)) return []
  const out: ResourceLink[] = []
  for (const item of raw) {
    if (!item || typeof item !== 'object') continue
    const r = item as { site?: unknown; query?: unknown }
    // Keep queries short: long page-title-style queries match nothing.
    const query =
      typeof r.query === 'string'
        ? r.query.replace(/site:\S+/gi, '').replace(/[()"|]/g, ' ').replace(/\s+/g, ' ').trim().split(' ').slice(0, 8).join(' ')
        : ''
    if (!query) continue
    const key = typeof r.site === 'string' ? r.site.toLowerCase().replace(/[^a-z]/g, '') : 'google'
    const site = SITES[key] ?? SITES.google
    out.push({ label: `${site.label}: ${query}`, url: site.build(query), kind: site.kind })
    if (out.length >= max) break
  }
  return out
}
