/**
 * Study service: turns user actions into Gemini requests and normalises the
 * answers into the strict shapes in @shared/study.
 *
 * Normalisation matters: models occasionally drop fields or return the wrong
 * type. Every field below gets a safe default, so the UI can't crash on a
 * surprising answer.
 */
import { randomUUID } from 'node:crypto'
import { resolveApiKey } from '../credentials'
import { GeminiError, generateJson, type Part } from './gemini'
import { buildLinks, SITE_KEYS } from './links'
import * as store from './store'
import {
  HANDWRITING_LINES,
  type HandwritingProfile,
  type MarkRequest,
  type MarkResult,
  type Quiz,
  type QuizRequest,
  type QuizResult,
  type PlanDay,
  type PlanSubject,
  type RevisionPlan,
  type StudyProfile,
  type StudyResult,
  type StudyState,
  type UploadFile
} from '@shared/study'

const MAX_FILES = 8
const MAX_TOTAL_BYTES = 18 * 1024 * 1024 // stays under Gemini's ~20 MB inline request limit
const ALLOWED_MIME = /^(image\/(jpeg|png|webp|heic|heif)|application\/pdf)$/

// ───────────────────────────── small normalisers ─────────────────────────────

const str = (v: unknown, max = 4000): string => (typeof v === 'string' ? v.trim().slice(0, max) : '')
const num = (v: unknown): number | null => (typeof v === 'number' && Number.isFinite(v) ? v : null)
const strList = (v: unknown, maxItems = 12): string[] =>
  Array.isArray(v) ? v.map((x) => str(x, 600)).filter(Boolean).slice(0, maxItems) : []
const clamp = (n: number, lo: number, hi: number): number => Math.min(hi, Math.max(lo, n))
const objList = (v: unknown, maxItems = 20): Record<string, unknown>[] =>
  Array.isArray(v) ? (v.filter((x) => x && typeof x === 'object') as Record<string, unknown>[]).slice(0, maxItems) : []

async function withKey<T>(fn: (key: string) => Promise<T>): Promise<StudyResult<T>> {
  try {
    const { key } = await resolveApiKey()
    if (!key) return { ok: false, error: 'Add your Gemini API key in the notch first (hover the notch, then Start session).' }
    return { ok: true, data: await fn(key) }
  } catch (err) {
    const message = err instanceof GeminiError || err instanceof Error ? err.message : String(err)
    console.error('[study]', err)
    return { ok: false, error: message }
  }
}

function validateUpload(f: UploadFile): Buffer {
  if (!ALLOWED_MIME.test(f.mimeType)) throw new Error(`${f.name}: only photos (JPG, PNG, HEIC) and PDFs can be marked.`)
  const buf = Buffer.from(f.dataBase64, 'base64')
  if (buf.length === 0) throw new Error(`${f.name} is empty.`)
  return buf
}

function describeStudent(profile: StudyProfile | null): string {
  if (!profile || profile.subjects.length === 0) return 'The student has not set up their subjects yet.'
  const lines = profile.subjects.map(
    (s) =>
      `- ${s.name}${s.board ? ` (${s.board})` : ''}: confidence ${s.confidence}/5` +
      (s.weakTopics ? `; finds hard: ${s.weakTopics}` : '')
  )
  return [
    `Level: ${profile.level || 'not given'}.`,
    profile.examDate ? `Exams start: ${profile.examDate}.` : 'No exam date given.',
    `Time available: about ${profile.hoursPerWeek} hours per week.`,
    'Subjects:',
    ...lines
  ].join('\n')
}

// ───────────────────────────── public operations ─────────────────────────────

export const getState = (): Promise<StudyState> => store.getState()

export async function saveProfile(p: StudyProfile): Promise<StudyResult<StudyState>> {
  try {
    const clean: StudyProfile = {
      name: str(p.name, 60),
      level: str(p.level, 60),
      examDate: /^\d{4}-\d{2}-\d{2}$/.test(p.examDate) ? p.examDate : '',
      hoursPerWeek: clamp(Math.round(Number(p.hoursPerWeek) || 5), 1, 60),
      subjects: (Array.isArray(p.subjects) ? p.subjects : [])
        .map((s) => ({
          id: str(s.id, 64) || randomUUID(),
          name: str(s.name, 60),
          board: str(s.board, 40),
          weakTopics: str(s.weakTopics, 1000),
          confidence: clamp(Math.round(Number(s.confidence) || 3), 1, 5)
        }))
        .filter((s) => s.name)
        .slice(0, 15),
      updatedAt: Date.now()
    }
    await store.saveProfile(clean)
    return { ok: true, data: await store.getState() }
  } catch (err) {
    return { ok: false, error: (err as Error).message }
  }
}

export function analyzeHandwriting(sample: UploadFile): Promise<StudyResult<HandwritingProfile>> {
  return withKey(async (key) => {
    const buf = validateUpload(sample)
    const expected = HANDWRITING_LINES.join('\n')

    const system = `You are an expert at reading student handwriting. You will see a photo of a handwriting sample.
The student was asked to copy exactly these lines:
${expected}

Return ONLY a JSON object:
{
  "transcription": string,        // exactly what you can read, line by line, WITHOUT correcting it
  "accuracyPercent": number,      // 0-100: how much of the expected text you could read correctly
  "confusions": [ { "chars": string, "note": string } ],  // letters/digits in THEIR writing easily mistaken, e.g. {"chars":"a / d","note":"your a has a tall stem so it can look like d"}
  "profile": string,              // 120-250 words describing this person's handwriting so another reader could decode it: slant, size, joined or print, spacing, distinctive shapes of specific letters and digits (describe each unusual one), how capitals differ from lowercase
  "tips": [string]                // 2-4 short, kind tips to make their writing easier to read in exams
}
Be specific about individual letters. If the photo is not a handwriting sample, set accuracyPercent to 0 and explain in "profile".`

    const raw = await generateJson<Record<string, unknown>>(key, system, [
      { text: 'Here is my handwriting sample.' },
      { inlineData: { mimeType: sample.mimeType, data: sample.dataBase64 } }
    ], 0.2)

    const profile: HandwritingProfile = {
      transcription: str(raw.transcription, 3000),
      accuracyPercent: clamp(Math.round(num(raw.accuracyPercent) ?? 0), 0, 100),
      confusions: objList(raw.confusions, 15)
        .map((c) => ({ chars: str(c.chars, 40), note: str(c.note, 300) }))
        .filter((c) => c.chars && c.note),
      profile: str(raw.profile, 3000),
      tips: strList(raw.tips, 5),
      createdAt: Date.now()
    }
    if (profile.accuracyPercent > 0) await store.saveHandwriting(profile, buf, sample.mimeType)
    return profile
  })
}

export function generatePlan(): Promise<StudyResult<RevisionPlan>> {
  return withKey(async (key) => {
    const state = await store.getState()
    if (!state.profile || state.profile.subjects.length === 0) {
      throw new Error('Add at least one subject first.')
    }
    const recent = state.history.slice(0, 12).map((h) => {
      const pct = h.score.percent != null ? `${h.score.percent}%` : 'no score'
      const weak = h.nextSteps.map((n) => n.topic).join(', ')
      return `- ${h.subject} / ${h.topic}: ${pct}. Needs work: ${weak || 'n/a'}`
    })
    const today = new Date().toISOString().slice(0, 10)

    const system = `You are an expert UK revision coach. Build a specific, realistic revision plan for this student.
Today is ${today}.
${describeStudent(state.profile)}
${recent.length ? `Recent marked work:\n${recent.join('\n')}` : 'No marked work yet.'}

Rules:
- Prioritise the lowest-confidence subjects and the topics they named as hard, plus weaknesses from marked work.
- Tasks must be concrete and doable in one sitting, e.g. "Do 10 questions on completing the square, then check answers" not "revise algebra".
- Use active recall, past-paper questions and spaced repetition. Mention exam-board specifics when a board is given.
- The weekly schedule must fit in about ${state.profile.hoursPerWeek} hours total.
- For links you may ONLY choose a "site" from: ${SITE_KEYS.join(', ')}. Give a short search phrase as "query" (include level and exam board when useful). Never write URLs. Keep each "query" to 3-6 plain words (e.g. "edexcel gcse quadratics questions"), never a page title.

Return ONLY JSON:
{
  "overview": string,   // 2-3 sentences, speak directly to the student
  "subjects": [ { "subject": string, "topics": [ { "topic": string, "why": string,
      "tasks": [ { "text": string, "minutes": number, "resources": [ { "site": string, "query": string } ] } ] } ] } ],
  "week": [ { "day": "Monday", "blocks": [ { "subject": string, "topic": string, "minutes": number, "activity": string } ] } ],
  "tips": [string]
}
Give 2-4 topics per subject, 2-4 tasks per topic, 1-3 resources per task, and all 7 days (rest days may have no blocks).`

    const raw = await generateJson<Record<string, unknown>>(key, system, [{ text: 'Make my revision plan.' }], 0.5)

    const subjects: PlanSubject[] = objList(raw.subjects, 15).map((s) => ({
      subject: str(s.subject, 60),
      topics: objList(s.topics, 6).map((t) => ({
        topic: str(t.topic, 120),
        why: str(t.why, 400),
        tasks: objList(t.tasks, 6).map((k) => ({
          id: randomUUID(),
          text: str(k.text, 500),
          minutes: clamp(Math.round(num(k.minutes) ?? 20), 5, 180),
          resources: buildLinks(k.resources, 3)
        })).filter((k) => k.text)
      })).filter((t) => t.topic)
    })).filter((s) => s.subject)

    const week: PlanDay[] = objList(raw.week, 7).map((d) => ({
      day: str(d.day, 20),
      blocks: objList(d.blocks, 8).map((b) => ({
        subject: str(b.subject, 60),
        topic: str(b.topic, 120),
        minutes: clamp(Math.round(num(b.minutes) ?? 30), 5, 240),
        activity: str(b.activity, 300)
      })).filter((b) => b.subject)
    })).filter((d) => d.day)

    if (subjects.length === 0) throw new GeminiError('The plan came back empty. Try again.', 'bad-output')

    const plan: RevisionPlan = {
      overview: str(raw.overview, 800),
      subjects,
      week,
      tips: strList(raw.tips, 6),
      createdAt: Date.now()
    }
    await store.savePlan(plan)
    return plan
  })
}

export function markWork(req: MarkRequest): Promise<StudyResult<MarkResult>> {
  return withKey(async (key) => {
    const files = Array.isArray(req.files) ? req.files : []
    if (files.length === 0) throw new Error('Add at least one photo or PDF of your work.')
    if (files.length > MAX_FILES) throw new Error(`Send up to ${MAX_FILES} pages at a time.`)
    let total = 0
    for (const f of files) total += validateUpload(f).length
    if (total > MAX_TOTAL_BYTES) throw new Error('Those files are too big together. Send fewer pages, or smaller photos.')

    const state = await store.getState()
    const sample = await store.getHandwritingSample()
    const subject = str(req.subject, 60) || 'Unknown subject'
    const subjectPref = state.profile?.subjects.find((s) => s.name.toLowerCase() === subject.toLowerCase())

    const system = `You are an experienced, encouraging UK examiner and teacher marking a student's work.
Subject: ${subject}${subjectPref?.board ? ` (${subjectPref.board})` : ''}. Level: ${state.profile?.level || 'not given'}.

Reading handwriting:
${state.handwriting
  ? `You have this student's handwriting profile:\n${state.handwriting.profile}\nKnown easily-confused characters: ${state.handwriting.confusions.map((c) => `${c.chars} (${c.note})`).join('; ') || 'none noted'}.`
  : 'No handwriting profile is available; read carefully.'}
${sample ? 'The FIRST image is their handwriting reference sample (they copied known pangrams, the alphabet and digits). Use it to decode letter shapes. Do NOT mark the sample. The work to mark follows it.' : ''}

Marking:
- First transcribe exactly what the student wrote (do not fix their mistakes in the transcription).
- If a question or mark scheme is given, mark against it. Otherwise work out the questions from the pages and mark as a real examiner would, and set "estimated" to true.
- Be accurate and honest, but kind. Point to exactly where each mistake is.
- Use plain text maths (x², √, ≤, ½), never LaTeX.
- For links you may ONLY choose a "site" from: ${SITE_KEYS.join(', ')}, with a short search "query". Never write URLs. Keep each "query" to 3-6 plain words (e.g. "edexcel gcse quadratics questions"), never a page title.

Return ONLY JSON:
{
  "subject": string,
  "topic": string,
  "transcription": string,
  "readingConfidence": "high" | "medium" | "low",
  "unclearParts": [string],          // words/numbers you were unsure how to read
  "score": { "got": number|null, "outOf": number|null, "percent": number|null, "estimated": boolean, "grade": string },  // grade only if meaningful (e.g. GCSE 1-9), else ""
  "summary": string,                 // 2-3 sentences to the student
  "strengths": [string],
  "mistakes": [ { "where": string, "youWrote": string, "correct": string, "why": string } ],
  "improvements": [string],          // specific actions
  "nextSteps": [ { "topic": string, "why": string, "resources": [ { "site": string, "query": string } ] } ]
}`

    const parts: Part[] = []
    if (sample) {
      parts.push({ text: 'Handwriting reference sample (do not mark):' })
      parts.push({ inlineData: { mimeType: sample.mimeType, data: sample.data.toString('base64') } })
    }
    parts.push({ text: `Work to mark (${files.length} page${files.length > 1 ? 's' : ''}):` })
    for (const f of files) parts.push({ inlineData: { mimeType: f.mimeType, data: f.dataBase64 } })
    const question = str(req.question, 4000)
    const scheme = str(req.markScheme, 6000)
    parts.push({ text: `Question / task: ${question || '(not given, infer it from the pages)'}` })
    parts.push({ text: `Mark scheme / answers: ${scheme || '(not given)'}` })

    const raw = await generateJson<Record<string, unknown>>(key, system, parts, 0.2)
    const sc = (raw.score && typeof raw.score === 'object' ? raw.score : {}) as Record<string, unknown>
    const got = num(sc.got)
    const outOf = num(sc.outOf)
    let percent = num(sc.percent)
    if (percent == null && got != null && outOf) percent = Math.round((got / outOf) * 100)
    const conf = str(raw.readingConfidence, 10)

    const result: MarkResult = {
      id: randomUUID(),
      createdAt: Date.now(),
      subject: str(raw.subject, 60) || subject,
      topic: str(raw.topic, 120) || 'General',
      transcription: str(raw.transcription, 12000),
      readingConfidence: conf === 'high' || conf === 'low' ? conf : 'medium',
      unclearParts: strList(raw.unclearParts, 10),
      score: {
        got,
        outOf,
        percent: percent == null ? null : clamp(Math.round(percent), 0, 100),
        estimated: sc.estimated !== false,
        grade: str(sc.grade, 12)
      },
      summary: str(raw.summary, 1000),
      strengths: strList(raw.strengths, 8),
      mistakes: objList(raw.mistakes, 20)
        .map((m) => ({ where: str(m.where, 200), youWrote: str(m.youWrote, 600), correct: str(m.correct, 800), why: str(m.why, 800) }))
        .filter((m) => m.why || m.correct),
      improvements: strList(raw.improvements, 8),
      nextSteps: objList(raw.nextSteps, 5)
        .map((n) => ({ topic: str(n.topic, 120), why: str(n.why, 400), links: buildLinks(n.resources, 3) }))
        .filter((n) => n.topic)
    }
    await store.addHistory(result)
    return result
  })
}

export function makeQuiz(req: QuizRequest): Promise<StudyResult<Quiz>> {
  return withKey(async (key) => {
    const state = await store.getState()
    const subject = str(req.subject, 60)
    if (!subject) throw new Error('Choose a subject for the quiz.')
    const topic = str(req.topic, 160) || 'mixed topics from this subject'
    const count = clamp(Math.round(Number(req.count) || 5), 3, 15)
    const pref = state.profile?.subjects.find((s) => s.name.toLowerCase() === subject.toLowerCase())
    const difficulty =
      req.difficulty === 'easier' ? 'a bit easier than the real exam, to build confidence' : req.difficulty === 'harder' ? 'harder than a typical exam question, to stretch them' : 'at real exam standard'

    const system = `You write excellent multiple-choice revision quizzes for UK students.
Subject: ${subject}${pref?.board ? ` (${pref.board})` : ''}. Level: ${state.profile?.level || 'GCSE'}.
Topic: ${topic}. Difficulty: ${difficulty}.
Write ${count} questions that test understanding, not just recall. Each has exactly 4 options with ONE correct answer and
plausible wrong answers based on common mistakes. Use plain-text maths (x², √, ½), never LaTeX.
Return ONLY JSON: { "topic": string, "questions": [ { "question": string, "options": [string, string, string, string], "answerIndex": number, "explanation": string } ] }
"explanation" says in 1-2 sentences why the answer is right and why the most tempting wrong option is wrong.`

    const raw = await generateJson<Record<string, unknown>>(key, system, [{ text: 'Make my quiz.' }], 0.7)
    const questions = objList(raw.questions, count)
      .map((q) => {
        const options = strList(q.options, 4)
        const answer = Math.round(num(q.answerIndex) ?? -1)
        if (options.length !== 4 || answer < 0 || answer > 3) return null
        // Shuffle so the right answer isn't always in the same place.
        const order = [0, 1, 2, 3].sort(() => Math.random() - 0.5)
        return {
          question: str(q.question, 800),
          options: order.map((i) => options[i]),
          answerIndex: order.indexOf(answer),
          explanation: str(q.explanation, 800)
        }
      })
      .filter((q): q is NonNullable<typeof q> => Boolean(q && q.question))
    if (questions.length === 0) throw new GeminiError('The quiz came back empty. Try again.', 'bad-output')
    return { subject, topic: str(raw.topic, 160) || topic, questions }
  })
}

export async function saveQuizResult(r: QuizResult): Promise<StudyState> {
  await store.addQuiz({
    id: str(r.id, 64) || randomUUID(),
    createdAt: Date.now(),
    subject: str(r.subject, 60),
    topic: str(r.topic, 160),
    correct: clamp(Math.round(Number(r.correct) || 0), 0, 50),
    total: clamp(Math.round(Number(r.total) || 1), 1, 50)
  })
  return store.getState()
}

export async function deleteAllData(): Promise<StudyState> {
  await store.deleteAll()
  return store.getState()
}

export const setTaskDone = (id: string, done: boolean): Promise<string[]> => store.setTaskDone(str(id, 64), Boolean(done))
export const deleteHistoryItem = (id: string) => store.deleteHistory(str(id, 64))

/** Appended to the live tutor's instructions so the voice tutor knows the student. */
export async function tutorContext(): Promise<string> {
  const s = await store.getState()
  const parts: string[] = []
  if (s.profile && s.profile.subjects.length) {
    parts.push(`About this student${s.profile.name ? ` (${s.profile.name})` : ''}:\n${describeStudent(s.profile)}`)
  }
  if (s.handwriting) parts.push(`Their handwriting (for reading notes on screen): ${s.handwriting.profile}`)
  const recent = s.history.slice(0, 5).map((h) => `${h.subject} / ${h.topic}: ${h.score.percent ?? '?'}%`)
  if (recent.length) parts.push(`Recent marked work: ${recent.join('; ')}.`)
  if (s.plan) {
    const focus = s.plan.subjects.flatMap((x) => x.topics.map((t) => `${x.subject}: ${t.topic}`)).slice(0, 8)
    parts.push(`Current revision focus: ${focus.join('; ')}.`)
  }
  return parts.length ? `\n\n${parts.join('\n\n')}\nUse this to tailor help, but always prioritise what is on screen right now.` : ''
}
