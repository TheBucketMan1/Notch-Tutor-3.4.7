/**
 * Local persistence for the study hub (main process only).
 *
 * Everything lives in the app's userData folder on this Mac:
 *   study.json               profile, handwriting profile, plan, ticks, marking history
 *   handwriting-sample.bin   the photo of the student's handwriting sample
 *
 * Writes are atomic (write temp file, then rename) so a crash mid-save can
 * never corrupt the file.
 */
import { app } from 'electron'
import { promises as fs } from 'node:fs'
import { join } from 'node:path'
import type { HandwritingProfile, MarkResult, QuizResult, RevisionPlan, StudyProfile, StudyState } from '@shared/study'

const MAX_HISTORY = 100

interface Persisted {
  version: 1
  profile: StudyProfile | null
  handwriting: HandwritingProfile | null
  handwritingSampleMime: string | null
  plan: RevisionPlan | null
  doneTasks: string[]
  history: MarkResult[]
  quizzes: QuizResult[]
  activityDays: string[]
}

const EMPTY: Persisted = {
  version: 1,
  profile: null,
  handwriting: null,
  handwritingSampleMime: null,
  plan: null,
  doneTasks: [],
  history: [],
  quizzes: [],
  activityDays: []
}

const dataPath = (): string => join(app.getPath('userData'), 'study.json')
const samplePath = (): string => join(app.getPath('userData'), 'handwriting-sample.bin')

let cache: Persisted | null = null
let writeChain: Promise<void> = Promise.resolve()

async function load(): Promise<Persisted> {
  if (cache) return cache
  try {
    const raw = JSON.parse(await fs.readFile(dataPath(), 'utf8')) as Partial<Persisted>
    cache = {
      ...EMPTY,
      ...raw,
      doneTasks: raw.doneTasks ?? [],
      history: raw.history ?? [],
      quizzes: raw.quizzes ?? [],
      activityDays: raw.activityDays ?? []
    }
  } catch {
    cache = { ...EMPTY }
  }
  return cache
}

/** Serialised writes: concurrent updates can't interleave. */
function persist(data: Persisted): Promise<void> {
  writeChain = writeChain
    .catch(() => undefined)
    .then(async () => {
      await fs.mkdir(app.getPath('userData'), { recursive: true })
      const tmp = `${dataPath()}.tmp`
      await fs.writeFile(tmp, JSON.stringify(data, null, 2), 'utf8')
      await fs.rename(tmp, dataPath())
    })
  return writeChain
}

async function update(mutator: (d: Persisted) => void): Promise<Persisted> {
  const d = await load()
  mutator(d)
  await persist(d)
  return d
}

export async function getState(): Promise<StudyState> {
  const d = await load()
  return {
    profile: d.profile,
    handwriting: d.handwriting,
    plan: d.plan,
    doneTasks: d.doneTasks,
    history: d.history,
    quizzes: d.quizzes,
    activityDays: d.activityDays
  }
}

/** Local calendar date, e.g. 2026-09-27 (for the study streak). */
const today = (): string => new Date().toLocaleDateString('en-CA')

function markActivity(d: Persisted): void {
  const t = today()
  if (!d.activityDays.includes(t)) d.activityDays = [...d.activityDays, t].slice(-400)
}

export async function addQuiz(result: QuizResult): Promise<void> {
  await update((d) => {
    d.quizzes = [result, ...d.quizzes].slice(0, 200)
    markActivity(d)
  })
}

/** Wipes every piece of study data (settings and API key are kept). */
export async function deleteAll(): Promise<void> {
  await fs.rm(samplePath(), { force: true })
  await update((d) => {
    Object.assign(d, { ...EMPTY, doneTasks: [], history: [], quizzes: [], activityDays: [] })
  })
}

export async function saveProfile(profile: StudyProfile): Promise<void> {
  await update((d) => {
    d.profile = profile
  })
}

export async function saveHandwriting(profile: HandwritingProfile, sample: Buffer, mimeType: string): Promise<void> {
  await fs.mkdir(app.getPath('userData'), { recursive: true })
  await fs.writeFile(samplePath(), sample)
  await update((d) => {
    d.handwriting = profile
    d.handwritingSampleMime = mimeType
  })
}

/** The stored sample photo, sent alongside work so the model can compare letter shapes. */
export async function getHandwritingSample(): Promise<{ data: Buffer; mimeType: string } | null> {
  const d = await load()
  if (!d.handwritingSampleMime) return null
  try {
    return { data: await fs.readFile(samplePath()), mimeType: d.handwritingSampleMime }
  } catch {
    return null
  }
}

export async function savePlan(plan: RevisionPlan): Promise<void> {
  await update((d) => {
    d.plan = plan
    d.doneTasks = [] // new plan, fresh ticks
  })
}

export async function setTaskDone(taskId: string, done: boolean): Promise<string[]> {
  const d = await update((x) => {
    const set = new Set(x.doneTasks)
    if (done) set.add(taskId)
    else set.delete(taskId)
    x.doneTasks = [...set]
    if (done) markActivity(x)
  })
  return d.doneTasks
}

export async function addHistory(result: MarkResult): Promise<void> {
  await update((d) => {
    d.history = [result, ...d.history].slice(0, MAX_HISTORY)
    markActivity(d)
  })
}

export async function deleteHistory(id: string): Promise<MarkResult[]> {
  const d = await update((x) => {
    x.history = x.history.filter((h) => h.id !== id)
  })
  return d.history
}
