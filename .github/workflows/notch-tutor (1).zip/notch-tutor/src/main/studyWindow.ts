/**
 * The study hub: a normal, resizable window (unlike the notch overlay).
 *
 * The app normally has no Dock icon (it's a menu-bar-style utility). While
 * the hub is open we show the Dock icon so it behaves like a regular window
 * (⌘-Tab, Mission Control), and hide it again when the hub closes.
 */
import { app, BrowserWindow, shell } from 'electron'
import { join } from 'node:path'

let hub: BrowserWindow | null = null

export function getHub(): BrowserWindow | null {
  return hub && !hub.isDestroyed() ? hub : null
}

export function openStudyHub(): BrowserWindow {
  const existing = getHub()
  if (existing) {
    if (existing.isMinimized()) existing.restore()
    existing.show()
    existing.focus()
    return existing
  }

  hub = new BrowserWindow({
    width: 1120,
    height: 780,
    minWidth: 760,
    minHeight: 560,
    show: false,
    title: 'Study hub',
    backgroundColor: '#ffffff',
    titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default',
    webPreferences: {
      preload: join(__dirname, '../preload/index.js'),
      contextIsolation: true,
      sandbox: true,
      nodeIntegration: false,
      spellcheck: true
    }
  })

  // Links only ever open in the user's browser; the hub never navigates away.
  hub.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('https://')) void shell.openExternal(url)
    return { action: 'deny' }
  })
  hub.webContents.on('will-navigate', (e) => e.preventDefault())

  hub.once('ready-to-show', () => {
    if (process.platform === 'darwin') void app.dock?.show()
    hub?.show()
    hub?.focus()
    app.focus({ steal: true })
  })

  hub.on('closed', () => {
    hub = null
    if (process.platform === 'darwin') app.dock?.hide()
  })

  if (process.env.ELECTRON_RENDERER_URL) {
    void hub.loadURL(`${process.env.ELECTRON_RENDERER_URL}/study.html`)
  } else {
    void hub.loadFile(join(__dirname, '../renderer/study.html'))
  }
  return hub
}
