/**
 * The notch window: frameless, transparent, always-on-top, click-through,
 * pinned to the top-center of the primary display, and hidden from screen
 * capture (so the tutor never "sees" its own UI in the frames we send).
 *
 * The window is a fixed transparent canvas big enough for the EXPANDED pill.
 * The pill itself grows/shrinks with CSS inside it, which is far smoother than
 * animating native window bounds (setBounds animations stutter on Windows and
 * cause compositor churn on macOS).
 */
import { BrowserWindow, screen, shell } from 'electron'
import { join } from 'node:path'

/** Canvas size – must fit the fully expanded pill + its shadow. */
export const WINDOW_WIDTH = 480
export const WINDOW_HEIGHT = 340

export function createNotchWindow(): BrowserWindow {
  const { x, y } = topCenterOfPrimary()

  const win = new BrowserWindow({
    width: WINDOW_WIDTH,
    height: WINDOW_HEIGHT,
    x,
    y,
    show: false,
    frame: false,
    transparent: true,
    backgroundColor: '#00000000',
    hasShadow: false, // shadow is drawn in CSS around the pill, not the canvas
    resizable: false,
    movable: false,
    minimizable: false,
    maximizable: false,
    fullscreenable: false,
    skipTaskbar: true,
    alwaysOnTop: true,
    // Non-focusable = clicking the notch doesn't steal focus from the app the
    // user is working in (their editor keeps the cursor). We flip this on only
    // while the API-key field needs typing.
    focusable: false,
    // macOS: lets the window sit over the menu bar, flush with the hardware
    // notch, instead of being pushed below it by the window server.
    enableLargerThanScreen: true,
    roundedCorners: false,
    title: 'Notch Tutor',
    webPreferences: {
      preload: join(__dirname, '../preload/index.js'),
      contextIsolation: true,
      sandbox: true,
      nodeIntegration: false,
      webSecurity: true,
      spellcheck: false,
      // Critical for realtime: never throttle timers/rAF/audio when the window
      // isn't focused (it almost never is).
      backgroundThrottling: false,
      // AudioContext must start from a global shortcut, not only a click.
      autoplayPolicy: 'no-user-gesture-required'
    }
  })

  // Float above fullscreen apps, the Dock and menu bar ('screen-saver' level).
  win.setAlwaysOnTop(true, 'screen-saver', 1)
  win.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true, skipTransformProcessType: true })

  // Exclude from screen capture: macOS sharingType=none; Windows 10 2004+
  // WDA_EXCLUDEFROMCAPTURE. Our own frames stay clean.
  win.setContentProtection(true)

  // Start fully click-through; `forward: true` still delivers mousemove to the
  // renderer so it can detect hover over the pill and turn clicks back on.
  win.setIgnoreMouseEvents(true, { forward: true })

  // Hardening: this window never navigates or opens popups.
  win.webContents.on('will-navigate', (e) => e.preventDefault())
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('https://')) void shell.openExternal(url)
    return { action: 'deny' }
  })

  win.once('ready-to-show', () => win.showInactive()) // show without stealing focus

  // Keep pinned when monitors are added/removed/rearranged or resolution changes.
  const recenter = (): void => {
    if (win.isDestroyed()) return
    const p = topCenterOfPrimary()
    win.setBounds({ x: p.x, y: p.y, width: WINDOW_WIDTH, height: WINDOW_HEIGHT })
  }
  screen.on('display-metrics-changed', recenter)
  screen.on('display-added', recenter)
  screen.on('display-removed', recenter)
  win.on('closed', () => {
    screen.removeListener('display-metrics-changed', recenter)
    screen.removeListener('display-added', recenter)
    screen.removeListener('display-removed', recenter)
  })

  if (process.env.ELECTRON_RENDERER_URL) {
    void win.loadURL(process.env.ELECTRON_RENDERER_URL) // electron-vite dev server (HMR)
  } else {
    void win.loadFile(join(__dirname, '../renderer/index.html'))
  }
  return win
}

/** Toggle click-through. `wantsKeyboard` temporarily makes the window focusable. */
export function setWindowInteractive(win: BrowserWindow, interactive: boolean, wantsKeyboard = false): void {
  if (win.isDestroyed()) return
  win.setIgnoreMouseEvents(!interactive, { forward: true })
  if (wantsKeyboard) {
    win.setFocusable(true)
    win.focus()
  } else if (win.isFocusable()) {
    win.setFocusable(false)
  }
}

function topCenterOfPrimary(): { x: number; y: number } {
  const d = screen.getPrimaryDisplay()
  // Use full bounds (not workArea) so we sit at the very top edge like a notch.
  // On Windows the top edge is free; on macOS we overlay the menu bar center.
  return {
    x: Math.round(d.bounds.x + (d.bounds.width - WINDOW_WIDTH) / 2),
    y: d.bounds.y
  }
}
