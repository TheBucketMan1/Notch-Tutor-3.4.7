/**
 * Preload (sandboxed, contextIsolation on).
 *
 * Exposes a tiny, typed, capability-scoped API as `window.notch`. No generic
 * `ipcRenderer.send(channel, ...)` passthrough – the renderer can only do the
 * handful of things listed here.
 *
 * MessagePorts cannot cross the contextBridge, so the data-plane port is
 * re-posted into the main world with window.postMessage (the pattern the
 * Electron docs recommend).
 */
import { contextBridge, ipcRenderer, type IpcRendererEvent } from 'electron'
import { IPC, type NotchApi, type SessionStateEvent } from '@shared/protocol'
import { STUDY_IPC, type AppSettings, type StudyApi } from '@shared/study'

/** Subscribe to a main→renderer push; returns an unsubscribe function. */
function subscribe(channel: string, cb: (payload: unknown) => void): () => void {
  const listener = (_e: IpcRendererEvent, payload: unknown): void => cb(payload)
  ipcRenderer.on(channel, listener)
  return () => ipcRenderer.removeListener(channel, listener)
}

ipcRenderer.on(IPC.mediaPort, (event: IpcRendererEvent) => {
  // Same window, same document; '*' is required because file:// origins are "null".
  window.postMessage({ type: IPC.mediaPort }, '*', event.ports)
})

const api: NotchApi = {
  startSession: () => ipcRenderer.invoke(IPC.sessionStart),
  stopSession: () => ipcRenderer.invoke(IPC.sessionStop),
  keyStatus: () => ipcRenderer.invoke(IPC.keyStatus),
  setKey: (key) => ipcRenderer.invoke(IPC.keySet, key),
  clearKey: () => ipcRenderer.invoke(IPC.keyClear),
  ensurePermissions: () => ipcRenderer.invoke(IPC.permEnsure),
  setInteractive: (interactive, wantsKeyboard = false) =>
    ipcRenderer.send(IPC.windowInteractive, interactive, wantsKeyboard),
  quit: () => ipcRenderer.send(IPC.quit),
  openStudyHub: () => ipcRenderer.send(STUDY_IPC.open),
  requestMediaPort: () => ipcRenderer.send(IPC.mediaPortRequest),
  onSessionState: (cb) => {
    const listener = (_e: IpcRendererEvent, payload: SessionStateEvent): void => cb(payload)
    ipcRenderer.on(IPC.sessionState, listener)
    return () => ipcRenderer.removeListener(IPC.sessionState, listener)
  },
  onShortcutToggle: (cb) => subscribe(IPC.shortcutToggle, () => cb()),
  onStartRequest: (cb) => subscribe(IPC.startRequest, () => cb()),
  onPtt: (cb) => subscribe(IPC.ptt, (down) => cb(down === true)),
  platform: process.platform
}

contextBridge.exposeInMainWorld('notch', api)

/** Study hub API. Only the notch and study windows can call it (checked in main). */
const study: StudyApi = {
  getState: () => ipcRenderer.invoke(STUDY_IPC.getState),
  saveProfile: (p) => ipcRenderer.invoke(STUDY_IPC.saveProfile, p),
  analyzeHandwriting: (f) => ipcRenderer.invoke(STUDY_IPC.analyzeHandwriting, f),
  generatePlan: () => ipcRenderer.invoke(STUDY_IPC.generatePlan),
  setTaskDone: (id, done) => ipcRenderer.invoke(STUDY_IPC.setTaskDone, id, done),
  markWork: (req) => ipcRenderer.invoke(STUDY_IPC.markWork, req),
  deleteHistoryItem: (id) => ipcRenderer.invoke(STUDY_IPC.deleteHistory, id),
  ensureCamera: () => ipcRenderer.invoke(STUDY_IPC.ensureCamera),
  openExternal: (url) => ipcRenderer.send(STUDY_IPC.openExternal, url),
  getOpenAtLogin: () => ipcRenderer.invoke(STUDY_IPC.getOpenAtLogin),
  setOpenAtLogin: (on) => ipcRenderer.invoke(STUDY_IPC.setOpenAtLogin, on),
  makeQuiz: (req) => ipcRenderer.invoke(STUDY_IPC.makeQuiz, req),
  saveQuizResult: (r) => ipcRenderer.invoke(STUDY_IPC.saveQuiz, r),
  deleteAllData: () => ipcRenderer.invoke(STUDY_IPC.deleteAll),
  getSettings: () => ipcRenderer.invoke(STUDY_IPC.getSettings),
  updateSettings: (patch) => ipcRenderer.invoke(STUDY_IPC.updateSettings, patch),
  recordPttKey: () => ipcRenderer.invoke(STUDY_IPC.recordKey),
  getAccessibility: () => ipcRenderer.invoke(STUDY_IPC.accessibility),
  requestAccessibility: () => ipcRenderer.invoke(STUDY_IPC.requestAccessibility),
  keyStatus: () => ipcRenderer.invoke(STUDY_IPC.keyStatus),
  setApiKey: (key) => ipcRenderer.invoke(STUDY_IPC.setApiKey, key),
  removeApiKey: () => ipcRenderer.invoke(STUDY_IPC.removeApiKey),
  startTutor: () => ipcRenderer.send(STUDY_IPC.startTutor),
  onNavigate: (cb) => subscribe(STUDY_IPC.navigate, (tab) => cb(String(tab))),
  onSettingsChanged: (cb) => subscribe(IPC.settingsChanged, (s) => cb(s as AppSettings))
}
contextBridge.exposeInMainWorld('study', study)
