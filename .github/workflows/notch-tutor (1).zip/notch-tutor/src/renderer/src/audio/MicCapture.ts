/**
 * MicCapture – getUserMedia → AudioWorklet → 40 ms PCM16 @ 16 kHz chunks.
 *
 * Latency notes:
 *  • The AudioContext runs at 16 kHz, so Chromium's high-quality resampler
 *    does 48k→16k natively (no JS resampling, no aliasing from naive decimation).
 *  • echoCancellation stays ON: it removes the tutor's own voice from the mic
 *    when using speakers, which is what keeps server VAD from "interrupting"
 *    itself. Chromium's AEC works best when playback happens in the same
 *    renderer, which is why PcmPlayer lives here too.
 */
import { AUDIO_IN_RATE } from '@shared/protocol'
import { CAPTURE_WORKLET_SOURCE, addWorkletModule } from './worklets'

const CHUNK_MS = 40

export class MicCapture {
  private stream: MediaStream | null = null
  private ctx: AudioContext | null = null
  private node: AudioWorkletNode | null = null
  private sink: GainNode | null = null
  private muted = false

  /** Smoothed RMS 0..~0.5 for the UI meter. */
  level = 0

  constructor(
    private readonly onChunk: (pcm: ArrayBuffer) => void,
    private readonly onEnded: (reason: string) => void
  ) {}

  async start(deviceId?: string): Promise<void> {
    this.stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        ...(deviceId ? { deviceId: { exact: deviceId } } : {}),
        channelCount: 1,
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true
      },
      video: false
    })

    const track = this.stream.getAudioTracks()[0]
    track.addEventListener('ended', () => this.onEnded('Microphone disconnected.'))

    this.ctx = new AudioContext({ sampleRate: AUDIO_IN_RATE, latencyHint: 'interactive' })
    await addWorkletModule(this.ctx, CAPTURE_WORKLET_SOURCE)

    const source = this.ctx.createMediaStreamSource(this.stream)
    this.node = new AudioWorkletNode(this.ctx, 'pcm-capture', {
      numberOfInputs: 1,
      numberOfOutputs: 1,
      channelCount: 1,
      channelCountMode: 'explicit', // downmix anything to mono before the worklet
      channelInterpretation: 'speakers',
      processorOptions: { chunkSamples: Math.round((AUDIO_IN_RATE * CHUNK_MS) / 1000) }
    })

    this.node.port.onmessage = (e: MessageEvent<{ pcm: ArrayBuffer | null; level: number }>) => {
      // Fast attack, slow release → a meter that feels responsive but not jittery.
      const l = e.data.level
      this.level = l > this.level ? l : this.level * 0.85 + l * 0.15
      if (e.data.pcm && !this.muted) this.onChunk(e.data.pcm)
    }

    // The graph must reach the destination to be pulled; route through a
    // zero-gain node so nothing is audible (no self-monitoring feedback).
    this.sink = this.ctx.createGain()
    this.sink.gain.value = 0
    source.connect(this.node).connect(this.sink).connect(this.ctx.destination)

    if (this.ctx.state === 'suspended') await this.ctx.resume()
  }

  setMuted(muted: boolean): void {
    this.muted = muted
    // Also stop the worklet from allocating chunks we'd discard.
    this.node?.port.postMessage({ type: 'enable', value: !muted })
  }

  get isMuted(): boolean {
    return this.muted
  }

  async stop(): Promise<void> {
    this.node?.port.close()
    this.node?.disconnect()
    this.sink?.disconnect()
    this.stream?.getTracks().forEach((t) => t.stop())
    if (this.ctx && this.ctx.state !== 'closed') await this.ctx.close()
    this.node = null
    this.sink = null
    this.stream = null
    this.ctx = null
    this.level = 0
  }
}
