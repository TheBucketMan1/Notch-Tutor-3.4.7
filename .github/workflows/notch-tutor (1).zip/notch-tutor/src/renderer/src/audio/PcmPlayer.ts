/**
 * PcmPlayer – plays the model's streamed PCM16 @ 24 kHz with a jitter buffer.
 *
 * Why a worklet ring buffer instead of scheduling AudioBufferSourceNodes:
 * scheduling hundreds of tiny buffers drifts, clicks at seams, and can't be
 * cancelled instantly. A ring buffer is gapless and flushes in one quantum.
 */
import { AUDIO_OUT_RATE } from '@shared/protocol'
import { PLAYER_WORKLET_SOURCE, addWorkletModule } from './worklets'

export class PcmPlayer {
  private ctx: AudioContext | null = null
  private node: AudioWorkletNode | null = null

  level = 0
  playing = false
  /** Samples queued but not yet played (useful for debugging latency). */
  buffered = 0

  async start(): Promise<void> {
    this.ctx = new AudioContext({ sampleRate: AUDIO_OUT_RATE, latencyHint: 'interactive' })
    await addWorkletModule(this.ctx, PLAYER_WORKLET_SOURCE)
    this.node = new AudioWorkletNode(this.ctx, 'pcm-player', {
      numberOfInputs: 0,
      numberOfOutputs: 1,
      outputChannelCount: [1],
      processorOptions: {
        prebufferSamples: Math.round(AUDIO_OUT_RATE * 0.06), // 60 ms
        capacitySamples: AUDIO_OUT_RATE * 120
      }
    })
    this.node.port.onmessage = (e: MessageEvent<{ level: number; playing: boolean; buffered: number }>) => {
      this.level = e.data.level
      this.playing = e.data.playing
      this.buffered = e.data.buffered
    }
    this.node.connect(this.ctx.destination)
    if (this.ctx.state === 'suspended') await this.ctx.resume()
  }

  /** Queue a PCM16 LE chunk. The buffer is transferred to the audio thread. */
  enqueue(chunk: ArrayBuffer | Uint8Array): void {
    if (!this.node) return
    let ab: ArrayBuffer =
      chunk instanceof ArrayBuffer
        ? chunk
        : (chunk.buffer.slice(chunk.byteOffset, chunk.byteOffset + chunk.byteLength) as ArrayBuffer)
    if (ab.byteLength % 2 !== 0) ab = ab.slice(0, ab.byteLength - 1) // guard malformed odd tails
    if (ab.byteLength === 0) return
    this.node.port.postMessage({ type: 'push', pcm: ab }, [ab])
  }

  /** User interrupted: silence immediately. */
  flush(): void {
    this.node?.port.postMessage({ type: 'flush' })
  }

  /** Model finished the turn: play out whatever remains, even below prebuffer. */
  drain(): void {
    this.node?.port.postMessage({ type: 'drain' })
  }

  async stop(): Promise<void> {
    this.node?.port.close()
    this.node?.disconnect()
    if (this.ctx && this.ctx.state !== 'closed') await this.ctx.close()
    this.node = null
    this.ctx = null
    this.level = 0
    this.playing = false
  }
}
