/**
 * AudioWorklet processors, shipped as source strings and loaded via Blob URLs.
 *
 * Why strings: worklet modules are fetched by URL at runtime. Blob URLs behave
 * identically in the Vite dev server and in a packaged app loaded from
 * file:// inside an asar – no bundler special-casing, no path breakage.
 * (CSP allows `script-src blob:` for exactly this.)
 *
 * Both processors run on the real-time audio thread: no allocation in the hot
 * loop except when a finished chunk is handed off (and that buffer is
 * transferred, not copied).
 */

/**
 * pcm-capture: Float32 @ context rate (16 kHz – Chromium resamples the mic for
 * us because the AudioContext is created at 16 kHz) → Int16 LE chunks.
 *
 * Chunk size trades latency vs. per-message overhead. 40 ms = 640 samples =
 * 1280 bytes → 25 WebSocket messages/s, well within budget, and below the
 * ~100 ms at which VAD/barge-in start to feel sluggish.
 */
export const CAPTURE_WORKLET_SOURCE = /* js */ `
class PcmCaptureProcessor extends AudioWorkletProcessor {
  constructor(options) {
    super();
    const o = (options && options.processorOptions) || {};
    this.chunk = o.chunkSamples || 640;
    this.buf = new Int16Array(this.chunk);
    this.idx = 0;
    this.sumSq = 0;
    this.enabled = true;
    this.port.onmessage = (e) => {
      if (e.data && e.data.type === 'enable') this.enabled = !!e.data.value;
    };
  }

  process(inputs) {
    const input = inputs[0];
    if (!input || input.length === 0) return true;
    const ch = input[0];               // mono (channelCount forced to 1)
    if (!ch) return true;

    for (let i = 0; i < ch.length; i++) {
      let s = ch[i];
      s = s < -1 ? -1 : s > 1 ? 1 : s; // clip
      this.sumSq += s * s;
      this.buf[this.idx++] = s < 0 ? s * 0x8000 : s * 0x7fff;

      if (this.idx === this.chunk) {
        const level = Math.sqrt(this.sumSq / this.chunk);
        if (this.enabled) {
          const out = this.buf.buffer;
          this.port.postMessage({ pcm: out, level }, [out]); // transfer, zero-copy
          this.buf = new Int16Array(this.chunk);
        } else {
          this.port.postMessage({ pcm: null, level });      // keep the meter alive while muted
        }
        this.idx = 0;
        this.sumSq = 0;
      }
    }
    return true;
  }
}
registerProcessor('pcm-capture', PcmCaptureProcessor);
`

/**
 * pcm-player: ring-buffer jitter buffer for streamed PCM16 @ 24 kHz.
 *
 *  • Prebuffer (~60 ms) before starting a turn so network jitter doesn't cause
 *    crackle; after an underrun we re-prebuffer instead of stuttering.
 *  • 'drain' (sent on turnComplete) plays out the tail even if it's shorter
 *    than the prebuffer threshold.
 *  • 'flush' (sent on interruption) empties instantly: barge-in latency is one
 *    render quantum (~5 ms) after the message arrives.
 *  • Reports output level + playing state every ~50 ms for the UI.
 */
export const PLAYER_WORKLET_SOURCE = /* js */ `
class PcmPlayerProcessor extends AudioWorkletProcessor {
  constructor(options) {
    super();
    const o = (options && options.processorOptions) || {};
    this.cap = o.capacitySamples || sampleRate * 120;            // 2 minutes max backlog
    this.ring = new Float32Array(this.cap);
    this.r = 0; this.w = 0; this.size = 0;
    this.prebuffer = o.prebufferSamples || Math.round(sampleRate * 0.06);
    this.playing = false;
    this.draining = false;
    this.reportEvery = Math.round(sampleRate * 0.05);
    this.sinceReport = 0;
    this.sumSq = 0; this.n = 0;

    this.port.onmessage = (e) => {
      const m = e.data;
      if (!m) return;
      if (m.type === 'push') this.push(new Int16Array(m.pcm));
      else if (m.type === 'flush') { this.r = this.w = this.size = 0; this.playing = false; this.draining = false; }
      else if (m.type === 'drain') this.draining = true;
    };
  }

  push(pcm) {
    this.draining = false;                  // new audio → new/continuing turn
    const cap = this.cap, ring = this.ring;
    for (let i = 0; i < pcm.length; i++) {
      if (this.size === cap) { this.r = (this.r + 1) % cap; this.size--; } // overwrite oldest
      ring[this.w] = pcm[i] / 32768;
      this.w = (this.w + 1) % cap;
      this.size++;
    }
  }

  process(_inputs, outputs) {
    const out = outputs[0];
    const ch0 = out[0];
    if (!ch0) return true;

    if (!this.playing && (this.size >= this.prebuffer || (this.draining && this.size > 0))) {
      this.playing = true;
    }

    const cap = this.cap, ring = this.ring;
    for (let i = 0; i < ch0.length; i++) {
      let v = 0;
      if (this.playing && this.size > 0) {
        v = ring[this.r];
        this.r = (this.r + 1) % cap;
        this.size--;
      }
      ch0[i] = v;
      this.sumSq += v * v;
    }
    for (let c = 1; c < out.length; c++) out[c].set(ch0);

    if (this.playing && this.size === 0) {
      this.playing = false;                // underrun or end of turn → rebuffer
      this.draining = false;
    }

    this.n += ch0.length;
    this.sinceReport += ch0.length;
    if (this.sinceReport >= this.reportEvery) {
      this.port.postMessage({ level: Math.sqrt(this.sumSq / this.n), playing: this.playing, buffered: this.size });
      this.sinceReport = 0; this.sumSq = 0; this.n = 0;
    }
    return true;
  }
}
registerProcessor('pcm-player', PcmPlayerProcessor);
`

/** Registers a worklet module from source; revokes the Blob URL afterwards. */
export async function addWorkletModule(ctx: BaseAudioContext, source: string): Promise<void> {
  const url = URL.createObjectURL(new Blob([source], { type: 'text/javascript' }))
  try {
    await ctx.audioWorklet.addModule(url)
  } finally {
    URL.revokeObjectURL(url)
  }
}
