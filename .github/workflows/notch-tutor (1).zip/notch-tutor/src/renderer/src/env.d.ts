/// <reference types="vite/client" />
import type { NotchApi } from '@shared/protocol'
import type { StudyApi } from '@shared/study'

declare global {
  interface Window {
    /** Exposed by src/preload/index.ts via contextBridge. */
    notch: NotchApi
    /** Study hub API (preload). */
    study: StudyApi
  }
}

interface ImportMetaEnv {
  /** Build-time (non-secret) screen sampling interval. */
  readonly RENDERER_VITE_SCREEN_INTERVAL_MS?: string
}

export {}
