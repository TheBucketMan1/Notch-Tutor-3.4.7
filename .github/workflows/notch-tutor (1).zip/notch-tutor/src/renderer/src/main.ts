/**
 * Renderer orchestrator.
 *
 *   ┌──────────── renderer ────────────┐        ┌───────── main ─────────┐
 *   │ MicCapture ─ PCM16 16k ─┐        │  Port  │                        │   wss
 *   │ ScreenSampler ─ JPEG ───┼────────┼───────▶│ MediaBridge → Gemini ──┼──────▶
 *   │ PcmPlayer ◀─ PCM16 24k ─┘◀───────┼────────│ ◀──────────── Live   ◀─┼──────
 *   │ Pill (UI)                        │  IPC   │ window/permissions/key │
 *   └──────────────────────────────────┘        └────────────────────────┘
 *
 * Start-up latency trick: the WebSocket handshake + setup and the device
 * start-up (mic, AudioContexts, screen capture) run IN PARALLEL.
 */
import './styles.css'
import { IPC, type MainToRenderer, type RendererToMain, type SessionState } from '@shared/protocol'
import { DEFAULT_SETTINGS, type AppSettings } from '@shared/study'
import { MicCapture } from './audio/MicCapture'
import { PcmPlayer } from './audio/PcmPlayer'
import { ScreenSampler } from './video/ScreenSampler'
import { Pill } from './ui/Pill'

const api = window.notch
const SCREEN_INTERVAL_MS = Number(import.meta.env.RENDERER_VITE_SCREEN_INTERVAL_MS) || 1000

// Speech-onset detection (hysteresis) → force a fresh screen frame.
const SPEECH_ON = 0.04
const SPEECH_OFF = 0.015

let state: SessionState = 'idle'
let starting = false
let mic: MicCapture | null = null
let player: PcmPlayer | null = null
let sampler: ScreenSampler | null = null
let settings: AppSettings = { ...DEFAULT_SETTINGS }
/** Push-to-talk key (or on-screen button) currently held. */
let holding = false
/** An activityStart has been sent without its matching activityEnd. */
let activityOpen = false
/** Talk mode the current session was started with (Gemini can't switch mid-session). */
let sessionTalkMode: AppSettings['talkMode'] | null = null

// ───────────────────────────── data plane ─────────────────────────────

let port: MessagePort | null = null
const portWaiters: Array<(p: MessagePort) => void> = []

window.addEventListener('message', (e: MessageEvent) => {
  if (e.source !== window || e.data?.type !== IPC.mediaPort || !e.ports[0]) return
  port?.close()
  port = e.ports[0]
  port.onmessage = (ev: MessageEvent<MainToRenderer>) => onMainMessage(ev.data)
  port.start()
  for (const resolve of portWaiters.splice(0)) resolve(port)
})
api.requestMediaPort()

const getPort = (): Promise<MessagePort> =>
  port ? Promise.resolve(port) : new Promise((resolve) => portWaiters.push(resolve))

/** Binary is structured-cloned across the process boundary (a ~1–100 KB memcpy). */
function send(msg: RendererToMain): void {
  port?.postMessage(msg)
}

function onMainMessage(m: MainToRenderer): void {
  switch (m.t) {
    case 'audio':
      player?.enqueue(m.buf)
      break
    case 'interrupted':
      player?.flush() // barge-in: silence within one audio quantum
      pill.endTutorLine()
      break
    case 'turnComplete':
      player?.drain()
      pill.endTutorLine()
      break
    case 'transcript':
      pill.pushTranscript(m.role, m.text)
      break
    case 'question':
      pill.showQuestion(m.question, m.hint)
      break
  }
}

// ───────────────────────────── UI ─────────────────────────────

const pill = new Pill(
  document.getElementById('pill') as HTMLElement,
  {
    onPrimary: () => void (isActive() ? stop() : start()),
    onMute: toggleMute,
    onHold: (down) => setHolding(down),
    onAsk: (text, question) =>
      send({ t: 'text', text: question ? `My answer to your question "${question}": ${text}` : text }),
    onScreen: toggleScreen,
    onQuit: () => api.quit(),
    onStudy: () => api.openStudyHub(),
    onSaveKey: (key) => void saveKey(key),
    setInteractive: (i, kb) => api.setInteractive(i, kb)
  },
  () => ({
    you: mic?.level ?? 0,
    tutor: player?.level ?? 0,
    tutorSpeaking: player?.playing ?? false
  })
)

api.onSessionState(({ state: s, detail }) => {
  state = s
  if (s === 'error') {
    void teardownMedia()
    pill.setError(detail ?? 'The session ended unexpectedly.')
  } else if (s === 'idle') {
    void teardownMedia()
    pill.setState('idle')
  } else {
    pill.setState(s, detail)
  }
})

api.onShortcutToggle(() => void (isActive() ? stop() : start()))
api.onStartRequest(() => void start())
api.onPtt((down) => setHolding(down))

// Settings (talk mode, key, face) come from the main process and live-update.
function applySettings(s: AppSettings): void {
  const modeChanged = sessionTalkMode !== null && sessionTalkMode !== s.talkMode
  settings = s
  pill.configure({ talkMode: s.talkMode, keyName: s.pttKeyName, showFace: s.showFace })
  if (s.talkMode === 'always') pill.setMuted(false)
  // The talk mode is fixed when a session starts, so restart to apply it.
  if (modeChanged && state === 'live') void stop().then(() => start())
}
void window.study.getSettings().then(applySettings)
window.study.onSettingsChanged(applySettings)

/**
 * Hold-to-talk. Pressing interrupts the tutor instantly, un-mutes the mic and
 * grabs a fresh screen frame; releasing mutes and tells Gemini you've finished.
 * Pressing while idle starts a session.
 */
function setHolding(down: boolean): void {
  if (settings.talkMode !== 'hold') return
  if (down === holding) return
  holding = down
  pill.setHolding(down)
  if (down) {
    if (!isActive()) {
      void start() // begins talking once connected (see start())
      return
    }
    if (state === 'live') beginUtterance()
  } else {
    endUtterance()
  }
}

/** Key down: tell Gemini you're speaking (this also interrupts it), then open the mic. */
function beginUtterance(): void {
  if (activityOpen || !mic) return
  player?.flush()
  sampler?.forceNext()
  send({ t: 'activityStart' })
  activityOpen = true
  mic.setMuted(false)
}

/** Key up: close the mic and tell Gemini you've finished, so it answers now. */
function endUtterance(): void {
  mic?.setMuted(true)
  if (!activityOpen) return
  activityOpen = false
  send({ t: 'activityEnd' })
}

function isActive(): boolean {
  return starting || state === 'live' || state === 'connecting' || state === 'reconnecting'
}

// ───────────────────────────── session control ─────────────────────────────

async function start(): Promise<void> {
  if (isActive()) return
  starting = true
  try {
    const key = await api.keyStatus()
    if (!key.hasKey) {
      pill.showKeyPanel()
      return
    }

    pill.setState('connecting')
    const perms = await api.ensurePermissions()
    if (perms.microphone === 'denied') {
      pill.setError('Microphone access is off. Turn it on in system settings, then start again.')
      return
    }
    await getPort()

    player = new PcmPlayer()
    mic = new MicCapture(
      (pcm) => send({ t: 'audio', buf: pcm }),
      (reason) => void fail(reason)
    )
    // Hold mode: the mic stays closed until the key is held AND the session is live.
    mic.setMuted(settings.talkMode === 'hold')
    sampler =
      perms.screen === 'denied'
        ? null
        : new ScreenSampler(
            (jpeg) => send({ t: 'frame', buf: jpeg }),
            (reason) => {
              sampler?.stop()
              sampler = null
              pill.setScreenAvailable(false)
              pill.notice(`${reason} The tutor can still hear you.`)
            },
            { intervalMs: SCREEN_INTERVAL_MS }
          )

    // Parallel: socket handshake overlaps device start-up.
    const screenStart = sampler?.start().catch((err: unknown) => {
      console.warn('[notch] screen capture unavailable', err)
      sampler = null
    })
    const [result] = await Promise.all([api.startSession(), player.start(), mic.start(), screenStart])

    if (!result.ok) {
      await teardownMedia()
      if (result.code === 'NO_KEY' || result.code === 'BAD_KEY') pill.showKeyPanel(result.error)
      else pill.setError(result.error)
      return
    }

    sessionTalkMode = settings.talkMode
    // Key was pressed to start the session and is still held: start listening now.
    if (settings.talkMode === 'hold' && holding) beginUtterance()
    pill.setScreenAvailable(Boolean(sampler))
    if (!sampler) pill.notice('Screen sharing is off, so the tutor can hear you but can’t see your screen.')
    else if (settings.talkMode === 'hold') {
      const access = await window.study.getAccessibility()
      if (access.required && !access.granted) {
        pill.notice(`To talk with ${settings.pttKeyName}, open Study hub, then Settings, and click Allow access. Until then, hold “Hold to talk” here.`)
      }
    }
  } catch (err) {
    await fail(describeMediaError(err))
  } finally {
    starting = false
  }
}

async function stop(): Promise<void> {
  await api.stopSession() // main pushes 'idle' → teardown via onSessionState
  await teardownMedia()
  pill.setState('idle')
}

async function fail(message: string): Promise<void> {
  await api.stopSession().catch(() => undefined)
  await teardownMedia()
  pill.setError(message)
}

async function teardownMedia(): Promise<void> {
  holding = false
  activityOpen = false
  sessionTalkMode = null
  pill.setHolding(false)
  // Null out first so re-entrant calls are no-ops.
  const m = mic
  const p = player
  const s = sampler
  mic = null
  player = null
  sampler = null
  s?.stop()
  await Promise.allSettled([m?.stop(), p?.stop()])
}

function toggleMute(): void {
  if (!mic || settings.talkMode === 'hold') return
  const muted = !mic.isMuted
  mic.setMuted(muted)
  // Tell server VAD the stream paused on purpose so it closes the turn now.
  if (muted) send({ t: 'audioEnd' })
  pill.setMuted(muted)
}

function toggleScreen(): void {
  if (!sampler) return
  if (sampler.isPaused) sampler.resume()
  else sampler.pause()
  pill.setScreenPaused(sampler.isPaused)
}

async function saveKey(key: string): Promise<void> {
  const res = await api.setKey(key)
  if (!res.ok) {
    pill.showKeyPanel(res.error)
    return
  }
  pill.hideKeyPanel()
  void start()
}

// ───────────────────────────── speech onset → fresh frame ─────────────────────────────

let speaking = false
setInterval(() => {
  if (!mic || !sampler || mic.isMuted) return
  const l = mic.level
  if (!speaking && l > SPEECH_ON) {
    speaking = true
    sampler.forceNext() // the question ships with what's on screen right now
  } else if (speaking && l < SPEECH_OFF) {
    speaking = false
  }
}, 50)

function describeMediaError(err: unknown): string {
  const name = (err as DOMException)?.name
  switch (name) {
    case 'NotAllowedError':
      return 'Microphone access was blocked. Allow it in system settings, then start again.'
    case 'NotFoundError':
      return 'No microphone found. Connect one and start again.'
    case 'NotReadableError':
      return 'Your microphone is busy in another app. Close it there and start again.'
    default:
      return (err as Error)?.message || 'Something went wrong starting the session.'
  }
}
