/**
 * Pill – the notch UI. Pure DOM, no framework.
 *
 * Modes (data-attributes on the root; CSS animates between them):
 *   compact   black bar at the top edge: the tutor's face + status on the left,
 *             voice wave on the right, empty middle where a camera notch sits.
 *   peek      grows to show the live caption while the tutor speaks
 *             (still click-through, so it never blocks your work).
 *   question  the tutor asked something: the question + a typing bar stay
 *             visible until you answer or dismiss it.
 *   expanded  on hover: caption, typing bar and controls.
 *
 * The face: yellow while the tutor talks (mouth moves with its voice),
 * blue while you talk, grey when idle. Eyes blink every few seconds.
 */
import type { SessionState } from '@shared/protocol'

export interface PillHandlers {
  onPrimary(): void
  /** Hold mode: talk button pressed (true) / released (false). */
  onHold(down: boolean): void
  /** Always-listening mode: mute toggle. */
  onMute(): void
  onScreen(): void
  onStudy(): void
  onQuit(): void
  onSaveKey(key: string): void
  /** Typed message. `question` is set when answering a question the tutor showed. */
  onAsk(text: string, question: string | null): void
  setInteractive(interactive: boolean, wantsKeyboard?: boolean): void
}

export interface LevelSource {
  you: number
  tutor: number
  tutorSpeaking: boolean
}

const PEEK_LINGER_MS = 5000
const CAPTION_MAX_CHARS = 220

type Mood = 'idle' | 'thinking' | 'listening' | 'talking'

export class Pill {
  private readonly el
  private state: SessionState = 'idle'
  private hovered = false
  private typing = false
  private muted = false
  private holding = false
  private talkMode: 'hold' | 'always' = 'hold'
  private keyName = 'Right Option'
  private screenPaused = false
  private tutorLine = ''
  private userLine = ''
  private question: { text: string; hint: string } | null = null
  private peekTimer: ReturnType<typeof setTimeout> | null = null
  private raf = 0
  private amp = 0
  private mouthOpen = 0
  private readonly reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches
  private colors = { you: '#7cc4ff', tutor: '#ffd27a', quiet: '#5c5c61' }

  constructor(
    root: HTMLElement,
    private readonly handlers: PillHandlers,
    private readonly levels: () => LevelSource
  ) {
    const q = <T extends Element>(sel: string): T => {
      const n = root.querySelector<T>(sel)
      if (!n) throw new Error(`Pill: missing ${sel}`)
      return n
    }
    this.el = {
      root,
      label: q<HTMLElement>('[data-ref=label]'),
      wave: q<HTMLCanvasElement>('[data-ref=wave]'),
      caption: q<HTMLElement>('[data-ref=caption]'),
      eyeL: q<SVGEllipseElement>('[data-ref=eyeL]'),
      eyeR: q<SVGEllipseElement>('[data-ref=eyeR]'),
      mouth: q<SVGPathElement>('[data-ref=mouth]'),
      questionBox: q<HTMLElement>('[data-ref=question]'),
      qtext: q<HTMLElement>('[data-ref=qtext]'),
      qhint: q<HTMLElement>('[data-ref=qhint]'),
      qclose: q<HTMLButtonElement>('[data-ref=qclose]'),
      askForm: q<HTMLFormElement>('[data-ref=askForm]'),
      askInput: q<HTMLInputElement>('[data-ref=askInput]'),
      keyPanel: q<HTMLElement>('[data-ref=keyPanel]'),
      keyInput: q<HTMLInputElement>('[data-ref=keyInput]'),
      keyError: q<HTMLElement>('[data-ref=keyError]'),
      primary: q<HTMLButtonElement>('[data-ref=primary]'),
      talk: q<HTMLButtonElement>('[data-ref=talk]'),
      screen: q<HTMLButtonElement>('[data-ref=screen]'),
      study: q<HTMLButtonElement>('[data-ref=study]'),
      quit: q<HTMLButtonElement>('[data-ref=quit]')
    }
    const cs = getComputedStyle(root)
    this.colors = {
      you: cs.getPropertyValue('--you').trim() || this.colors.you,
      tutor: cs.getPropertyValue('--tutor').trim() || this.colors.tutor,
      quiet: cs.getPropertyValue('--quiet').trim() || this.colors.quiet
    }
    this.bind()
    this.render()
    this.drawFrame(performance.now())
    this.scheduleBlink()
  }

  // ───────────────────────────── public API ─────────────────────────────

  setState(state: SessionState, detail?: string): void {
    this.state = state
    if (state === 'idle') {
      this.tutorLine = ''
      this.userLine = ''
      this.muted = false
      this.holding = false
      this.screenPaused = false
      this.question = null
    }
    if (state === 'reconnecting' && detail) console.info('[notch] reconnecting:', detail)
    this.render()
    this.syncAnimation()
  }

  setError(message: string): void {
    this.state = 'error'
    this.tutorLine = ''
    this.userLine = message
    this.question = null
    this.render()
    this.syncAnimation()
    this.peek()
  }

  notice(message: string): void {
    this.userLine = message
    this.render()
    this.peek()
  }

  configure(opts: { talkMode: 'hold' | 'always'; keyName: string; showFace: boolean }): void {
    this.talkMode = opts.talkMode
    this.keyName = opts.keyName
    this.el.root.dataset.face = String(opts.showFace)
    this.render()
  }

  setHolding(holding: boolean): void {
    this.holding = holding
    this.render()
  }

  pushTranscript(role: 'user' | 'tutor', text: string): void {
    if (role === 'tutor') {
      this.tutorLine = clampTail(this.tutorLine + text)
      this.userLine = ''
    } else {
      if (this.tutorLine && !this.levels().tutorSpeaking) this.tutorLine = ''
      this.userLine = clampTail(this.userLine + text)
    }
    this.render()
    this.peek()
  }

  endTutorLine(): void {
    this.peek()
  }

  /** The tutor asked a question: show it with a typing bar until answered. */
  showQuestion(text: string, hint: string): void {
    this.question = { text, hint }
    this.render()
    this.peek()
  }

  showKeyPanel(error?: string): void {
    this.el.keyPanel.hidden = false
    this.el.keyError.textContent = error ?? ''
    this.el.root.dataset.keyEntry = 'true'
    this.handlers.setInteractive(true, true)
    requestAnimationFrame(() => this.el.keyInput.focus())
    this.render()
  }

  hideKeyPanel(): void {
    this.el.keyPanel.hidden = true
    this.el.keyInput.value = ''
    this.el.keyError.textContent = ''
    delete this.el.root.dataset.keyEntry
    this.handlers.setInteractive(this.hovered, false)
    this.render()
  }

  setMuted(muted: boolean): void {
    this.muted = muted
    this.render()
  }

  setScreenPaused(paused: boolean): void {
    this.screenPaused = paused
    this.render()
  }

  setScreenAvailable(available: boolean): void {
    this.el.screen.disabled = !available
    this.el.screen.title = available ? '' : 'Screen access is off in system settings'
  }

  // ───────────────────────────── internals ─────────────────────────────

  private bind(): void {
    const e = this.el

    e.root.addEventListener('pointerenter', () => {
      this.hovered = true
      this.handlers.setInteractive(true, this.wantsKeyboard())
      this.render()
    })
    e.root.addEventListener('pointerleave', () => {
      this.hovered = false
      if (!this.wantsKeyboard()) this.handlers.setInteractive(false)
      this.render()
    })

    e.primary.addEventListener('click', () => this.handlers.onPrimary())
    e.screen.addEventListener('click', () => this.handlers.onScreen())
    e.study.addEventListener('click', () => this.handlers.onStudy())
    e.quit.addEventListener('click', () => this.handlers.onQuit())

    // Talk button: press-and-hold in hold mode, a toggle in always mode.
    e.talk.addEventListener('pointerdown', (ev) => {
      if (this.talkMode !== 'hold') return
      e.talk.setPointerCapture(ev.pointerId)
      this.handlers.onHold(true)
    })
    const release = (): void => {
      if (this.talkMode === 'hold' && this.holding) this.handlers.onHold(false)
    }
    e.talk.addEventListener('pointerup', release)
    e.talk.addEventListener('pointercancel', release)
    e.talk.addEventListener('click', () => {
      if (this.talkMode === 'always') this.handlers.onMute()
    })

    // Typing bar. The window is non-focusable (so it never steals focus from
    // your work) until you click into the box.
    e.askInput.addEventListener('pointerdown', () => {
      this.handlers.setInteractive(true, true)
      setTimeout(() => e.askInput.focus(), 0)
    })
    e.askInput.addEventListener('focus', () => {
      this.typing = true
      this.render()
    })
    e.askInput.addEventListener('blur', () => {
      this.typing = false
      if (!this.wantsKeyboard()) this.handlers.setInteractive(this.hovered, false)
      this.render()
    })
    e.askInput.addEventListener('keydown', (ev) => {
      if (ev.key === 'Escape') e.askInput.blur()
    })
    e.askForm.addEventListener('submit', (ev) => {
      ev.preventDefault()
      const text = e.askInput.value.trim()
      if (!text) return
      this.handlers.onAsk(text, this.question?.text ?? null)
      e.askInput.value = ''
      this.question = null
      this.tutorLine = ''
      this.userLine = text
      e.askInput.blur()
      this.render()
      this.peek()
    })
    e.qclose.addEventListener('click', () => {
      this.question = null
      this.render()
    })

    e.keyPanel.querySelector('form')?.addEventListener('submit', (ev) => {
      ev.preventDefault()
      const v = e.keyInput.value.trim()
      if (v) this.handlers.onSaveKey(v)
    })
    e.keyInput.addEventListener('keydown', (ev) => {
      if (ev.key === 'Escape') this.hideKeyPanel()
    })
  }

  private wantsKeyboard(): boolean {
    return this.el.root.dataset.keyEntry === 'true' || this.typing
  }

  private peek(): void {
    this.el.root.dataset.peek = 'true'
    if (this.peekTimer) clearTimeout(this.peekTimer)
    this.peekTimer = setTimeout(() => {
      if (this.levels().tutorSpeaking) return this.peek()
      delete this.el.root.dataset.peek
    }, PEEK_LINGER_MS)
  }

  private render(): void {
    const e = this.el
    const s = this.state
    const active = s === 'live' || s === 'connecting' || s === 'reconnecting'
    const hold = this.talkMode === 'hold'

    e.root.dataset.state = s
    e.root.dataset.expanded = String(this.hovered || this.wantsKeyboard())
    e.root.dataset.muted = String(!hold && this.muted)
    e.root.dataset.question = String(Boolean(this.question) && s === 'live')
    e.root.dataset.canType = String(s === 'live')

    e.label.textContent =
      s === 'connecting'
        ? 'Connecting'
        : s === 'reconnecting'
          ? 'Reconnecting'
          : s === 'error'
            ? 'Needs attention'
            : s === 'live'
              ? hold
                ? this.holding
                  ? 'Listening'
                  : 'Ready'
                : this.muted
                  ? 'Muted'
                  : 'Listening'
              : 'Tutor'

    const line = this.tutorLine || this.userLine
    e.caption.textContent = line || this.idleHint()
    e.caption.dataset.role = this.tutorLine ? 'tutor' : this.userLine ? (s === 'error' ? 'error' : 'user') : 'hint'

    e.questionBox.hidden = !this.question
    e.qtext.textContent = this.question?.text ?? ''
    e.qhint.textContent = this.question?.hint ? `Hint: ${this.question.hint}` : ''
    e.askInput.placeholder = this.question ? 'Type your answer…' : 'Type to your tutor…'

    e.primary.textContent = active ? 'End session' : 'Start session'
    e.talk.hidden = !active
    e.screen.hidden = !active
    e.talk.textContent = hold ? (this.holding ? 'Listening…' : 'Hold to talk') : this.muted ? 'Unmute' : 'Mute'
    e.talk.setAttribute('aria-pressed', String(hold ? this.holding : this.muted))
    e.screen.textContent = this.screenPaused ? 'Show screen' : 'Hide screen'
    e.screen.setAttribute('aria-pressed', String(this.screenPaused))
  }

  private idleHint(): string {
    const combo = window.notch.platform === 'darwin' ? '⌘⇧Space' : 'Ctrl+Shift+Space'
    if (this.state === 'live') {
      return this.talkMode === 'hold' ? `Hold ${this.keyName} to talk, or type below.` : 'Ask about anything on your screen.'
    }
    if (this.state === 'connecting') return 'Starting your session…'
    return this.talkMode === 'hold'
      ? `Hold ${this.keyName} to start talking, or press ${combo}.`
      : `Press ${combo} or start a session to talk it through.`
  }

  private mood(): Mood {
    if (this.state === 'connecting' || this.state === 'reconnecting') return 'thinking'
    if (this.state !== 'live') return 'idle'
    const lv = this.levels()
    if (lv.tutorSpeaking) return 'talking'
    const userActive = this.talkMode === 'hold' ? this.holding : !this.muted
    return userActive ? 'listening' : 'idle'
  }

  private scheduleBlink(): void {
    if (this.reducedMotion) return
    setTimeout(
      () => {
        this.el.eyeL.setAttribute('ry', '0.25')
        this.el.eyeR.setAttribute('ry', '0.25')
        setTimeout(() => {
          this.el.eyeL.setAttribute('ry', '1.6')
          this.el.eyeR.setAttribute('ry', '1.6')
          this.scheduleBlink()
        }, 120)
      },
      2500 + Math.random() * 3500
    )
  }

  // One animation loop drives the face and the wave (only while a session is active).
  private syncAnimation(): void {
    const animate = this.state === 'live' || this.state === 'reconnecting' || this.state === 'connecting'
    if (animate && !this.raf) {
      const loop = (t: number): void => {
        this.drawFrame(t)
        this.raf = requestAnimationFrame(loop)
      }
      this.raf = requestAnimationFrame(loop)
    } else if (!animate && this.raf) {
      cancelAnimationFrame(this.raf)
      this.raf = 0
      this.amp = 0
      this.mouthOpen = 0
      this.drawFrame(performance.now())
    }
  }

  private drawFrame(t: number): void {
    const lv = this.levels()
    const mood = this.mood()
    this.el.root.dataset.mood = mood

    // Mouth follows the tutor's voice level.
    const targetOpen = mood === 'talking' ? Math.min(1, lv.tutor * 6) : 0
    this.mouthOpen += (targetOpen - this.mouthOpen) * 0.5
    const m = this.el.mouth
    if (this.mouthOpen < 0.08) {
      m.setAttribute('d', 'M7.6 14.2 Q12 17.8 16.4 14.2')
      m.dataset.open = 'false'
    } else {
      const depth = 14.4 + 1.2 + this.mouthOpen * 5
      m.setAttribute('d', `M8.1 14 Q12 15 15.9 14 Q12 ${depth.toFixed(2)} 8.1 14 Z`)
      m.dataset.open = 'true'
    }

    this.drawWave(t, lv, mood)
  }

  private drawWave(t: number, lv: LevelSource, mood: Mood): void {
    const c = this.el.wave
    const dpr = window.devicePixelRatio || 1
    const cssW = c.clientWidth || 46
    const cssH = c.clientHeight || 16
    if (c.width !== Math.round(cssW * dpr) || c.height !== Math.round(cssH * dpr)) {
      c.width = Math.round(cssW * dpr)
      c.height = Math.round(cssH * dpr)
    }
    const g = c.getContext('2d')
    if (!g) return
    g.setTransform(dpr, 0, 0, dpr, 0, 0)
    g.clearRect(0, 0, cssW, cssH)

    const raw = mood === 'talking' ? lv.tutor * 5 : mood === 'listening' ? lv.you * 7 : 0
    const target = Math.min(1, raw)
    this.amp += (target - this.amp) * (target > this.amp ? 0.45 : 0.12)

    g.fillStyle = mood === 'talking' ? this.colors.tutor : mood === 'listening' ? this.colors.you : this.colors.quiet
    const bars = 7
    const barW = 3
    const gap = (cssW - bars * barW) / (bars - 1)
    const mid = (bars - 1) / 2
    for (let i = 0; i < bars; i++) {
      const envelope = 1 - Math.abs(i - mid) / (mid + 1.5)
      const wobble = this.reducedMotion ? 1 : 0.65 + 0.35 * Math.sin(t / 110 + i * 1.7)
      const h = Math.max(barW, cssH * this.amp * envelope * wobble)
      g.beginPath()
      g.roundRect(i * (barW + gap), (cssH - h) / 2, barW, h, barW / 2)
      g.fill()
    }
  }
}

function clampTail(s: string): string {
  return s.length > CAPTION_MAX_CHARS ? '…' + s.slice(-CAPTION_MAX_CHARS).trimStart() : s
}
