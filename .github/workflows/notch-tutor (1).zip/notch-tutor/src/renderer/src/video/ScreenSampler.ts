/**
 * ScreenSampler – primary monitor → downscaled JPEG every N ms.
 *
 * getDisplayMedia() is answered by the main process's display-media handler
 * with the primary screen (no picker). We then:
 *
 *   1. Sample a 96×54 luma thumbnail and compare it with the last SENT frame.
 *      If nothing meaningful changed, skip – saves bandwidth, tokens and
 *      socket time (keeps audio latency low). A keyframe is still sent every
 *      `keyframeMs` so the model's view never goes stale.
 *   2. Downscale to `maxEdge` (1280 px keeps code/text legible at ~60–150 KB).
 *   3. Encode JPEG off the main thread via OffscreenCanvas.convertToBlob.
 *
 * `forceNext()` bypasses change detection – the orchestrator calls it the
 * moment the user starts speaking, so a question always ships with a fresh frame.
 */

export interface ScreenSamplerOptions {
  intervalMs: number
  maxEdge: number
  jpegQuality: number
  keyframeMs: number
  /** Mean absolute luma difference (0–255) below which a frame counts as unchanged. */
  changeThreshold: number
}

const DEFAULTS: ScreenSamplerOptions = {
  intervalMs: 1000,
  maxEdge: 1280,
  jpegQuality: 0.72,
  keyframeMs: 6000,
  changeThreshold: 0.35
}

const PROBE_W = 96
const PROBE_H = 54

export class ScreenSampler {
  private readonly opts: ScreenSamplerOptions
  private stream: MediaStream | null = null
  private video: HTMLVideoElement | null = null
  private canvas: OffscreenCanvas | null = null
  private ctx2d: OffscreenCanvasRenderingContext2D | null = null
  private probe: OffscreenCanvasRenderingContext2D | null = null
  private timer: ReturnType<typeof setInterval> | null = null
  private prevLuma: Uint8Array | null = null
  private lastSentAt = 0
  private busy = false
  private paused = false
  private forced = false

  framesSent = 0
  framesSkipped = 0

  constructor(
    private readonly onFrame: (jpeg: ArrayBuffer) => void,
    private readonly onEnded: (reason: string) => void,
    opts: Partial<ScreenSamplerOptions> = {}
  ) {
    this.opts = { ...DEFAULTS, ...opts }
  }

  async start(): Promise<void> {
    this.stream = await navigator.mediaDevices.getDisplayMedia({
      video: { frameRate: { ideal: 5, max: 10 } },
      audio: false
    })
    const track = this.stream.getVideoTracks()[0]
    // Hint the capturer to preserve sharp edges (text) over motion smoothness.
    track.contentHint = 'text'
    track.addEventListener('ended', () => this.onEnded('Screen sharing stopped.'))

    const video = document.createElement('video')
    video.muted = true
    video.playsInline = true
    video.srcObject = this.stream
    await video.play()
    this.video = video

    this.canvas = new OffscreenCanvas(2, 2)
    this.ctx2d = this.canvas.getContext('2d', { alpha: false, desynchronized: true })
    this.probe = new OffscreenCanvas(PROBE_W, PROBE_H).getContext('2d', { alpha: false, willReadFrequently: true })

    this.timer = setInterval(() => void this.tick(), this.opts.intervalMs)
    this.forced = true
    void this.tick() // send the first frame immediately
  }

  pause(): void {
    this.paused = true
  }

  resume(): void {
    this.paused = false
    this.forceNext()
  }

  get isPaused(): boolean {
    return this.paused
  }

  forceNext(): void {
    this.forced = true
  }

  private async tick(): Promise<void> {
    const v = this.video
    if (this.busy || this.paused || !v || !this.ctx2d || !this.canvas || !this.probe) return
    if (v.readyState < HTMLMediaElement.HAVE_CURRENT_DATA || v.videoWidth === 0) return
    this.busy = true
    try {
      const now = performance.now()

      // 1) Cheap change detection on a tiny luma thumbnail.
      this.probe.drawImage(v, 0, 0, PROBE_W, PROBE_H)
      const luma = toLuma(this.probe.getImageData(0, 0, PROBE_W, PROBE_H).data)
      const stale = now - this.lastSentAt >= this.opts.keyframeMs
      if (!this.forced && !stale && this.prevLuma && meanAbsDiff(luma, this.prevLuma) < this.opts.changeThreshold) {
        this.framesSkipped++
        return
      }

      // 2) Downscale, preserving aspect ratio.
      const scale = Math.min(1, this.opts.maxEdge / Math.max(v.videoWidth, v.videoHeight))
      const w = Math.max(2, Math.round(v.videoWidth * scale))
      const h = Math.max(2, Math.round(v.videoHeight * scale))
      if (this.canvas.width !== w || this.canvas.height !== h) {
        this.canvas.width = w
        this.canvas.height = h
      }
      this.ctx2d.imageSmoothingQuality = 'high'
      this.ctx2d.drawImage(v, 0, 0, w, h)

      // 3) Hardware-friendly async JPEG encode.
      const blob = await this.canvas.convertToBlob({ type: 'image/jpeg', quality: this.opts.jpegQuality })
      const buf = await blob.arrayBuffer()

      this.prevLuma = luma
      this.lastSentAt = now
      this.forced = false
      this.framesSent++
      this.onFrame(buf)
    } catch (err) {
      console.warn('[screen] frame grab failed', err)
    } finally {
      this.busy = false
    }
  }

  stop(): void {
    if (this.timer) clearInterval(this.timer)
    this.timer = null
    this.stream?.getTracks().forEach((t) => t.stop())
    if (this.video) {
      this.video.pause()
      this.video.srcObject = null
    }
    this.video = null
    this.stream = null
    this.canvas = null
    this.ctx2d = null
    this.probe = null
    this.prevLuma = null
  }
}

function toLuma(rgba: Uint8ClampedArray): Uint8Array {
  const out = new Uint8Array(rgba.length / 4)
  for (let i = 0, j = 0; i < rgba.length; i += 4, j++) {
    // Integer Rec.601 approximation: (77R + 150G + 29B) >> 8
    out[j] = (77 * rgba[i] + 150 * rgba[i + 1] + 29 * rgba[i + 2]) >> 8
  }
  return out
}

function meanAbsDiff(a: Uint8Array, b: Uint8Array): number {
  let sum = 0
  for (let i = 0; i < a.length; i++) sum += Math.abs(a[i] - b[i])
  return sum / a.length
}
