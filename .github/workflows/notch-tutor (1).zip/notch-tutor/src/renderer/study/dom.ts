/**
 * Tiny DOM helpers. All text goes through text nodes (never innerHTML), so
 * nothing the model writes can inject markup or script into the page.
 */
export type Child = Node | string | number | null | undefined | false | Child[]

type Props = {
  class?: string
  on?: Partial<Record<keyof HTMLElementEventMap, (e: Event) => void>>
  [attr: string]: unknown
}

export function h<K extends keyof HTMLElementTagNameMap>(tag: K, props: Props = {}, ...children: Child[]): HTMLElementTagNameMap[K] {
  const el = document.createElement(tag)
  for (const [key, value] of Object.entries(props)) {
    if (value == null || value === false) continue
    if (key === 'class') el.className = String(value)
    else if (key === 'on') {
      for (const [ev, fn] of Object.entries(value as Record<string, (e: Event) => void>)) el.addEventListener(ev, fn)
    } else if (key in el && typeof value !== 'string') {
      ;(el as unknown as Record<string, unknown>)[key] = value // properties: checked, disabled, value…
    } else if (value === true) el.setAttribute(key, '')
    else el.setAttribute(key, String(value))
  }
  append(el, children)
  return el
}

/** Replace an element's children (accepts nulls and nested arrays). */
export function setChildren(el: Element, ...children: Child[]): void {
  el.replaceChildren()
  append(el, children)
}

/** Append children (accepts nulls and nested arrays). */
export function addChildren(el: Element, ...children: Child[]): void {
  append(el, children)
}

function append(parent: Node, children: Child[]): void {
  for (const c of children) {
    if (c == null || c === false) continue
    if (Array.isArray(c)) append(parent, c)
    else parent.appendChild(c instanceof Node ? c : document.createTextNode(String(c)))
  }
}

let toastTimer: ReturnType<typeof setTimeout> | null = null
export function toast(message: string, kind: 'info' | 'error' = 'info'): void {
  const el = document.getElementById('toast')
  if (!el) return
  el.textContent = message
  el.dataset.kind = kind
  el.dataset.show = 'true'
  if (toastTimer) clearTimeout(toastTimer)
  toastTimer = setTimeout(() => (el.dataset.show = 'false'), kind === 'error' ? 6000 : 2800)
}

/** Disables a button and shows a spinner + label while `work` runs. */
export async function withBusy<T>(button: HTMLButtonElement, busyLabel: string, work: () => Promise<T>): Promise<T> {
  const original = [...button.childNodes]
  button.disabled = true
  button.replaceChildren(h('span', { class: 'spinner', 'aria-hidden': 'true' }), busyLabel)
  try {
    return await work()
  } finally {
    button.disabled = false
    button.replaceChildren(...original)
  }
}

export function formatDate(ms: number): string {
  return new Date(ms).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })
}

export function newId(): string {
  return crypto.randomUUID()
}
