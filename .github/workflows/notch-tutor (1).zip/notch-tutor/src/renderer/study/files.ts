/**
 * Getting pages into the app: upload, drag and drop, paste, or camera.
 *
 * Photos are downscaled to at most 2200 px and re-encoded as JPEG before
 * sending. That keeps handwriting perfectly legible for the model while
 * cutting a 5 MB phone photo to a few hundred KB (faster, and well inside
 * Gemini's request limit). iPhone HEIC photos that the browser can't decode
 * are sent as-is, since Gemini reads HEIC directly. PDFs are sent as-is.
 */
import type { UploadFile } from '@shared/study'
import { h } from './dom'

const MAX_EDGE = 2200
const MAX_RAW_BYTES = 15 * 1024 * 1024

export const ACCEPT = 'image/*,.heic,.heif,application/pdf'

export async function prepareFile(file: File): Promise<UploadFile> {
  const name = file.name || 'photo'
  const lower = name.toLowerCase()
  const isPdf = file.type === 'application/pdf' || lower.endsWith('.pdf')
  const isHeic = /heic|heif/.test(file.type) || /\.(heic|heif)$/.test(lower)

  if (isPdf) return raw(file, name, 'application/pdf')

  try {
    const bitmap = await createImageBitmap(file, { imageOrientation: 'from-image' })
    const scale = Math.min(1, MAX_EDGE / Math.max(bitmap.width, bitmap.height))
    const canvas = new OffscreenCanvas(Math.round(bitmap.width * scale), Math.round(bitmap.height * scale))
    const ctx = canvas.getContext('2d')
    if (!ctx) throw new Error('no 2d context')
    ctx.fillStyle = '#fff' // transparent PNG screenshots → white paper, not black
    ctx.fillRect(0, 0, canvas.width, canvas.height)
    ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height)
    bitmap.close()
    const blob = await canvas.convertToBlob({ type: 'image/jpeg', quality: 0.88 })
    return { name, mimeType: 'image/jpeg', dataBase64: await toBase64(blob) }
  } catch {
    if (isHeic) return raw(file, name, lower.endsWith('.heif') ? 'image/heif' : 'image/heic')
    throw new Error(`Couldn’t open ${name}. Use a JPG, PNG, HEIC or PDF.`)
  }
}

async function raw(file: File, name: string, mimeType: string): Promise<UploadFile> {
  if (file.size > MAX_RAW_BYTES) throw new Error(`${name} is over 15 MB. Use a smaller file.`)
  return { name, mimeType, dataBase64: await toBase64(file) }
}

function toBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader()
    r.onload = () => resolve(String(r.result).split(',')[1] ?? '')
    r.onerror = () => reject(new Error('Couldn’t read the file.'))
    r.readAsDataURL(blob)
  })
}

export function previewUrl(f: UploadFile): string | null {
  return f.mimeType === 'image/jpeg' || f.mimeType === 'image/png' ? `data:${f.mimeType};base64,${f.dataBase64}` : null
}

/** Opens a file picker. */
export function pickFiles(multiple: boolean): Promise<File[]> {
  return new Promise((resolve) => {
    const input = h('input', { type: 'file', accept: ACCEPT, multiple })
    input.addEventListener('change', () => resolve([...(input.files ?? [])]))
    input.addEventListener('cancel', () => resolve([]))
    input.click()
  })
}

/** Makes an element accept dropped files. */
export function makeDropZone(zone: HTMLElement, onFiles: (files: File[]) => void): void {
  zone.addEventListener('dragover', (e) => {
    e.preventDefault()
    zone.dataset.over = 'true'
  })
  zone.addEventListener('dragleave', () => (zone.dataset.over = 'false'))
  zone.addEventListener('drop', (e) => {
    e.preventDefault()
    zone.dataset.over = 'false'
    const files = [...(e.dataTransfer?.files ?? [])]
    if (files.length) onFiles(files)
  })
}

/** Full-screen camera: hold your page up to the webcam and take a photo. */
export async function captureFromCamera(): Promise<UploadFile | null> {
  if (!(await window.study.ensureCamera())) return null

  let stream: MediaStream
  try {
    stream = await navigator.mediaDevices.getUserMedia({
      video: { width: { ideal: 1920 }, height: { ideal: 1080 } },
      audio: false
    })
  } catch {
    throw new Error('Couldn’t start the camera. Check it isn’t in use by another app, or upload a photo instead.')
  }

  return new Promise((resolve) => {
    const video = h('video', { autoplay: true, playsinline: true, muted: true })
    video.srcObject = stream

    const close = (result: UploadFile | null): void => {
      stream.getTracks().forEach((t) => t.stop())
      overlay.remove()
      document.removeEventListener('keydown', onKey)
      resolve(result)
    }
    const onKey = (e: KeyboardEvent): void => {
      if (e.key === 'Escape') close(null)
    }

    const take = h('button', { class: 'btn btn--primary', type: 'button' }, 'Take photo')
    take.addEventListener('click', async () => {
      const canvas = new OffscreenCanvas(video.videoWidth, video.videoHeight)
      canvas.getContext('2d')?.drawImage(video, 0, 0)
      const blob = await canvas.convertToBlob({ type: 'image/jpeg', quality: 0.9 })
      close({ name: `camera-${Date.now()}.jpg`, mimeType: 'image/jpeg', dataBase64: await toBase64(blob) })
    })
    const cancel = h('button', { class: 'btn', type: 'button', on: { click: () => close(null) } }, 'Cancel')

    const overlay = h(
      'div',
      { class: 'camera', role: 'dialog', 'aria-label': 'Take a photo' },
      h(
        'div',
        { class: 'camera__box' },
        video,
        h('p', { class: 'small muted', style: 'margin:10px 0 0' }, 'Hold the page flat and close to the camera, with good light and no shadows.'),
        h('div', { class: 'row' }, cancel, take)
      )
    )
    document.body.appendChild(overlay)
    document.addEventListener('keydown', onKey)
    take.focus()
  })
}
