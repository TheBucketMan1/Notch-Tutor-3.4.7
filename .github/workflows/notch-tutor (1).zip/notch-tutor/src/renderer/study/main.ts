/**
 * Study hub entry: navigation + shared state.
 *
 * Each view builds its own DOM once and updates itself locally, so typing in
 * a form is never interrupted by a re-render. Views get a small context
 * object to read/replace the shared state and navigate.
 */
import './study.css'
import type { StudyState } from '@shared/study'
import { h } from './dom'
import { todayView } from './views/today'
import { quizView } from './views/quiz'
import { settingsView } from './views/settings'
import { subjectsView } from './views/subjects'
import { handwritingView } from './views/handwriting'
import { planView } from './views/plan'
import { markView } from './views/mark'
import { progressView } from './views/progress'

export type Tab = 'today' | 'subjects' | 'handwriting' | 'plan' | 'mark' | 'quiz' | 'progress' | 'settings'

export interface Ctx {
  state: StudyState
  setState(next: StudyState): void
  go(tab: Tab): void
  /** Register a handler for pasted files while this view is open. */
  onPaste(fn: ((files: File[]) => void) | null): void
}

type Group = 'home' | 'setup' | 'revise' | 'app'
const NAV: Array<{ tab: Tab; label: string; group: Group; step?: number; icon?: string }> = [
  { tab: 'today', label: 'Today', group: 'home', icon: '☀' },
  { tab: 'subjects', label: 'Your subjects', group: 'setup', step: 1 },
  { tab: 'handwriting', label: 'Your handwriting', group: 'setup', step: 2 },
  { tab: 'plan', label: 'Revision plan', group: 'setup', step: 3 },
  { tab: 'mark', label: 'Mark my work', group: 'revise', icon: '✓' },
  { tab: 'quiz', label: 'Quick quiz', group: 'revise', icon: '?' },
  { tab: 'progress', label: 'Progress', group: 'revise', icon: '↗' },
  { tab: 'settings', label: 'Settings', group: 'app', icon: '⚙' }
]

const VIEWS: Record<Tab, (ctx: Ctx) => HTMLElement> = {
  today: todayView,
  quiz: quizView,
  settings: settingsView,
  subjects: subjectsView,
  handwriting: handwritingView,
  plan: planView,
  mark: markView,
  progress: progressView
}

let current: Tab = 'today'
let pasteHandler: ((files: File[]) => void) | null = null

const ctx: Ctx = {
  state: { profile: null, handwriting: null, plan: null, doneTasks: [], history: [], quizzes: [], activityDays: [] },
  setState(next) {
    ctx.state = next
    renderNav()
  },
  go(tab) {
    current = tab
    renderView()
  },
  onPaste(fn) {
    pasteHandler = fn
  }
}

function stepDone(tab: Tab): boolean {
  const s = ctx.state
  if (tab === 'subjects') return Boolean(s.profile && s.profile.subjects.length)
  if (tab === 'handwriting') return Boolean(s.handwriting)
  if (tab === 'plan') return Boolean(s.plan)
  return false
}

function renderNav(): void {
  const nav = document.getElementById('nav')
  if (!nav) return
  const item = (n: (typeof NAV)[number]): HTMLElement => {
    const done = n.step ? stepDone(n.tab) : false
    return h(
      'button',
      {
        class: 'nav__item',
        type: 'button',
        'data-tab': n.tab,
        'aria-current': n.tab === current ? 'page' : null,
        'data-done': String(done),
        on: { click: () => ctx.go(n.tab) }
      },
      n.step
        ? h('span', { class: 'nav__mark', 'aria-hidden': 'true' }, done ? '✓' : String(n.step))
        : h('span', { class: 'nav__icon', 'aria-hidden': 'true' }, n.icon ?? ''),
      n.label
    )
  }
  const group = (g: Group): HTMLElement[] => NAV.filter((n) => n.group === g).map(item)
  nav.replaceChildren(
    ...group('home'),
    h('div', { class: 'nav__group' }, 'Set up'),
    ...group('setup'),
    h('div', { class: 'nav__group' }, 'Revise'),
    ...group('revise'),
    h('div', { class: 'nav__spacer' }),
    ...group('app')
  )
}

function renderView(): void {
  pasteHandler = null
  const main = document.getElementById('view')
  if (!main) return
  main.replaceChildren(VIEWS[current](ctx))
  main.scrollTop = 0
  main.focus({ preventScroll: true })
  renderNav()
}

window.addEventListener('paste', (e) => {
  const files = [...(e.clipboardData?.files ?? [])]
  if (files.length && pasteHandler) {
    e.preventDefault()
    pasteHandler(files)
  }
})

// Links built by the app open in the browser.
document.addEventListener('click', (e) => {
  const a = (e.target as HTMLElement).closest('a[href^="https://"]') as HTMLAnchorElement | null
  if (!a) return
  e.preventDefault()
  window.study.openExternal(a.href)
})

async function boot(): Promise<void> {
  ctx.state = await window.study.getState()
  // First visit goes straight to subjects; after that, Today is home.
  current = stepDone('subjects') ? 'today' : 'subjects'
  renderView()
  // The voice tutor can open a section ("show me my plan").
  window.study.onNavigate((tab) => {
    const map: Record<string, Tab> = { today: 'today', plan: 'plan', mark: 'mark', quiz: 'quiz', progress: 'progress' }
    if (map[tab]) ctx.go(map[tab])
  })
}

void boot()
