/** Step 2: learn the student's handwriting from a known sample. */
import { HANDWRITING_LINES, type HandwritingProfile, type UploadFile } from '@shared/study'
import type { Ctx } from '../main'
import { formatDate, h, setChildren, toast, withBusy } from '../dom'
import { captureFromCamera, makeDropZone, pickFiles, prepareFile, previewUrl } from '../files'

export function handwritingView(ctx: Ctx): HTMLElement {
  let sample: UploadFile | null = null
  const preview = h('div', {})
  const result = h('div', {})

  const check = h('button', { class: 'btn btn--primary', type: 'button', disabled: true }, 'Check my handwriting')

  async function useFiles(files: File[]): Promise<void> {
    const file = files[0]
    if (!file) return
    try {
      setSample(await prepareFile(file))
    } catch (err) {
      toast((err as Error).message, 'error')
    }
  }

  function setSample(f: UploadFile | null): void {
    sample = f
    check.disabled = !f
    if (!f) return preview.replaceChildren()
    const url = previewUrl(f)
    preview.replaceChildren(
      h(
        'div',
        { class: 'thumbs', style: 'grid-template-columns:minmax(0,280px)' },
        h(
          'div',
          { class: 'thumb' },
          url ? h('img', { src: url, alt: 'Your handwriting sample' }) : h('div', { class: 'thumb__file' }, f.name),
          h('button', { class: 'thumb__remove', type: 'button', 'aria-label': 'Remove photo', on: { click: () => setSample(null) } }, '×')
        )
      )
    )
  }

  check.addEventListener('click', () =>
    withBusy(check, 'Reading your handwriting…', async () => {
      if (!sample) return
      const res = await window.study.analyzeHandwriting(sample)
      if (!res.ok) return toast(res.error, 'error')
      if (res.data.accuracyPercent === 0) {
        toast('That photo didn’t look like the handwriting sample. Try again.', 'error')
      } else {
        ctx.setState({ ...ctx.state, handwriting: res.data })
        toast('Handwriting saved')
      }
      showProfile(res.data)
      result.scrollIntoView({ behavior: 'smooth', block: 'start' })
    })
  )

  function showProfile(p: HandwritingProfile): void {
    setChildren(
      result,
      h('h2', {}, 'What I learned about your handwriting'),
      h('p', {}, `I could read ${p.accuracyPercent}% of your sample correctly.`),
      h('div', { class: 'meter', role: 'img', 'aria-label': `${p.accuracyPercent}% read correctly` }, h('i', { style: `width:${p.accuracyPercent}%` })),
      p.profile ? h('p', {}, p.profile) : null,
      p.confusions.length
        ? [
            h('h3', { style: 'margin-top:24px' }, 'Characters that could be misread'),
            h('ul', { class: 'pairs', style: 'margin-top:10px' }, p.confusions.map((c) => h('li', {}, h('b', {}, c.chars), h('span', {}, c.note))))
          ]
        : null,
      p.tips.length ? [h('h3', { style: 'margin-top:24px' }, 'Tips for exam handwriting'), h('ul', {}, p.tips.map((t) => h('li', {}, t)))] : null,
      h('details', { class: 'read-box' }, h('summary', {}, 'Exactly what I read'), h('pre', { class: 'read' }, p.transcription)),
      p.accuracyPercent > 0
        ? h('div', { class: 'row', style: 'margin-top:28px' }, h('button', { class: 'btn btn--primary', type: 'button', on: { click: () => ctx.go(ctx.state.plan ? 'mark' : 'plan') } }, ctx.state.plan ? 'Mark some work' : 'Make my revision plan'))
        : null
    )
  }

  const drop = h(
    'div',
    { class: 'drop' },
    h('p', {}, 'Drop your photo here, paste it with ⌘V, or'),
    h(
      'div',
      { class: 'row', style: 'justify-content:center' },
      h('button', { class: 'btn', type: 'button', on: { click: async () => useFiles(await pickFiles(false)) } }, 'Upload photo'),
      h(
        'button',
        {
          class: 'btn',
          type: 'button',
          on: {
            click: async () => {
              try {
                const f = await captureFromCamera()
                if (f) setSample(f)
              } catch (err) {
                toast((err as Error).message, 'error')
              }
            }
          }
        },
        'Use camera'
      )
    )
  )
  makeDropZone(drop, (files) => void useFiles(files))
  ctx.onPaste((files) => void useFiles(files))

  const existing = ctx.state.handwriting
  if (existing) showProfile(existing)

  return h(
    'div',
    { class: 'page' },
    h('h1', {}, 'Teach me your handwriting'),
    h(
      'p',
      { class: 'lead' },
      existing
        ? `I learned your handwriting on ${formatDate(existing.createdAt)}. Redo it any time your writing changes, or if I misread your work.`
        : 'Copy these lines onto paper in your normal handwriting, then take a photo. I’ll use it every time I mark your work, so I can read your letters and numbers correctly.'
    ),
    h('div', { class: 'sheet' }, h('ol', { class: 'sheet__lines' }, HANDWRITING_LINES.map((line) => h('li', {}, line)))),
    h('p', { class: 'small muted', style: 'margin-top:12px' }, 'Use the pen you normally write with. Write at your usual speed, not your neatest.'),
    h('h2', {}, 'Add your photo'),
    drop,
    preview,
    h('div', { class: 'row', style: 'margin-top:18px' }, check),
    result
  )
}
