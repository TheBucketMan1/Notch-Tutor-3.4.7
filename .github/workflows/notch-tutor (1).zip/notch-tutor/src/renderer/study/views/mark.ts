/** Mark my work: upload pages, get red-pen feedback. */
import type { UploadFile } from '@shared/study'
import type { Ctx } from '../main'
import { h, toast, withBusy } from '../dom'
import { captureFromCamera, makeDropZone, pickFiles, prepareFile, previewUrl } from '../files'
import { markedSheet } from './shared'

const MAX_PAGES = 8

export function markView(ctx: Ctx): HTMLElement {
  const pages: UploadFile[] = []
  const thumbs = h('div', { class: 'thumbs' })
  const result = h('div', {})

  // Subject picker: the student's subjects + "Other".
  const subjects = ctx.state.profile?.subjects.map((s) => s.name) ?? []
  const subject = h('select', { class: 'select' }, [...subjects, 'Other'].map((s) => h('option', { value: s }, s)))
  const otherSubject = h('input', { class: 'input', placeholder: 'Which subject?', hidden: subjects.length > 0 })
  subject.addEventListener('change', () => (otherSubject.hidden = subject.value !== 'Other'))
  if (!subjects.length) subject.value = 'Other'

  const question = h('textarea', { class: 'textarea', placeholder: 'e.g. “Q3: Explain how the heart pumps blood (6 marks)”. Leave blank and I’ll work it out from your page.' })
  const scheme = h('textarea', { class: 'textarea', placeholder: 'Paste the answers or mark scheme if you have them. This makes marking much more accurate.' })

  const markBtn = h('button', { class: 'btn btn--primary', type: 'button', disabled: true }, 'Mark my work')

  function renderThumbs(): void {
    markBtn.disabled = pages.length === 0
    thumbs.replaceChildren(
      ...pages.map((p, i) => {
        const url = previewUrl(p)
        return h(
          'div',
          { class: 'thumb' },
          url ? h('img', { src: url, alt: `Page ${i + 1}` }) : h('div', { class: 'thumb__file' }, p.name),
          h(
            'button',
            {
              class: 'thumb__remove',
              type: 'button',
              'aria-label': `Remove page ${i + 1}`,
              on: {
                click: () => {
                  pages.splice(i, 1)
                  renderThumbs()
                }
              }
            },
            '×'
          )
        )
      })
    )
  }

  async function addFiles(files: File[]): Promise<void> {
    for (const f of files) {
      if (pages.length >= MAX_PAGES) {
        toast(`You can send up to ${MAX_PAGES} pages at once.`, 'error')
        break
      }
      try {
        pages.push(await prepareFile(f))
      } catch (err) {
        toast((err as Error).message, 'error')
      }
    }
    renderThumbs()
  }

  markBtn.addEventListener('click', () =>
    withBusy(markBtn, 'Marking… this can take up to a minute', async () => {
      const subj = subject.value === 'Other' ? otherSubject.value.trim() : subject.value
      if (!subj) {
        toast('Choose which subject this is.', 'error')
        return
      }
      const res = await window.study.markWork({ files: pages, subject: subj, question: question.value, markScheme: scheme.value })
      if (!res.ok) return toast(res.error, 'error')
      ctx.setState({ ...ctx.state, history: [res.data, ...ctx.state.history] })
      result.replaceChildren(markedSheet(res.data), h('div', { class: 'row', style: 'margin-top:24px' },
        h('button', { class: 'btn', type: 'button', on: { click: () => resetForNext() } }, 'Mark something else'),
        h('button', { class: 'btn', type: 'button', on: { click: () => ctx.go('plan') } }, 'Update my plan')
      ))
      result.scrollIntoView({ behavior: 'smooth', block: 'start' })
    })
  )

  function resetForNext(): void {
    pages.length = 0
    question.value = ''
    scheme.value = ''
    renderThumbs()
    result.replaceChildren()
    document.getElementById('view')?.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const drop = h(
    'div',
    { class: 'drop' },
    h('p', {}, 'Drop photos or PDFs of your work here, paste with ⌘V, or'),
    h(
      'div',
      { class: 'row', style: 'justify-content:center' },
      h('button', { class: 'btn', type: 'button', on: { click: async () => addFiles(await pickFiles(true)) } }, 'Upload pages'),
      h(
        'button',
        {
          class: 'btn',
          type: 'button',
          on: {
            click: async () => {
              try {
                const f = await captureFromCamera()
                if (f) {
                  pages.push(f)
                  renderThumbs()
                }
              } catch (err) {
                toast((err as Error).message, 'error')
              }
            }
          }
        },
        'Use camera'
      )
    )
  )
  makeDropZone(drop, (files) => void addFiles(files))
  ctx.onPaste((files) => void addFiles(files))

  return h(
    'div',
    { class: 'page' },
    h('h1', {}, 'Mark my work'),
    h('p', { class: 'lead' }, 'Add photos of your answers. I’ll read your handwriting, mark it, show you exactly what to fix, and tell you what to revise next.'),
    !ctx.state.handwriting
      ? h(
          'div',
          { class: 'notice' },
          'I haven’t learned your handwriting yet, so I may misread some words. ',
          h('a', { href: '#', on: { click: (e: Event) => { e.preventDefault(); ctx.go('handwriting') } } }, 'Teach me your handwriting'),
          ' first for better marking.'
        )
      : null,
    h(
      'div',
      { class: 'grid-2' },
      h('label', { class: 'field' }, h('span', {}, 'Subject'), subject),
      h('label', { class: 'field' }, h('span', { 'aria-hidden': 'true' }, '\u00a0'), otherSubject)
    ),
    h('label', { class: 'field' }, h('span', {}, 'Question (optional)'), question),
    h('label', { class: 'field' }, h('span', {}, 'Answers or mark scheme (optional)'), scheme),
    h('h2', {}, 'Your pages'),
    drop,
    thumbs,
    h('div', { class: 'row', style: 'margin-top:20px' }, markBtn),
    result
  )
}
