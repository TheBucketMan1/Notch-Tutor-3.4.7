/** Step 3: a concrete revision plan with tick-off tasks and revision links. */
import type { RevisionPlan } from '@shared/study'
import type { Ctx } from '../main'
import { formatDate, h, setChildren, toast, withBusy } from '../dom'
import { linkChips } from './shared'

export function planView(ctx: Ctx): HTMLElement {
  const page = h('div', { class: 'page' })

  if (!ctx.state.profile || ctx.state.profile.subjects.length === 0) {
    page.append(
      h('h1', {}, 'Your revision plan'),
      h('p', { class: 'lead' }, 'Add your subjects first, and I’ll build a week-by-week plan around what you find hardest.'),
      h('button', { class: 'btn btn--primary', type: 'button', on: { click: () => ctx.go('subjects') } }, 'Add your subjects')
    )
    return page
  }

  const body = h('div', {})
  const make = h('button', { class: 'btn btn--primary', type: 'button' }, ctx.state.plan ? 'Make a new plan' : 'Make my plan')
  make.addEventListener('click', async () => {
    await withBusy(make, 'Building your plan…', async () => {
      if (ctx.state.plan && !confirm('Replace your current plan? Your ticked tasks will be cleared.')) return
      const res = await window.study.generatePlan()
      if (!res.ok) return toast(res.error, 'error')
      ctx.setState({ ...ctx.state, plan: res.data, doneTasks: [] })
      renderPlan(res.data)
      toast('Plan ready')
    })
    make.textContent = ctx.state.plan ? 'Make a new plan' : 'Make my plan'
  })

  function renderPlan(plan: RevisionPlan): void {
    const done = new Set(ctx.state.doneTasks)
    const allTasks = plan.subjects.flatMap((s) => s.topics.flatMap((t) => t.tasks))
    const progressText = h('span', { class: 'small muted' })
    const bar = h('i', {})
    const updateProgress = (): void => {
      const n = allTasks.filter((t) => done.has(t.id)).length
      progressText.textContent = `${n} of ${allTasks.length} tasks done`
      bar.style.width = `${allTasks.length ? (n / allTasks.length) * 100 : 0}%`
    }
    updateProgress()

    setChildren(
      body,
      plan.overview ? h('p', { style: 'font-size:17px' }, plan.overview) : null,
      h('div', { class: 'progress' }, h('div', { class: 'meter' }, bar), progressText),

      plan.week.length
        ? [
            h('h2', {}, 'This week'),
            h(
              'div',
              { class: 'week' },
              plan.week.map((d) =>
                h(
                  'section',
                  { class: 'day' },
                  h('h3', {}, d.day),
                  d.blocks.length
                    ? h('ul', {}, d.blocks.map((b) => h('li', {}, h('b', {}, `${b.subject}, ${b.minutes} min`), `${b.topic}: ${b.activity}`)))
                    : h('p', { class: 'rest' }, 'Rest day')
                )
              )
            )
          ]
        : null,

      plan.subjects.map((s) =>
        h(
          'section',
          {},
          h('h2', {}, s.subject),
          s.topics.map((t) =>
            h(
              'div',
              { class: 'topic' },
              h('h3', {}, h('span', { class: 'topic__name' }, t.topic)),
              t.why ? h('p', { class: 'topic__why' }, t.why) : null,
              h(
                'ul',
                { class: 'tasks' },
                t.tasks.map((task) => {
                  const li = h('li', { class: 'task', 'data-done': String(done.has(task.id)) })
                  const box = h('input', {
                    type: 'checkbox',
                    checked: done.has(task.id),
                    'aria-label': `Done: ${task.text}`,
                    on: {
                      change: async (e: Event) => {
                        const on = (e.target as HTMLInputElement).checked
                        li.dataset.done = String(on)
                        if (on) done.add(task.id)
                        else done.delete(task.id)
                        updateProgress()
                        const ids = await window.study.setTaskDone(task.id, on)
                        ctx.setState({ ...ctx.state, doneTasks: ids })
                      }
                    }
                  })
                  li.append(box, h('div', {}, h('div', { class: 'task__text' }, task.text), h('div', { class: 'task__meta' }, `About ${task.minutes} minutes`), linkChips(task.resources)))
                  return li
                })
              )
            )
          )
        )
      ),

      plan.tips.length ? [h('h2', {}, 'Tips'), h('ul', {}, plan.tips.map((t) => h('li', {}, t)))] : null,
      h('p', { class: 'small muted', style: 'margin-top:32px' }, `Plan made ${formatDate(plan.createdAt)}. Links search trusted revision sites, so they always open real pages.`)
    )
  }

  if (ctx.state.plan) renderPlan(ctx.state.plan)

  page.append(
    h('h1', {}, 'Your revision plan'),
    h(
      'p',
      { class: 'lead' },
      ctx.state.plan
        ? 'Tick tasks off as you go. Make a new plan whenever your subjects change or after marking some work, and it will focus on your latest mistakes.'
        : 'I’ll build a plan from your subjects, the topics you find hard, and any work I’ve marked. It takes about 20–40 seconds.'
    ),
    h('div', { class: 'row', style: 'margin-bottom:28px' }, make),
    body
  )
  return page
}
