/** Progress: average marks per subject, recurring weak topics, and history. */
import type { MarkResult } from '@shared/study'
import type { Ctx } from '../main'
import { addChildren, formatDate, h, toast } from '../dom'
import { markedSheet, scoreLabel } from './shared'

export function progressView(ctx: Ctx): HTMLElement {
  const page = h('div', { class: 'page' }, h('h1', {}, 'Your progress'))
  const history = ctx.state.history

  const quizzes = ctx.state.quizzes

  if (!history.length && !quizzes.length) {
    page.append(
      h('p', { class: 'lead' }, 'Once I’ve marked some work or you’ve done a quiz, you’ll see your average for each subject and the topics that keep coming up.'),
      h('button', { class: 'btn btn--primary', type: 'button', on: { click: () => ctx.go('mark') } }, 'Mark some work')
    )
    return page
  }

  // Average per subject (only results with a percentage).
  const bySubject = new Map<string, number[]>()
  const addScore = (subject: string, pct: number): void => {
    const list = bySubject.get(subject) ?? []
    list.push(pct)
    bySubject.set(subject, list)
  }
  for (const r of history) if (r.score.percent != null) addScore(r.subject, r.score.percent)
  for (const q of quizzes) addScore(q.subject, Math.round((q.correct / q.total) * 100))
  const averages = [...bySubject.entries()]
    .map(([subject, xs]) => ({ subject, avg: Math.round(xs.reduce((a, b) => a + b, 0) / xs.length), n: xs.length }))
    .sort((a, b) => a.avg - b.avg)

  // Topics that keep appearing in "revise next".
  const counts = new Map<string, number>()
  for (const r of history.slice(0, 30)) for (const n of r.nextSteps) counts.set(n.topic, (counts.get(n.topic) ?? 0) + 1)
  const recurring = [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 10)

  const list = h('ul', { class: 'history' })
  const renderHistory = (items: MarkResult[]): void => {
    list.replaceChildren(
      ...items.map((r) =>
        h(
          'li',
          {},
          h(
            'details',
            {},
            h('summary', {}, h('span', { class: 'muted small' }, formatDate(r.createdAt)), h('span', {}, `${r.subject}: ${r.topic}`), h('span', { class: 'history__score' }, scoreLabel(r))),
            markedSheet(r),
            h(
              'div',
              { class: 'row', style: 'margin:16px 0 24px' },
              h(
                'button',
                {
                  class: 'btn btn--quiet',
                  type: 'button',
                  on: {
                    click: async () => {
                      if (!confirm('Delete this marked piece of work?')) return
                      const next = await window.study.deleteHistoryItem(r.id)
                      ctx.setState({ ...ctx.state, history: next })
                      renderHistory(next)
                      toast('Deleted')
                    }
                  }
                },
                'Delete'
              )
            )
          )
        )
      )
    )
  }
  renderHistory(history)

  addChildren(
    page,
    h('p', { class: 'lead' }, `${history.length} piece${history.length === 1 ? '' : 's'} of work marked and ${quizzes.length} quiz${quizzes.length === 1 ? '' : 'zes'} done so far.`),
    averages.length
      ? [
          h('h2', {}, 'Average score by subject'),
          h(
            'div',
            { class: 'bars' },
            averages.map((a) =>
              h(
                'div',
                { class: 'bar' },
                h('span', {}, a.subject),
                h('div', { class: 'meter', role: 'img', 'aria-label': `${a.subject} average ${a.avg}%` }, h('i', { style: `width:${a.avg}%` })),
                h('b', {}, `${a.avg}%`)
              )
            )
          )
        ]
      : null,
    recurring.length
      ? [
          h('h2', {}, 'Topics that keep coming up'),
          h('p', { class: 'muted' }, 'These appeared most often in “revise next”. Your next plan will focus on them.'),
          h('div', { class: 'chips' }, recurring.map(([t, n]) => h('span', { class: 'chip', style: 'cursor:default' }, n > 1 ? `${t} (${n})` : t)))
        ]
      : null,
    quizzes.length
      ? [
          h('h2', {}, 'Recent quizzes'),
          h(
            'ul',
            { class: 'history' },
            quizzes.slice(0, 10).map((q) =>
              h('li', {}, h('div', { class: 'quiz-row' }, h('span', { class: 'muted small' }, formatDate(q.createdAt)), h('span', {}, `${q.subject}: ${q.topic}`), h('span', { class: 'history__score' }, `${q.correct}/${q.total}`)))
            )
          )
        ]
      : null,
    history.length ? [h('h2', {}, 'Marked work'), list] : null
  )
  return page
}
