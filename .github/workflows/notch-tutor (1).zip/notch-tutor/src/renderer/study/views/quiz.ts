/** Quick quiz: multiple-choice questions on any topic, marked instantly. */
import type { Quiz } from '@shared/study'
import type { Ctx } from '../main'
import { h, newId, setChildren, toast, withBusy } from '../dom'

export function quizView(ctx: Ctx): HTMLElement {
  const s = ctx.state
  const subjects = s.profile?.subjects.map((x) => x.name) ?? []
  const page = h('div', { class: 'page' }, h('h1', {}, 'Quick quiz'))

  if (!subjects.length) {
    page.append(
      h('p', { class: 'lead' }, 'Add your subjects first and I’ll quiz you on the topics you find hardest.'),
      h('button', { class: 'btn btn--primary', type: 'button', on: { click: () => ctx.go('subjects') } }, 'Add your subjects')
    )
    return page
  }

  // Topic suggestions: weak topics, plan topics and "revise next" topics.
  const suggestionsFor = (subject: string): string[] => {
    const pref = s.profile?.subjects.find((x) => x.name === subject)
    const fromWeak = (pref?.weakTopics ?? '').split(/[,;\n]/).map((t) => t.trim()).filter(Boolean)
    const fromPlan = s.plan?.subjects.find((x) => x.subject.toLowerCase() === subject.toLowerCase())?.topics.map((t) => t.topic) ?? []
    const fromMarks = s.history.filter((r) => r.subject === subject).flatMap((r) => r.nextSteps.map((n) => n.topic))
    return [...new Set([...fromMarks, ...fromWeak, ...fromPlan])].slice(0, 10)
  }

  const subject = h('select', { class: 'select' }, subjects.map((x) => h('option', { value: x }, x)))
  const topic = h('input', { class: 'input', placeholder: 'e.g. circle theorems (leave blank for mixed)' })
  const chips = h('div', { class: 'chips' })
  const renderChips = (): void =>
    setChildren(
      chips,
      suggestionsFor(subject.value).map((t) =>
        h('button', { class: 'chip', type: 'button', on: { click: () => (topic.value = t) } }, t)
      )
    )
  subject.addEventListener('change', renderChips)
  renderChips()

  const count = h('select', { class: 'select' }, [5, 10, 15].map((n) => h('option', { value: String(n) }, `${n} questions`)))
  const difficulty = h(
    'select',
    { class: 'select' },
    h('option', { value: 'easier' }, 'Easier (build confidence)'),
    h('option', { value: 'exam' }, 'Exam standard'),
    h('option', { value: 'harder' }, 'Harder (stretch me)')
  )
  difficulty.value = 'exam'

  const area = h('div', {})
  const go = h('button', { class: 'btn btn--primary', type: 'button' }, 'Start quiz')
  go.addEventListener('click', () =>
    withBusy(go, 'Writing your quiz…', async () => {
      const res = await window.study.makeQuiz({
        subject: subject.value,
        topic: topic.value,
        count: Number(count.value),
        difficulty: difficulty.value as 'easier' | 'exam' | 'harder'
      })
      if (!res.ok) return toast(res.error, 'error')
      runQuiz(res.data)
    })
  )

  function runQuiz(quiz: Quiz): void {
    let index = 0
    let correct = 0
    const show = (): void => {
      const q = quiz.questions[index]
      let answered = false
      const feedback = h('div', {})
      const options = h(
        'div',
        { class: 'options' },
        q.options.map((opt, i) =>
          h(
            'button',
            {
              class: 'option',
              type: 'button',
              on: {
                click: (e: Event) => {
                  if (answered) return
                  answered = true
                  const right = i === q.answerIndex
                  if (right) correct++
                  ;[...options.children].forEach((b, j) => {
                    const el = b as HTMLButtonElement
                    el.disabled = true
                    if (j === q.answerIndex) el.dataset.result = 'right'
                  })
                  if (!right) (e.currentTarget as HTMLElement).dataset.result = 'wrong'
                  const last = index === quiz.questions.length - 1
                  setChildren(
                    feedback,
                    h('p', { class: right ? 'verdict verdict--right' : 'verdict verdict--wrong' }, right ? 'Correct!' : 'Not quite.'),
                    q.explanation ? h('p', {}, q.explanation) : null,
                    h(
                      'button',
                      {
                        class: 'btn btn--primary',
                        type: 'button',
                        on: {
                          click: () => {
                            index++
                            if (last) void finish()
                            else show()
                          }
                        }
                      },
                      last ? 'See my score' : 'Next question'
                    )
                  )
                }
              }
            },
            h('span', { class: 'option__letter' }, 'ABCD'[i]),
            opt
          )
        )
      )
      setChildren(
        area,
        h('p', { class: 'muted small' }, `${quiz.subject}: ${quiz.topic}. Question ${index + 1} of ${quiz.questions.length}`),
        h('div', { class: 'meter' }, h('i', { style: `width:${(index / quiz.questions.length) * 100}%` })),
        h('h2', { style: 'margin-top:8px' }, q.question),
        options,
        feedback
      )
      area.scrollIntoView({ behavior: 'smooth', block: 'start' })
    }

    const finish = async (): Promise<void> => {
      const total = quiz.questions.length
      const next = await window.study.saveQuizResult({ id: newId(), createdAt: Date.now(), subject: quiz.subject, topic: quiz.topic, correct, total })
      ctx.setState(next)
      const pct = Math.round((correct / total) * 100)
      setChildren(
        area,
        h(
          'div',
          { class: 'marked__head', style: 'margin-top:24px' },
          h(
            'div',
            {},
            h('h2', { style: 'margin-top:0' }, pct >= 80 ? 'Brilliant work' : pct >= 50 ? 'Good effort' : 'Keep going'),
            h('p', {}, pct >= 80 ? 'You clearly know this. Try the harder level next time.' : pct >= 50 ? 'Nearly there. Have another go to lock it in.' : 'This topic needs more practice. Watch a video on it, then try again.')
          ),
          h('div', { class: 'score' }, h('div', {}, `${correct}/${total}`))
        ),
        h(
          'div',
          { class: 'row', style: 'margin-top:20px' },
          h('button', { class: 'btn btn--primary', type: 'button', on: { click: () => runQuiz(quiz) } }, 'Try again'),
          h('button', { class: 'btn', type: 'button', on: { click: () => setChildren(area) } }, 'New quiz')
        )
      )
    }

    correct = 0
    index = 0
    show()
  }

  page.append(
    h('p', { class: 'lead' }, 'Test yourself in a few minutes. Every answer comes with an explanation.'),
    h(
      'div',
      { class: 'grid-2' },
      h('label', { class: 'field' }, h('span', {}, 'Subject'), subject),
      h('label', { class: 'field' }, h('span', {}, 'Topic'), topic)
    ),
    chips,
    h('div', { class: 'grid-2' }, h('label', { class: 'field' }, h('span', {}, 'Length'), count), h('label', { class: 'field' }, h('span', {}, 'Difficulty'), difficulty)),
    h('div', { class: 'row' }, go),
    area
  )
  return page
}
