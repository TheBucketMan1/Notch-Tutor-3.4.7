/** Settings: talking, tutor, screen, startup, API key, data, about. */
import { APP_AUTHOR, VOICES, type AppSettings } from '@shared/study'
import type { Ctx } from '../main'
import { h, setChildren, toast, withBusy } from '../dom'

export function settingsView(ctx: Ctx): HTMLElement {
  const page = h('div', { class: 'page' }, h('h1', {}, 'Settings'), h('p', { class: 'lead' }, 'Make Notch Tutor work the way you like.'))
  const body = h('div', {}, h('p', { class: 'muted' }, 'Loading…'))
  page.append(body)
  void build(ctx, body)
  return page
}

async function build(ctx: Ctx, body: HTMLElement): Promise<void> {
  let s = await window.study.getSettings()
  const save = async (patch: Partial<AppSettings>, message = 'Saved'): Promise<void> => {
    s = { ...s, ...(await window.study.updateSettings(patch)) }
    toast(message)
  }

  // ── Talking ──
  const keyLabel = h('kbd', { class: 'kbd' }, s.pttKeyName)
  const changeKey = h('button', { class: 'btn', type: 'button' }, 'Change key')
  changeKey.addEventListener('click', () =>
    withBusy(changeKey, 'Press any key… (Esc cancels)', async () => {
      const k = await window.study.recordPttKey()
      if (!k) return toast('No key recorded. Make sure access is allowed below, then try again.', 'error')
      await save({ pttKeycode: k.keycode, pttKeyName: k.name }, `Hold ${k.name} to talk`)
      keyLabel.textContent = k.name
    })
  )

  const access = h('div', {})
  const renderAccess = async (): Promise<void> => {
    const a = await window.study.getAccessibility()
    if (!a.required && !a.error) return setChildren(access)
    if (a.error) return setChildren(access, h('div', { class: 'notice error' }, a.error))
    if (a.granted) return setChildren(access, h('p', { class: 'small muted' }, 'Keyboard access is allowed, so your talk key works in any app.'))
    setChildren(
      access,
      h(
        'div',
        { class: 'notice' },
        h('p', {}, 'To use a key while you’re in other apps, macOS needs you to allow Notch Tutor under Accessibility.'),
        h(
          'button',
          {
            class: 'btn',
            type: 'button',
            on: {
              click: async () => {
                await window.study.requestAccessibility()
                toast('Turn on Notch Tutor in the window that opened')
              }
            }
          },
          'Allow access'
        )
      )
    )
  }
  void renderAccess()
  // Keep checking while this page is open, so it updates as soon as access is granted.
  const poll = setInterval(() => {
    if (!body.isConnected) return clearInterval(poll)
    void renderAccess()
  }, 2500)

  const keyRow = h(
    'div',
    { class: 'field' },
    h('span', {}, 'Talk key'),
    h('div', { class: 'row' }, keyLabel, changeKey),
    h('small', {}, 'Right Option, Right Command or Caps Lock work well. The fn key can’t be used: macOS keeps it for emoji and dictation.')
  )
  const keyBlock = h('div', { hidden: s.talkMode !== 'hold' }, keyRow, access)

  const talkMode = segmented(
    'How you talk',
    [
      ['hold', 'Hold a key to talk'],
      ['always', 'Always listening']
    ],
    s.talkMode,
    async (v) => {
      await save({ talkMode: v as AppSettings['talkMode'] })
      keyBlock.hidden = v !== 'hold'
    }
  )

  // ── Tutor ──
  const voice = h('select', { class: 'select' }, h('option', { value: '' }, 'Default'), VOICES.map((v) => h('option', { value: v }, v)))
  voice.value = s.voice
  voice.addEventListener('change', () => void save({ voice: voice.value }, 'Voice changes next time you start a session'))

  const style = segmented(
    'Teaching style',
    [
      ['guide', 'Guide me with hints'],
      ['direct', 'Explain answers directly']
    ],
    s.tutorStyle,
    (v) => save({ tutorStyle: v as AppSettings['tutorStyle'] }, 'Style changes next time you start a session')
  )

  const face = toggle('Show the tutor’s face in the notch', s.showFace, (on) => save({ showFace: on }))

  // ── Screen ──
  const detail = segmented(
    'Screen detail',
    [
      ['standard', 'Standard'],
      ['sharp', 'Sharp (reads small text)']
    ],
    s.screenDetail,
    (v) => save({ screenDetail: v as AppSettings['screenDetail'] }, 'Applies next time you start a session')
  )

  // ── Startup ──
  const login = await window.study.getOpenAtLogin()
  const startup = login.supported
    ? toggle('Open Notch Tutor when my Mac starts', login.enabled, async (on) => {
        const next = await window.study.setOpenAtLogin(on)
        toast(next.needsApproval ? 'Turn on Notch Tutor in the Login Items window to finish' : next.enabled ? 'Notch Tutor will open when your Mac starts' : 'Notch Tutor won’t open at startup')
        return next.enabled
      })
    : h('p', { class: 'small muted' }, 'Available in the installed app.')

  // ── API key ──
  const keyStatus = h('p', {})
  const renderKeyStatus = async (): Promise<void> => {
    const k = await window.study.keyStatus()
    keyStatus.textContent = k.hasKey ? (k.source === 'env' ? 'Using the key from your .env file (development).' : 'Your Gemini key is saved on this Mac.') : 'No key saved yet.'
  }
  void renderKeyStatus()
  const keyInput = h('input', { class: 'input', type: 'password', placeholder: 'Paste a new key (AQ.… or AIza…)', spellcheck: 'false' })
  const replace = h('button', { class: 'btn', type: 'button' }, 'Save new key')
  replace.addEventListener('click', () =>
    withBusy(replace, 'Saving…', async () => {
      const res = await window.study.setApiKey(keyInput.value)
      if (!res.ok) return toast(res.error ?? 'Couldn’t save that key.', 'error')
      keyInput.value = ''
      toast('New key saved')
      await renderKeyStatus()
    })
  )
  const remove = h('button', { class: 'btn btn--quiet', type: 'button' }, 'Remove key')
  remove.addEventListener('click', async () => {
    if (!confirm('Remove your Gemini key from this Mac? You’ll need to paste it again to use the tutor.')) return
    await window.study.removeApiKey()
    toast('Key removed')
    await renderKeyStatus()
  })

  // ── Data ──
  const wipe = h('button', { class: 'btn btn--danger', type: 'button' }, 'Delete all my study data')
  wipe.addEventListener('click', async () => {
    if (!confirm('Delete your subjects, handwriting, plan, marks and quizzes? This can’t be undone.')) return
    ctx.setState(await window.study.deleteAllData())
    toast('All study data deleted')
  })

  setChildren(
    body,
    section('Talking', talkMode, keyBlock, h('p', { class: 'small muted' }, 'You can also press and hold “Hold to talk” in the notch.')),
    section('Your tutor', h('label', { class: 'field' }, h('span', {}, 'Voice'), voice), style, face),
    section('Screen', detail, h('p', { class: 'small muted' }, 'Sharp uses more of your free Gemini allowance.')),
    section('Startup', startup),
    section('Gemini API key', keyStatus, h('div', { class: 'row' }, h('div', { style: 'flex:1;min-width:220px' }, keyInput), replace, remove)),
    section('Your data', h('p', { class: 'muted' }, 'Everything is stored on this Mac. Photos you upload are sent to Google Gemini to be read and marked.'), wipe),
    section(
      'About',
      h('p', {}, h('b', {}, `Notch Tutor ${s.appVersion}`)),
      h('p', { class: 'muted' }, `Made by ${APP_AUTHOR}. Powered by Google Gemini. On Gemini’s free tier, Google may use what you send to improve its products, so avoid sharing private information.`)
    )
  )
}

function section(title: string, ...children: Array<Node | null>): HTMLElement {
  return h('section', { class: 'settings-section' }, h('h2', {}, title), children)
}

function segmented(label: string, options: Array<[string, string]>, value: string, onChange: (v: string) => unknown): HTMLElement {
  const name = `seg-${Math.random().toString(36).slice(2)}`
  return h(
    'div',
    { class: 'field' },
    h('span', {}, label),
    h(
      'div',
      { class: 'scale', role: 'radiogroup', 'aria-label': label },
      options.map(([v, text]) =>
        h(
          'label',
          {},
          h('input', { type: 'radio', name, value: v, checked: v === value, on: { change: () => void onChange(v) } }),
          h('span', {}, text)
        )
      )
    )
  )
}

function toggle(label: string, on: boolean, onChange: (on: boolean) => Promise<unknown> | unknown): HTMLElement {
  const id = `sw-${Math.random().toString(36).slice(2)}`
  const input = h('input', { type: 'checkbox', role: 'switch', id, checked: on })
  input.addEventListener('change', async () => {
    input.disabled = true
    try {
      const result = await onChange(input.checked)
      if (typeof result === 'boolean') input.checked = result
    } finally {
      input.disabled = false
    }
  })
  return h('label', { class: 'switch', for: id, style: 'margin:6px 0 14px' }, input, h('span', { class: 'switch__track', 'aria-hidden': 'true' }), h('span', {}, label))
}
