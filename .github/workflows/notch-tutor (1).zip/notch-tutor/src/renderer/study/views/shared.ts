/** Rendering shared between views: resource links and the marked-work sheet. */
import type { MarkResult, ResourceLink } from '@shared/study'
import { formatDate, h } from '../dom'

export function linkChips(links: ResourceLink[]): HTMLElement | null {
  if (!links.length) return null
  return h(
    'div',
    { class: 'links' },
    links.map((l) => h('a', { class: 'link', href: l.url, 'data-kind': l.kind, title: 'Opens in your browser' }, l.label))
  )
}

function scoreText(r: MarkResult): { big: string; small: string } {
  const s = r.score
  const big = s.got != null && s.outOf ? `${s.got}/${s.outOf}` : s.percent != null ? `${s.percent}%` : '—'
  const bits = [s.grade ? `grade ${s.grade}` : '', s.estimated ? 'estimate' : ''].filter(Boolean)
  return { big, small: bits.join(', ') }
}

export function scoreLabel(r: MarkResult): string {
  return scoreText(r).big
}

/** The marked page: teacher's red-pen comments on ruled paper. */
export function markedSheet(r: MarkResult): HTMLElement {
  const { big, small } = scoreText(r)
  return h(
    'article',
    { class: 'marked' },
    h(
      'div',
      { class: 'marked__head' },
      h(
        'div',
        {},
        h('h2', { style: 'margin-top:0' }, `${r.subject}: ${r.topic}`),
        h('p', { class: 'muted small' }, `Marked ${formatDate(r.createdAt)}`)
      ),
      h('div', { class: 'score', 'aria-label': `Score ${big}` }, h('div', {}, big, small ? h('small', {}, small) : null))
    ),
    h(
      'div',
      { class: 'sheet' },
      r.summary ? h('p', { class: 'comment' }, r.summary) : null,

      r.strengths.length ? [h('h3', {}, 'What you got right'), h('ul', { class: 'ticks' }, r.strengths.map((s) => h('li', {}, s)))] : null,

      r.mistakes.length
        ? [
            h('h3', {}, 'Mistakes to fix'),
            r.mistakes.map((m) =>
              h(
                'div',
                { class: 'mistake' },
                m.where ? h('div', { class: 'mistake__where' }, m.where) : null,
                m.youWrote ? h('div', {}, 'You wrote: ', h('span', { class: 'mistake__wrote' }, m.youWrote)) : null,
                m.correct ? h('div', { class: 'mistake__right' }, m.correct) : null,
                m.why ? h('div', { class: 'muted' }, m.why) : null
              )
            )
          ]
        : null,

      r.improvements.length ? [h('h3', {}, 'How to improve'), h('ul', {}, r.improvements.map((s) => h('li', {}, s)))] : null,

      r.nextSteps.length
        ? [
            h('h3', {}, 'Revise next'),
            r.nextSteps.map((n) =>
              h('div', { class: 'mistake' }, h('div', { class: 'mistake__where' }, n.topic), n.why ? h('div', { class: 'muted' }, n.why) : null, linkChips(n.links))
            )
          ]
        : null
    ),
    h(
      'details',
      { class: 'read-box' },
      h('summary', {}, `What I read from your page (reading confidence: ${r.readingConfidence})`),
      r.unclearParts.length ? h('p', { class: 'small', style: 'margin-top:10px' }, `I wasn’t sure about: ${r.unclearParts.join(', ')}`) : null,
      h('pre', { class: 'read' }, r.transcription || 'Nothing readable found.')
    )
  )
}
