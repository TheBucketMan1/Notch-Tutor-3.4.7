/** Step 1: which subjects, what level, what's hard. */
import type { StudyProfile, SubjectPref } from '@shared/study'
import type { Ctx } from '../main'
import { h, newId, toast, withBusy } from '../dom'

const LEVELS = ['KS3 (Years 7–9)', 'GCSE', 'A-level', 'BTEC', 'IB', 'University', 'Other']
const BOARDS = ['', 'AQA', 'Edexcel (Pearson)', 'OCR', 'WJEC / Eduqas', 'CCEA', 'Cambridge (CIE)', 'SQA']
const SUGGESTED = [
  'Maths', 'English Language', 'English Literature', 'Biology', 'Chemistry', 'Physics',
  'Combined Science', 'History', 'Geography', 'Computer Science', 'French', 'Spanish',
  'Religious Studies', 'Business', 'Psychology', 'Economics'
]
const CONFIDENCE = ['Struggling', 'Shaky', 'OK', 'Good', 'Confident']

export function subjectsView(ctx: Ctx): HTMLElement {
  const saved = ctx.state.profile
  const draft: StudyProfile = saved
    ? structuredClone(saved)
    : { name: '', level: 'GCSE', examDate: '', hoursPerWeek: 6, subjects: [], updatedAt: 0 }

  const list = h('div', {})
  const chips = h('div', { class: 'chips', role: 'group', 'aria-label': 'Add a subject' })

  const has = (name: string): boolean => draft.subjects.some((s) => s.name.toLowerCase() === name.toLowerCase())

  function addSubject(name: string): void {
    const clean = name.trim()
    if (!clean || has(clean)) return
    draft.subjects.push({ id: newId(), name: clean, board: '', weakTopics: '', confidence: 3 })
    renderList()
    renderChips()
    // Put the cursor straight into "what's hard" for the new subject.
    ;(list.lastElementChild?.querySelector('textarea') as HTMLTextAreaElement | null)?.focus()
  }

  function removeSubject(id: string): void {
    draft.subjects = draft.subjects.filter((s) => s.id !== id)
    renderList()
    renderChips()
  }

  function renderChips(): void {
    chips.replaceChildren(
      ...SUGGESTED.map((name) =>
        h(
          'button',
          {
            class: 'chip',
            type: 'button',
            'aria-pressed': String(has(name)),
            on: {
              click: () => {
                const existing = draft.subjects.find((s) => s.name.toLowerCase() === name.toLowerCase())
                if (existing) removeSubject(existing.id)
                else addSubject(name)
              }
            }
          },
          name
        )
      )
    )
  }

  function subjectRow(s: SubjectPref): HTMLElement {
    const board = h('select', { class: 'select', 'aria-label': `${s.name} exam board` }, BOARDS.map((b) => h('option', { value: b }, b || 'Not sure')))
    board.value = s.board
    board.addEventListener('change', () => (s.board = board.value))

    const scale = h(
      'div',
      { class: 'scale', role: 'radiogroup', 'aria-label': `How confident are you in ${s.name}?` },
      CONFIDENCE.map((label, i) =>
        h(
          'label',
          {},
          h('input', {
            type: 'radio',
            name: `conf-${s.id}`,
            value: String(i + 1),
            checked: s.confidence === i + 1,
            on: { change: () => (s.confidence = i + 1) }
          }),
          h('span', {}, label)
        )
      )
    )

    const weak = h('textarea', {
      class: 'textarea',
      placeholder: 'e.g. quadratics, circle theorems, rearranging formulas',
      on: { input: (e: Event) => (s.weakTopics = (e.target as HTMLTextAreaElement).value) }
    })
    weak.value = s.weakTopics

    const name = h('input', {
      class: 'input',
      'aria-label': 'Subject name',
      on: { input: (e: Event) => (s.name = (e.target as HTMLInputElement).value) }
    })
    name.value = s.name

    return h(
      'section',
      { class: 'subject' },
      h('div', { class: 'subject__head' }, name, h('button', { class: 'btn btn--quiet', type: 'button', on: { click: () => removeSubject(s.id) } }, 'Remove')),
      h(
        'div',
        { class: 'grid-2' },
        h('label', { class: 'field' }, h('span', {}, 'Exam board'), board),
        h('div', { class: 'field' }, h('span', {}, 'How confident are you?'), scale)
      ),
      h('label', { class: 'field' }, h('span', {}, 'Topics you find hardest'), weak, h('small', {}, 'The more specific, the better your plan.'))
    )
  }

  function renderList(): void {
    list.replaceChildren(
      ...(draft.subjects.length
        ? draft.subjects.map(subjectRow)
        : [h('p', { class: 'muted' }, 'Pick your subjects above, or add your own.')])
    )
  }

  // Custom subject
  const custom = h('input', { class: 'input', placeholder: 'Another subject', 'aria-label': 'Another subject' })
  const addCustom = (): void => {
    addSubject(custom.value)
    custom.value = ''
  }
  custom.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault()
      addCustom()
    }
  })

  // Profile fields
  const nameInput = h('input', { class: 'input', placeholder: 'Optional', on: { input: (e: Event) => (draft.name = (e.target as HTMLInputElement).value) } })
  nameInput.value = draft.name
  const level = h('select', { class: 'select', on: { change: (e: Event) => (draft.level = (e.target as HTMLSelectElement).value) } }, LEVELS.map((l) => h('option', { value: l }, l)))
  level.value = LEVELS.includes(draft.level) ? draft.level : 'GCSE'
  draft.level = level.value
  const exam = h('input', { class: 'input', type: 'date', on: { input: (e: Event) => (draft.examDate = (e.target as HTMLInputElement).value) } })
  exam.value = draft.examDate
  const hours = h('input', {
    class: 'input',
    type: 'number',
    min: '1',
    max: '60',
    on: { input: (e: Event) => (draft.hoursPerWeek = Number((e.target as HTMLInputElement).value) || 1) }
  })
  hours.value = String(draft.hoursPerWeek)

  const save = h('button', { class: 'btn btn--primary', type: 'button' }, 'Save subjects')
  save.addEventListener('click', () =>
    withBusy(save, 'Saving…', async () => {
      if (!draft.subjects.some((s) => s.name.trim())) {
        toast('Add at least one subject.', 'error')
        return
      }
      const res = await window.study.saveProfile(draft)
      if (!res.ok) return toast(res.error, 'error')
      ctx.setState(res.data)
      toast('Subjects saved')
      ctx.go(res.data.handwriting ? 'plan' : 'handwriting')
    })
  )

  renderChips()
  renderList()

  return h(
    'div',
    { class: 'page' },
    h('h1', {}, 'What do you want to get better at?'),
    h('p', { class: 'lead' }, 'Tell me your subjects and what you find hard. I’ll use this for your revision plan, when marking, and when we talk in the notch.'),
    h(
      'div',
      { class: 'grid-2' },
      h('label', { class: 'field' }, h('span', {}, 'Your first name'), nameInput),
      h('label', { class: 'field' }, h('span', {}, 'Level'), level),
      h('label', { class: 'field' }, h('span', {}, 'First exam date'), exam, h('small', {}, 'Leave blank if you’re not sure.')),
      h('label', { class: 'field' }, h('span', {}, 'Hours a week for revision'), hours)
    ),
    h('h2', {}, 'Subjects'),
    chips,
    h('div', { class: 'row', style: 'margin-bottom:8px' }, h('div', { style: 'flex:1;min-width:200px' }, custom), h('button', { class: 'btn', type: 'button', on: { click: addCustom } }, 'Add subject')),
    list,
    h('div', { class: 'row', style: 'margin-top:28px' }, save)
  )
}
