/** Today: the home page. What to do right now, exam countdown and streak. */
import type { PlanTask } from '@shared/study'
import type { Ctx } from '../main'
import { h } from '../dom'
import { linkChips, scoreLabel } from './shared'

const DAY_MS = 86_400_000

function greeting(): string {
  const hr = new Date().getHours()
  return hr < 12 ? 'Good morning' : hr < 18 ? 'Good afternoon' : 'Good evening'
}

/** Consecutive days (ending today or yesterday) with revision activity. */
export function streak(days: string[]): number {
  const set = new Set(days)
  const d = new Date()
  if (!set.has(d.toLocaleDateString('en-CA'))) d.setDate(d.getDate() - 1)
  let n = 0
  while (set.has(d.toLocaleDateString('en-CA'))) {
    n++
    d.setDate(d.getDate() - 1)
  }
  return n
}

export function todayView(ctx: Ctx): HTMLElement {
  const s = ctx.state
  const name = s.profile?.name ? `, ${s.profile.name}` : ''
  const page = h('div', { class: 'page' }, h('h1', {}, `${greeting()}${name}`))

  // Setup checklist until the three setup steps are done.
  const steps: Array<[boolean, string, Parameters<Ctx['go']>[0]]> = [
    [Boolean(s.profile?.subjects.length), 'Add your subjects', 'subjects'],
    [Boolean(s.handwriting), 'Teach me your handwriting', 'handwriting'],
    [Boolean(s.plan), 'Make your revision plan', 'plan']
  ]
  const todo = steps.filter(([done]) => !done)
  if (todo.length) {
    page.append(
      h('p', { class: 'lead' }, 'A couple of quick steps and your tutor will know exactly how to help.'),
      h(
        'div',
        { class: 'setup' },
        steps.map(([done, label, tab], i) =>
          h(
            'button',
            { class: 'setup__step', type: 'button', 'data-done': String(done), on: { click: () => ctx.go(tab) } },
            h('span', { class: 'nav__mark', 'aria-hidden': 'true' }, done ? '✓' : String(i + 1)),
            label
          )
        )
      )
    )
  } else {
    page.append(h('p', { class: 'lead' }, 'Here’s what to do today.'))
  }

  // Stats
  const exam = s.profile?.examDate ? new Date(`${s.profile.examDate}T09:00:00`) : null
  const daysLeft = exam ? Math.ceil((exam.getTime() - Date.now()) / DAY_MS) : null
  const allTasks = s.plan?.subjects.flatMap((x) => x.topics.flatMap((t) => t.tasks)) ?? []
  const doneCount = allTasks.filter((t) => s.doneTasks.includes(t.id)).length
  const st = streak(s.activityDays)
  page.append(
    h(
      'div',
      { class: 'stats' },
      daysLeft != null && daysLeft >= 0 ? stat(String(daysLeft), daysLeft === 1 ? 'day until exams' : 'days until exams') : null,
      stat(String(st), st === 1 ? 'day streak' : 'day streak'),
      allTasks.length ? stat(`${doneCount}/${allTasks.length}`, 'plan tasks done') : null,
      stat(String(s.history.length + s.quizzes.length), 'marks and quizzes')
    )
  )

  // Quick actions
  page.append(
    h(
      'div',
      { class: 'row', style: 'margin:8px 0 8px' },
      h('button', { class: 'btn btn--primary', type: 'button', on: { click: () => window.study.startTutor() } }, 'Talk to my tutor'),
      h('button', { class: 'btn', type: 'button', on: { click: () => ctx.go('mark') } }, 'Mark my work'),
      h('button', { class: 'btn', type: 'button', on: { click: () => ctx.go('quiz') } }, 'Quick quiz')
    )
  )

  // Today's schedule from the plan
  if (s.plan) {
    const dayName = new Date().toLocaleDateString('en-GB', { weekday: 'long' }).toLowerCase()
    const day = s.plan.week.find((d) => d.day.toLowerCase().startsWith(dayName.slice(0, 3)))
    page.append(h('h2', {}, 'Today’s plan'))
    if (day && day.blocks.length) {
      page.append(
        h(
          'ul',
          { class: 'today-blocks' },
          day.blocks.map((b) => h('li', {}, h('b', {}, `${b.subject}: ${b.topic}`), h('span', { class: 'muted' }, ` ${b.minutes} min. ${b.activity}`)))
        )
      )
    } else {
      page.append(h('p', { class: 'muted' }, 'Nothing planned today. Take a rest, or do a quick quiz on something you find hard.'))
    }

    // Next unticked tasks
    const next: PlanTask[] = allTasks.filter((t) => !s.doneTasks.includes(t.id)).slice(0, 3)
    if (next.length) {
      page.append(
        h('h2', {}, 'Next up'),
        h(
          'ul',
          { class: 'tasks' },
          next.map((task) => {
            const li = h('li', { class: 'task', 'data-done': 'false' })
            li.append(
              h('input', {
                type: 'checkbox',
                'aria-label': `Done: ${task.text}`,
                on: {
                  change: async (e: Event) => {
                    const on = (e.target as HTMLInputElement).checked
                    li.dataset.done = String(on)
                    const ids = await window.study.setTaskDone(task.id, on)
                    ctx.setState({ ...ctx.state, doneTasks: ids, activityDays: (await window.study.getState()).activityDays })
                  }
                }
              }),
              h('div', {}, h('div', { class: 'task__text' }, task.text), h('div', { class: 'task__meta' }, `About ${task.minutes} minutes`), linkChips(task.resources))
            )
            return li
          })
        )
      )
    }
  }

  // Latest mark
  const last = s.history[0]
  if (last) {
    page.append(
      h('h2', {}, 'Last marked'),
      h(
        'button',
        { class: 'last-mark', type: 'button', on: { click: () => ctx.go('progress') } },
        h('span', {}, `${last.subject}: ${last.topic}`),
        h('span', { class: 'history__score' }, scoreLabel(last))
      )
    )
  }
  return page
}

function stat(value: string, label: string): HTMLElement {
  return h('div', { class: 'stat' }, h('b', {}, value), h('span', {}, label))
}
