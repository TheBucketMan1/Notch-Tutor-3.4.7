/**
 * Shared contract between main, preload and renderer.
 *
 * Two planes:
 *  1. CONTROL plane – ipcRenderer.invoke / ipcMain.handle. Low frequency
 *     (start/stop, keys, permissions). Request/response semantics.
 *  2. DATA plane – a dedicated MessageChannel (MessagePortMain <-> MessagePort).
 *     Carries ~25 audio chunks/s + ~1 frame/s each way with no JSON, no
 *     base64 and no ipcMain routing overhead. Binary goes as ArrayBuffers;
 *     base64 encoding happens once, in the main process, right before the
 *     socket write (Node's Buffer base64 is native and much faster than btoa).
 *
 * The API key lives ONLY in the main process. The renderer never sees it and
 * never talks to the network, so a compromised renderer can't exfiltrate it.
 */

export const IPC = {
  sessionStart: 'session:start',
  sessionStop: 'session:stop',
  sessionState: 'session:state', // main -> renderer push
  keyStatus: 'key:status',
  keySet: 'key:set',
  keyClear: 'key:clear',
  permEnsure: 'perm:ensure',
  windowInteractive: 'window:interactive',
  quit: 'app:quit',
  mediaPortRequest: 'media:port-request',
  mediaPort: 'media:port', // main -> renderer, carries the MessagePort
  shortcutToggle: 'shortcut:toggle', // main -> renderer push
  startRequest: 'tutor:start-request', // main -> notch push (from the study hub)
  ptt: 'ptt:state', // main -> notch push: push-to-talk key down/up
  settingsChanged: 'settings:changed' // main -> all windows push
} as const

/** Audio formats fixed by the Gemini Live API. */
export const AUDIO_IN_RATE = 16_000 // mic → model: PCM16 LE mono 16 kHz
export const AUDIO_OUT_RATE = 24_000 // model → speaker: PCM16 LE mono 24 kHz

export type SessionState = 'idle' | 'connecting' | 'live' | 'reconnecting' | 'error'

export interface SessionStateEvent {
  state: SessionState
  detail?: string
}

export type PermissionStatus = 'granted' | 'denied' | 'unknown'

export interface PermissionReport {
  microphone: PermissionStatus
  screen: PermissionStatus
}

export type KeySource = 'env' | 'keychain' | 'none'

export type StartResult = { ok: true } | { ok: false; error: string; code?: 'NO_KEY' | 'BAD_KEY' | 'CONNECT' }

/** Renderer → main over the MessagePort. */
export type RendererToMain =
  | { t: 'audio'; buf: ArrayBuffer } // PCM16 LE mono @ 16 kHz, ~40 ms
  | { t: 'frame'; buf: ArrayBuffer } // JPEG bytes of the primary screen
  | { t: 'audioEnd' } // mic muted → lets server VAD flush immediately
  | { t: 'activityStart' } // push-to-talk key pressed
  | { t: 'activityEnd' } // push-to-talk key released → model replies
  | { t: 'text'; text: string } // typed question (optional UI path)

/** Main → renderer over the MessagePort. */
export type MainToRenderer =
  | { t: 'audio'; buf: ArrayBuffer | Uint8Array } // PCM16 LE mono @ 24 kHz
  | { t: 'interrupted' } // user barged in → flush playback NOW
  | { t: 'turnComplete' } // model finished its turn → drain what's buffered
  | { t: 'transcript'; role: 'user' | 'tutor'; text: string }
  | { t: 'question'; question: string; hint: string } // tutor wants a typed answer

/** The API the preload exposes as `window.notch`. */
export interface NotchApi {
  startSession(): Promise<StartResult>
  stopSession(): Promise<void>
  keyStatus(): Promise<{ hasKey: boolean; source: KeySource }>
  setKey(key: string): Promise<{ ok: boolean; error?: string }>
  clearKey(): Promise<void>
  ensurePermissions(): Promise<PermissionReport>
  /** interactive=false → clicks pass through transparent areas to apps below. */
  setInteractive(interactive: boolean, wantsKeyboard?: boolean): void
  quit(): void
  /** Opens (or focuses) the study hub window. */
  openStudyHub(): void
  requestMediaPort(): void
  onSessionState(cb: (e: SessionStateEvent) => void): () => void
  onShortcutToggle(cb: () => void): () => void
  onStartRequest(cb: () => void): () => void
  /** Global push-to-talk key pressed (true) / released (false). */
  onPtt(cb: (down: boolean) => void): () => void
  platform: NodeJS.Platform
}
