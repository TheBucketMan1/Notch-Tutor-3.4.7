/**
 * Study hub contract (main <-> preload <-> study window).
 *
 * Everything the model produces is normalised in the main process into these
 * shapes before it reaches the UI, so the renderer never has to defend against
 * missing fields. The renderer renders model text with textContent only.
 */

export const STUDY_IPC = {
  open: 'hub:open',
  getState: 'study:get-state',
  saveProfile: 'study:save-profile',
  analyzeHandwriting: 'study:analyze-handwriting',
  generatePlan: 'study:generate-plan',
  setTaskDone: 'study:set-task-done',
  markWork: 'study:mark-work',
  deleteHistory: 'study:delete-history',
  ensureCamera: 'study:ensure-camera',
  openExternal: 'study:open-external',
  getOpenAtLogin: 'app:get-open-at-login',
  setOpenAtLogin: 'app:set-open-at-login',
  makeQuiz: 'study:make-quiz',
  saveQuiz: 'study:save-quiz',
  deleteAll: 'study:delete-all',
  getSettings: 'settings:get',
  updateSettings: 'settings:update',
  recordKey: 'settings:record-key',
  accessibility: 'settings:accessibility',
  requestAccessibility: 'settings:request-accessibility',
  keyStatus: 'settings:key-status',
  setApiKey: 'settings:set-key',
  removeApiKey: 'settings:remove-key',
  startTutor: 'tutor:start',
  navigate: 'hub:navigate' // main -> hub push
} as const

/** Shown in Settings → About and in the app metadata. */
export const APP_AUTHOR = 'Romell'

/** Prebuilt Gemini Live voices offered in Settings ('' = Google's default). */
export const VOICES = ['Puck', 'Charon', 'Kore', 'Fenrir', 'Aoede', 'Leda', 'Orus', 'Zephyr'] as const

export interface AppSettings {
  /** 'hold' = push-to-talk (hold a key); 'always' = always listening with a mute button. */
  talkMode: 'hold' | 'always'
  /** uiohook keycode of the push-to-talk key. Default: Right Option (0x0E38). */
  pttKeycode: number
  pttKeyName: string
  voice: string
  /** 'guide' = hints and questions first; 'direct' = explain answers straight away. */
  tutorStyle: 'guide' | 'direct'
  showFace: boolean
  /** 'sharp' reads small text better but uses more of the free allowance. */
  screenDetail: 'standard' | 'sharp'
}

export const DEFAULT_SETTINGS: AppSettings = {
  talkMode: 'hold',
  pttKeycode: 0x0e38,
  pttKeyName: 'Right Option',
  voice: '',
  tutorStyle: 'guide',
  showFace: true,
  screenDetail: 'standard'
}

export interface AccessibilityStatus {
  /** Whether hold-to-talk can see key presses (macOS Accessibility permission). */
  granted: boolean
  /** False when the platform doesn't need it (Windows). */
  required: boolean
  /** The key listener failed to load or start. */
  error: string
}

export interface QuizQuestion {
  question: string
  options: string[]
  answerIndex: number
  explanation: string
}

export interface Quiz {
  subject: string
  topic: string
  questions: QuizQuestion[]
}

export interface QuizRequest {
  subject: string
  topic: string
  count: number
  difficulty: 'easier' | 'exam' | 'harder'
}

export interface QuizResult {
  id: string
  createdAt: number
  subject: string
  topic: string
  correct: number
  total: number
}

/** Exactly what the student copies out for handwriting calibration. */
export const HANDWRITING_LINES: readonly string[] = [
  'The quick brown fox jumps over the lazy dog.',
  'Pack my box with five dozen liquor jugs.',
  'Jackdaws love my big sphinx of quartz.',
  'The five boxing wizards jump quickly.',
  'a b c d e f g h i j k l m n o p q r s t u v w x y z',
  'A B C D E F G H I J K L M N O P Q R S T U V W X Y Z',
  '0 1 2 3 4 5 6 7 8 9'
]

export interface SubjectPref {
  id: string
  name: string
  /** Exam board for this subject, e.g. "AQA". Empty = not sure. */
  board: string
  /** Free text: the topics the student finds hardest. */
  weakTopics: string
  /** 1 = struggling, 5 = confident. */
  confidence: number
}

export interface StudyProfile {
  name: string
  level: string
  examDate: string // yyyy-mm-dd or ''
  hoursPerWeek: number
  subjects: SubjectPref[]
  updatedAt: number
}

export interface HandwritingProfile {
  transcription: string
  accuracyPercent: number
  confusions: Array<{ chars: string; note: string }>
  profile: string
  tips: string[]
  createdAt: number
}

export type LinkKind = 'video' | 'notes' | 'practice' | 'pastpapers' | 'search'

export interface ResourceLink {
  label: string
  url: string
  kind: LinkKind
}

export interface PlanTask {
  id: string
  text: string
  minutes: number
  resources: ResourceLink[]
}

export interface PlanTopic {
  topic: string
  why: string
  tasks: PlanTask[]
}

export interface PlanSubject {
  subject: string
  topics: PlanTopic[]
}

export interface PlanBlock {
  subject: string
  topic: string
  minutes: number
  activity: string
}

export interface PlanDay {
  day: string
  blocks: PlanBlock[]
}

export interface RevisionPlan {
  overview: string
  subjects: PlanSubject[]
  week: PlanDay[]
  tips: string[]
  createdAt: number
}

export interface MarkMistake {
  where: string
  youWrote: string
  correct: string
  why: string
}

export interface MarkScore {
  got: number | null
  outOf: number | null
  percent: number | null
  estimated: boolean
  grade: string
}

export interface NextStep {
  topic: string
  why: string
  links: ResourceLink[]
}

export interface MarkResult {
  id: string
  createdAt: number
  subject: string
  topic: string
  transcription: string
  readingConfidence: 'high' | 'medium' | 'low'
  unclearParts: string[]
  score: MarkScore
  summary: string
  strengths: string[]
  mistakes: MarkMistake[]
  improvements: string[]
  nextSteps: NextStep[]
}

export interface StudyState {
  profile: StudyProfile | null
  handwriting: HandwritingProfile | null
  plan: RevisionPlan | null
  doneTasks: string[]
  history: MarkResult[]
  quizzes: QuizResult[]
  /** Local dates (yyyy-mm-dd) with any revision activity, for the streak. */
  activityDays: string[]
}

/** A file prepared by the renderer (images downscaled to JPEG; PDFs/HEIC raw). */
export interface UploadFile {
  name: string
  mimeType: string
  dataBase64: string
}

export interface MarkRequest {
  files: UploadFile[]
  subject: string
  question: string
  markScheme: string
}

export interface LoginItemStatus {
  enabled: boolean
  /** macOS registered it but the user must switch it on in Login Items. */
  needsApproval: boolean
  /** False in development builds and on Linux. */
  supported: boolean
}

export type StudyResult<T> = { ok: true; data: T } | { ok: false; error: string }

export interface StudyApi {
  getState(): Promise<StudyState>
  saveProfile(profile: StudyProfile): Promise<StudyResult<StudyState>>
  analyzeHandwriting(sample: UploadFile): Promise<StudyResult<HandwritingProfile>>
  generatePlan(): Promise<StudyResult<RevisionPlan>>
  setTaskDone(taskId: string, done: boolean): Promise<string[]>
  markWork(req: MarkRequest): Promise<StudyResult<MarkResult>>
  deleteHistoryItem(id: string): Promise<MarkResult[]>
  ensureCamera(): Promise<boolean>
  openExternal(url: string): void
  getOpenAtLogin(): Promise<LoginItemStatus>
  setOpenAtLogin(on: boolean): Promise<LoginItemStatus>
  makeQuiz(req: QuizRequest): Promise<StudyResult<Quiz>>
  saveQuizResult(r: QuizResult): Promise<StudyState>
  deleteAllData(): Promise<StudyState>
  getSettings(): Promise<AppSettings & { appVersion: string }>
  updateSettings(patch: Partial<AppSettings>): Promise<AppSettings>
  /** Resolves with the next key the user presses anywhere (null on cancel/timeout). */
  recordPttKey(): Promise<{ keycode: number; name: string } | null>
  getAccessibility(): Promise<AccessibilityStatus>
  requestAccessibility(): Promise<AccessibilityStatus>
  keyStatus(): Promise<{ hasKey: boolean; source: 'env' | 'keychain' | 'none' }>
  setApiKey(key: string): Promise<{ ok: boolean; error?: string }>
  removeApiKey(): Promise<void>
  startTutor(): void
  onNavigate(cb: (tab: string) => void): () => void
  onSettingsChanged(cb: (s: AppSettings) => void): () => void
}
